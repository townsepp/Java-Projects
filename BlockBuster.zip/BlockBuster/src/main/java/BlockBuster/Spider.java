package BlockBuster;

import java.util.ArrayList;
import java.util.List;

public class Spider  {

    
    public Spider() {
        
    }
    
    private static List<Blocks> blocks= new ArrayList();//block board
    private static int playerX ;// keeps track of playable character's x coordinate
    private static int playerY ;// keeps track of playable character's y coordinate
    private static int spiderX;// keeps track of spider's x coordinate
    private static int spiderY;// keeps track of spider's y coordinate
    private static int spiderHitPoints = 10; //hit points the spider has
    private static int spiderHunger = 0;// level of hunger the spider has, higher hunger level mean more hungry
    private static BlockPanel blockPanel= new BlockPanel();//access to blockpanel class
    private static AStar star;//Access to Astar class
    private static int xSize;//horizonal length of board(for knowing where blocks are we need this)
    private static int damage=0;//how many hits are on the player this turn
    private static int strength=10;//strength of the hits
   private static int direction;//direction of wander movement 
   
   
   //set global variables equal to passed in values
public static void setEqual(int x, int y, int counter, int index, int X,int Y,
        int health, int hunger,List<Blocks> list, int width, int dir){
direction=dir;
        damage=0;
    	spiderX=x;
        spiderY=y;
        playerX=X;
        playerY=Y;
       spiderHitPoints=health;
       spiderHunger=hunger;
        xSize=width;
         blocks=list;
}
//displays information for debugging
public static void displayToTerminal() {
	System.out.println("PlayerX: "+playerX);
	System.out.println("PlayerY: "+playerY);
	System.out.println("SpiderX: "+spiderX);
	System.out.println("SpiderY: "+spiderY);
	System.out.println("Spider hit Points: "+spiderHitPoints);
	System.out.println("hunger: "+spiderHunger);
}
//internal and external environment actions
public static void timeAndHungerControls() {
	

 //20% chance for hunger to change with random int
	
	if(Math.random() <= .05 ) {
		spiderHunger++;
	} 
	//keeps hunger from becoming too large
	if(spiderHunger>=10) {
		spiderHunger=10;
        }
      }
//movement used for chase state
public static void chaseMovement() {
    if( Math.abs(spiderY-playerY)+Math.abs(spiderX-playerX)<=8){
switch(star.planPath( spiderX,  spiderY,  playerX,  playerY,  blocks, xSize)){
    case left->spiderX--;
    case right->spiderX++;
    case up->spiderY--;
    case down->spiderY++;
    case mine-> wanderMovement();
}
    }
         
}
//attack type
public static void attack(){
if(playerX==spiderX&&Math.abs(playerY-spiderY)<=1){
spiderHitPoints++;
spiderHunger--;
damage++;
}else if (playerY==spiderY&&Math.abs(playerX-spiderX)<=1){
spiderHitPoints++;
spiderHunger--;
damage++;
}
}
//movement used running state
public static void runMovement() {
if(spiderX-playerX>=0 && spiderY-playerY>=0){
    System.out.println("down right");
if(blocks.get(spiderX+spiderY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+spiderY*xSize+1).getBlocktype()==BlockType.sky){
    spiderX++;
}else if(blocks.get(spiderX+(spiderY+1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+(spiderY+1)*xSize).getBlocktype()==BlockType.sky){
spiderY++;}
}else if(spiderX-playerX>=0 && spiderY-playerY<=0){
    System.out.println("up right");
if(blocks.get(spiderX+spiderY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+spiderY*xSize+1).getBlocktype()==BlockType.sky){
    spiderX++;
}else if(blocks.get(spiderX+(spiderY-1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+(spiderY-1)*xSize).getBlocktype()==BlockType.sky){
spiderY--;}
    }else if(spiderX-playerX<=0 && spiderY-playerY>=0){
        System.out.println("left down");
if(blocks.get(spiderX+spiderY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+spiderY*xSize-1).getBlocktype()==BlockType.sky){
    spiderX--;
}else if(blocks.get(spiderX+(spiderY+1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+(spiderY+1)*xSize).getBlocktype()==BlockType.sky){
spiderY++;}
    }else if(spiderX-playerX<=0 && spiderY-playerY<=0){
        System.out.println("left up");
     if(blocks.get(spiderX+spiderY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+spiderY*xSize-1).getBlocktype()==BlockType.sky){
    spiderX--;
}else if(blocks.get(spiderX+(spiderY-1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+(spiderY-1)*xSize).getBlocktype()==BlockType.sky){
spiderY--;}
}else {
        System.out.println("wander");
wanderMovement();
}
}   
//movement used for wnder state
public static void wanderMovement() {
if(direction==1&&Math.random()<.75 &&(blocks.get(spiderX+spiderY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+spiderY*xSize+1).getBlocktype()==BlockType.sky)){
spiderX++;
direction=1;
}else if(direction==0 && Math.random()<.75 &&(blocks.get(spiderX+spiderY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+spiderY*xSize-1).getBlocktype()==BlockType.sky)){
spiderX--;
direction=0;
}else if(direction==0 && (blocks.get(spiderX+spiderY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+spiderY*xSize+1).getBlocktype()==BlockType.sky)){
spiderX++;
direction=1;
}else if(direction==1 && blocks.get(spiderX+spiderY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(spiderX+spiderY*xSize-1).getBlocktype()==BlockType.sky){
spiderX--;
direction=0;
}
}  

public static abstract class State {
       
        //empty constructor
        public State() {}
        //methods
        public abstract void enter();
        public abstract void exit();
        public abstract void environment();
        public abstract void movement();
        public abstract int updateAndCheckTransitions();
        
    }
    
    
   // this class represents the spider taking the run action
    // when health is low the spider will run away from the playable character
    public static class Run extends State {
        public Run() {
            super();
        }
        
        public void enter() {
            System.out.println("The spider is running from you!");
        }
        public void exit() {  
        	System.out.println("run exit");
        }
        
        public void environment(){
        timeAndHungerControls();
        }
        public void movement() {
        	runMovement();
                attack();
        	//displayToTerminal();
    }
        public int updateAndCheckTransitions() { 
            //chance to switch to chase increases as distance decreases and hunger increases
            //if health is low wont chase
             if(Math.abs(playerX-spiderX)+Math.abs(playerY-spiderY)-spiderHunger<=Math.random()*10 && spiderHitPoints>2 ){
            	return 0;
                //if health low and player close run away
            }else if(Math.abs(playerX-spiderX)+Math.abs(playerY-spiderY)<=6 && spiderHitPoints<=2){
            	return 1;
                //otherwise wander
            }else {
            	return 2;
            }
         
    }    
    }      
   // this class represent the spider taking a chasing action 
    // the spider will chase the playable character faster as hunger becomes higher 
    public static class Chase extends State {
	
        public Chase() {
           
            super();
        }
        
        
        public void enter() {
            System.out.println("The spider is chasing you!");
        }
        public void exit() {            
        	System.out.println("chase exit");
        }
       
        public void environment(){
        timeAndHungerControls();
        }
         
        public void movement() {
                attack();
        	chaseMovement();
    }
        public int updateAndCheckTransitions() {
                //if health is low and hunger sint high enough spider runs
            if(spiderHitPoints<=2 && spiderHunger<8) {
           return 1;
            //if player is too far away spider will wander
            }else if(Math.abs(playerX-spiderX)+Math.abs(playerY-spiderY)>6){
                    return 2;
                    //keep chasing otherwise
                }else {
        		return 0;
        	}
              
    }
        
        
    }   
    // this class represent the spider taking a wandering action 
    // the spider will wander and has a 25% chance of turning around after starting direction
   public static class Wander extends State {
        public Wander() {
            super();
        }
        
        public void enter() {
            System.out.println("The spider is wandering");
        }
        public void exit() {            
        	System.out.println("wander exit");
        }
                	                    
       public void environment(){
       timeAndHungerControls();
       }
        //moves spider and prints out 
        public void movement() {
        	wanderMovement();
        	//displayToTerminal();
        }
        public int updateAndCheckTransitions() {  
        	//chance of spider switching to chasing state increases as distance decreases
        	if (Math.abs(playerX-spiderX)+ Math.abs(playerY-spiderY)-spiderHunger< Math.random()*16 ) {
          	  return 0;
          	  //switch to run if health is low and player is nearby
            }else if( Math.abs(playerX-spiderX)+ Math.abs(playerY-spiderY)<=6&& spiderHitPoints<=2){
            	return 1;
                //else keep wandering
            }else {
            	return 2;
            }
              
        }            
         
    } 

   //functionality of the Spider is in this main
    public static Mobs call(int x, int y, int state, int counter, int index, boolean sun, int X,int Y,
            int health, int hunger,boolean burning ,List<Blocks> list, int width, int dir){
        //set global variables equal to passed in values
      setEqual(x,y,counter,index,X,Y,health,hunger,list,width,dir);
      counter++;
        // three states: run, chase, wander
        int numberOfStates = 3;
        
        State[] states = new State[numberOfStates];
        states[0] = new Chase();
        states[1] = new Run();
        states[2] = new Wander();
        
        
//variables keep track of the state the spider is in

 int currentState = state;
 
       
       	
       	
       	//checks internal and external environment queues to see if the state will change or remain the same
            int nextState = states[currentState].updateAndCheckTransitions();
            //exits current state and enters new state
            //counter is for timeout
            if (nextState != currentState&& counter>=3) {
            	//prints out exit state 
               // states[currentState].exit();
                //changes curent state to next state
                currentState = nextState;  
             // prints out state so user is aware of the action the spider may take
               // states[currentState].enter();
                counter=0;
            }
            //moves the spider 
        states[currentState].movement();
       	//extra movement chance for spider hunger level 0-50% chance;
       	if(Math.random()*hunger>=5) {
       		states[currentState].movement();
       	}
              states[currentState].environment();
             Mobs spider= new Mobs(spiderX,spiderY,currentState, counter, spiderHunger, spiderHitPoints, false, damage*strength, direction);
            return spider;
        }
    
    
    




    
                    
}

