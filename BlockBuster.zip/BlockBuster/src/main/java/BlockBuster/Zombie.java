
package BlockBuster;

import java.util.ArrayList;
import java.util.List;

public class Zombie  {

    
    public Zombie() {
        
    }
    
    private static List<Blocks> blocks= new ArrayList();
    private static int playerX ;// keeps track of playable character's x coordinate
    private static int playerY ;// keeps track of playable character's y coordinate
    private static int zombieX;// keeps track of zombie's x coordinate
    private static int zombieY;// keeps track of zombie's y coordinate
    private static int zombieHitPoints = 10; //hit points the zombie has
    private static boolean isBurning;// if zombie is burning
    private static int playerHitPoints = 10; //hit points the playable character has
    private static int zombieHunger = 0;// level of hunger the zombie has, higher hunger level mean more hungry
    private static int sunOut = 0;// if sun is out sun will have value of 1 if sun is down sun will have value of 0
    private static int speed=1; // speed of zombie, only one speed for now but can change for later us
    private static BlockPanel blockPanel= new BlockPanel();//acces to Blockpanel class
    private static AStar star;//access to Astar class
    private static int xSize;//  number of horizontal blocks in map
    private static int damage=0;//number of time attacking player
    private static int strength=30;//strenght of attacks
   private static int direction;//direction to wander

//sets global variables equal to passed in values
   public static void setEqual(int x, int y, int counter, int index, int X,int Y,
        int health, int hunger,List<Blocks> list, int width, int dir, boolean sun, boolean burning){
direction=dir;
        damage=0;
    	zombieX=x;
        zombieY=y;
        playerX=X;
        playerY=Y;
       zombieHitPoints=health;
       zombieHunger=hunger;
        xSize=width;
         blocks=list;
         if(sun==true){
       sunOut=1;
       }else{
       sunOut=0;
       }
         isBurning=burning;
}
//displays information to terminal if needed
   public static void displayToTerminal() {
	System.out.println("PlayerX: "+playerX);
	System.out.println("PlayerY: "+playerY);
	System.out.println("ZombieX: "+zombieX);
	System.out.println("ZombieY: "+zombieY);
	System.out.println("Zombie hit Points: "+zombieHitPoints);
	System.out.println("Player hit Points: "+playerHitPoints);
	System.out.println("hunger: "+zombieHunger);
	System.out.println("Sun: "+sunOut);
}    
//changes hunger and health is in sun
   public static void timeAndHungerControls() {
	//if zombie is not in shade of tree and sun is out it takes damage here
	if(isInSun()&& sunOut==1) {
  	   zombieHitPoints--;
           isBurning=true;
     }else{
      isBurning=false; }

 //20% chance for hunger to change with random int
	
	if(Math.random() <= .05 ) {
		zombieHunger++;
	} 
	//keeps hunger from becoming too large
	if(zombieHunger>=10) {
		zombieHunger=10;
        }
      }
   //movment used to chase player
public static void chaseMovement() {
    //if zombie is close enough run A* and return direction 
    if( Math.abs(zombieY-playerY)+Math.abs(zombieX-playerX)<=8){
switch(star.planPath( zombieX,  zombieY,  playerX,  playerY,  blocks, xSize)){
    case left->zombieX--;
    case right->zombieX++;
    case up->zombieY--;
    case down->zombieY++;
    case mine-> wanderMovement();
}
    }
         
}
//attacks player if able 
public static void attack(){
if(playerX==zombieX&&Math.abs(playerY-zombieY)<=1){
zombieHitPoints++;
zombieHunger--;
damage++;
}else if (playerY==zombieY&&Math.abs(playerX-zombieX)<=1){
zombieHitPoints++;
zombieHunger--;
damage++;
}
}
//movement used in run state
public static void runMovement(int x) {
    //moves zombie away from player in a diagonal line
    //ex: if player if left and below the zombie it will move right and up direction
if(zombieX-playerX>=0 && zombieY-playerY>=0){
    System.out.println("down right");
if(blocks.get(zombieX+zombieY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+zombieY*xSize+1).getBlocktype()==BlockType.sky){
    zombieX++;
}else if(blocks.get(zombieX+(zombieY+1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+(zombieY+1)*xSize).getBlocktype()==BlockType.sky){
zombieY++;}
}else if(zombieX-playerX>=0 && zombieY-playerY<=0){
    System.out.println("up right");
if(blocks.get(zombieX+zombieY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+zombieY*xSize+1).getBlocktype()==BlockType.sky){
    zombieX++;
}else if(blocks.get(zombieX+(zombieY-1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+(zombieY-1)*xSize).getBlocktype()==BlockType.sky){
zombieY--;}
    }else if(zombieX-playerX<=0 && zombieY-playerY>=0){
        System.out.println("left down");
if(blocks.get(zombieX+zombieY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+zombieY*xSize-1).getBlocktype()==BlockType.sky){
    zombieX--;
}else if(blocks.get(zombieX+(zombieY+1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+(zombieY+1)*xSize).getBlocktype()==BlockType.sky){
zombieY++;}
    }else if(zombieX-playerX<=0 && zombieY-playerY<=0){
        System.out.println("left up");
     if(blocks.get(zombieX+zombieY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+zombieY*xSize-1).getBlocktype()==BlockType.sky){
    zombieX--;
}else if(blocks.get(zombieX+(zombieY-1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+(zombieY-1)*xSize).getBlocktype()==BlockType.sky){
zombieY--;}
}else {
        System.out.println("wander");
wanderMovement();
}
}
//movement used in hide state
public static void hideMovement(){
    //cheks 5 blocks left and 5 blocks right, which ever one has a closer spot with shade 
    //is the direction the mob moves in if none within 5 blocks both ways wander 
    if(isInSun()){      
    int testClosestTree=0;
    int closestTree=0;
    for(int j=0; j<zombieY  ;j++){
        testClosestTree=j;
        if(testClosestTree%2==0){
            testClosestTree=-testClosestTree/2;
        }else{
        testClosestTree=testClosestTree/2+1;
        }
        for(int i=0; i<zombieY  ;i++){
       
        if(zombieX+testClosestTree+i*blockPanel.getXSize()>=0){
        if(blocks.get(zombieX+testClosestTree+i*blockPanel.getXSize()).getBlocktype()!=BlockType.empty&&
               blocks.get(zombieX+testClosestTree+i*blockPanel.getXSize()).getBlocktype()!=BlockType.sky ){
        closestTree=testClosestTree;
            break;
        }
    }
        }
        if(closestTree!=0){
    break;
    }   
    }
    if(closestTree<0){
    zombieX--;
    }else if(closestTree>0){
    zombieX++;
    }else if(Math.abs(playerX-zombieX)+ Math.abs(playerY-zombieY)<=6){
    chaseMovement();
    }else{
    wanderMovement();
    }
    }else{
     if(Math.abs(playerX-zombieX)+ Math.abs(playerY-zombieY)<=6){
    chaseMovement();
    attack();
    }else{
    wanderMovement();
    }
    }
    if(isInSun()){
        isBurning=true;
    }else{
    isBurning=false;
    }
    
}
//movemnet used to wander side to side
public static void wanderMovement() {
    
    //25% chance to change direction so mobs will sort of patrol in a line for some time
    //and not move back and forth randomly
if(direction==1&&Math.random()<.75 &&(blocks.get(zombieX+zombieY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+zombieY*xSize+1).getBlocktype()==BlockType.sky)){
zombieX++;
direction=1;
}else if(direction==0 && Math.random()<.75 &&(blocks.get(zombieX+zombieY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+zombieY*xSize-1).getBlocktype()==BlockType.sky)){
zombieX--;
direction=0;
}else if(direction==0 && (blocks.get(zombieX+zombieY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+zombieY*xSize+1).getBlocktype()==BlockType.sky)){
zombieX++;
direction=1;
}else if(direction==1 && blocks.get(zombieX+zombieY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(zombieX+zombieY*xSize-1).getBlocktype()==BlockType.sky){
zombieX--;
direction=0;
}
}  
//return true in in sun and false if not
public static boolean isInSun(){
Boolean inSun=true;
if(sunOut==1){
    //chekcs if there a block not empty above mob to block sun
    for(int i=0; i<zombieY && inSun==true ;i++){
        if(blocks.get(zombieX+i*blockPanel.getXSize()).getBlocktype()!=BlockType.empty&&
               blocks.get(zombieX+i*blockPanel.getXSize()).getBlocktype()!=BlockType.sky ){
        inSun=false;
        break;
        }
    }
}else{inSun=false;
}
    return  inSun;
}

public static abstract class State {
       
        //empty constructor
        public State() {}
        //methods
        public abstract void enter();
        public abstract void exit();
        public abstract void environment();
        public abstract void movement();
        public abstract int updateAndCheckTransitions();
        
    }
    
    // this class represents the zombie taking a hiding action 
    //usually will hide when the sun is out 
    public static class Hide extends State {
        public Hide() {
            super();
        }
        
        public void enter() {
            System.out.println("The zombie is trying to hide under tree.");
        }
        public void exit() {            
        	System.out.println("hide exit");
        }
                	                    
       public void environment(){
       timeAndHungerControls();
       }
        //moves zombie and prints out 
        public void movement() {
        	hideMovement();
                attack();
        	//displayToTerminal();
        }
        public int updateAndCheckTransitions() {  
        	//chance of zombie switching to chasing state increases as distance decreases
        	if ((Math.abs(playerX-zombieX)+ Math.abs(playerY-zombieY)<Math.random()*16 && !isInSun()) || zombieHunger>=9) {
          	  return 0;
          	  //switch to run if health is low and player is nearby
            }else if(zombieHitPoints<=2&& Math.abs(playerX-zombieX)+ Math.abs(playerY-zombieY)<6 ){
            	return 2;
                //if out of sun wander
            }if(!isInSun()){
            return 3;
            }
            //other wise keep hiding
                return 1;
        }            
         
    }
   // this class represents the zombie taking the run action
    // when health is low the zombie will run away from the playable character
    public static class Run extends State {
        public Run() {
            super();
        }
        
        public void enter() {
            System.out.println("The zombie is running from you!");
        }
        public void exit() {  
        	System.out.println("run exit");
        }
        
        public void environment(){
        timeAndHungerControls();
        }
        public void movement() {
            attack();
        	runMovement(0);
        	//displayToTerminal();
    }
        public int updateAndCheckTransitions() { 
            //if out of sun and hungry enough chase player if close
            if(!isInSun() && zombieHunger>=8 && Math.abs(playerX-zombieX)+Math.abs(playerY-zombieY)<6) {
            	return 0;
                //if in sun hide
            }else if(isInSun()){
            	return 1;
                //if player far away wander
            }else if(Math.abs(playerX-zombieX)+Math.abs(playerY-zombieY)>6){
            	return 3;
                //else keep running
            }
        return 2;
    }    
    }      
   // this class represent the zombie taking a chasing action 
    // the zombie will chase the playable character faster as hunger becomes higher 
    public static class Chase extends State {
	
        public Chase() {
           
            super();
        }
        
        
        public void enter() {
            System.out.println("The zombie is chasing you!");
        }
        public void exit() {            
        	System.out.println("chase exit");
        }
       
        public void environment(){
        timeAndHungerControls();
        }
         
        public void movement() {
             attack();
        	chaseMovement();
    }
        public int updateAndCheckTransitions() {
            //if sun is down and health is low chance of running decreases as hunger increases from 10%-100%
        	if(!isInSun() && zombieHitPoints<=2 && Math.random()>.1*zombieHunger) {
           return 2;
            //if sun is up hide 
           }else if(isInSun()){
        		return 1;
                        //if player is too far away from zombies wander
        	}else if(Math.abs(playerX-zombieX)+Math.abs(playerY-zombieY)>6){
                    return 3;
                    //keep chasing otherwise
                }else {
        		return 0;
        	}
              
    }
        
        
    }
    // this class represent the zombie taking a wander action 
    // the zombie will move left and right
   public static class Wander extends State {
        public Wander() {
            super();
        }
        
        public void enter() {
            System.out.println("The zombie is wandering");
        }
        public void exit() {            
        	System.out.println("wander exit");
        }
                	                    
       public void environment(){
       timeAndHungerControls();
       }
        //moves zombie and prints out 
        public void movement() {
        	wanderMovement();
        	//displayToTerminal();
        }
        public int updateAndCheckTransitions() {  
        	//chance of zombie switching to chasing state increases as distance decreases
        	if (Math.abs(playerX-zombieX)+ Math.abs(playerY-zombieY)-zombieHunger< Math.random()*16 && !isInSun()) {
          	  return 0;
                  // if in sun hide
            }else if( isInSun()){
            	return 1;
                 //switch to run if health is low and player is nearby
            }else if(Math.abs(playerX-zombieX)+ Math.abs(playerY-zombieY)< 6 && zombieHitPoints<=2){
            	return 2;
            }
                //else keep wandering
                return 3;
        }            
         
    } 

   //functionality of the Zombie is in this main
    public static Mobs call(int x, int y, int state, int counter, int index, boolean sun, int X,int Y, int health, int hunger,boolean burning ,List<Blocks> list, int width, int dir){
       //set global variables equal to passed in values
         setEqual(x,y,counter,index,X,Y,health,hunger,list,width,dir, sun, burning);
        counter++;
        
        // four states: run, chase, hide, wander
        int numberOfStates = 4;
        State[] states = new State[numberOfStates];
        states[0] = new Chase();
        states[1] = new Hide();
        states[2] = new Run();
        states[3] = new Wander();
            
//variables keep track of the state the zombie is in
 int currentState = state;
 
       	//checks internal and external environment queues to see if the state will change or remain the same
            int nextState = states[currentState].updateAndCheckTransitions();
            //exits current state and enters new state
            //counter is for timeout
            if (nextState != currentState&& counter>=2) {
            	//prints out exit state 
                //states[currentState].exit();
                //changes curent state to next state
                currentState = nextState;  
             // prints out state so user is aware of the action the zombie may take
                //states[currentState].enter();
                counter=0;
            }
            //moves the zombie 
        states[currentState].movement();
       	//extra movement chance for zombie hunger level 0-50% chance;
       	if(Math.random()*hunger>=5) {
       		states[currentState].movement();
       	}
              states[currentState].environment();
              //return Mob to update info in blockpanel
             Mobs zombie= new Mobs(zombieX,zombieY,currentState, counter, zombieHunger, zombieHitPoints, isBurning, damage*strength, direction);
            return zombie;
            
        }
    
    
    




    
                    
}

