
package BlockBuster;

import java.util.ArrayList;
import java.util.List;

public class Creeper  {

    
    public Creeper() {
        
    }
    
    private static List<Blocks> blocks= new ArrayList();// list of blocks 
    private static int playerX ;// keeps track of playable character's x coordinate
    private static int playerY ;// keeps track of playable character's y coordinate
    private static int creeperX;// keeps track of creeper's x coordinate
    private static int creeperY;// keeps track of creeper's y coordinate
    private static int creeperHitPoints = 10; //hit points the creeper has
    private static int creeperHunger = 0;// level of hunger the creeper has, higher hunger level mean more hungry
    private static BlockPanel blockPanel= new BlockPanel();
    private static boolean superCharged=false;// if true creeper is supercharged and blows up bigger
    private static AStar star;//access to Astar class
    private static int xSize;// how many  blocks horizontal the game is 
    private static int damage=0;// how many hits the creeper has
    private static int strength=100;//strength of hits
   private static int direction;// direction to wander in
   
   //set global variables equal to passed in values
public static void setEqual(int x, int y, int counter, int index, int X,int Y,
        int health, int hunger,List<Blocks> list, int width, int dir, boolean supercharged){
direction=dir;
        damage=0;
    	creeperX=x;
        creeperY=y;
        playerX=X;
        playerY=Y;
       creeperHitPoints=health;
       creeperHunger=hunger;
        xSize=width;
         blocks=list;
         superCharged=false;
         if(supercharged==true){
         superCharged=true;
         }
}   
//displays information to command line if needed
public static void displayToTerminal() {
	System.out.println("PlayerX: "+playerX);
	System.out.println("PlayerY: "+playerY);
	System.out.println("CreeperX: "+creeperX);
	System.out.println("CreeperY: "+creeperY);
	System.out.println("Creeper hit Points: "+creeperHitPoints);
	System.out.println("hunger: "+creeperHunger);
}    
//changes hunger and health if in sun
public static void timeAndHungerControls() {
	
// if health low supercharge creeper
if(creeperHitPoints<=2){
superCharged=true;
}

 //20% chance for hunger to change with random int
	
	if(Math.random() <= .05 ) {
		creeperHunger++;
	} 
	//keeps hunger from becoming too large
	if(creeperHunger>=10) {
		creeperHunger=10;
        }
      }
//movement used to chase player
public static void chaseMovement() {
    if( Math.abs(creeperY-playerY)+Math.abs(creeperX-playerX)<=8){
switch(star.planPath( creeperX,  creeperY,  playerX,  playerY,  blocks, xSize)){
    case left->creeperX--;
    case right->creeperX++;
    case up->creeperY--;
    case down->creeperY++;
    case mine-> wanderMovement();
}
    }
         
}
//attacks player if possible
public static void attack(){
if(playerX==creeperX&&Math.abs(playerY-creeperY)<=1){
creeperHitPoints++;
creeperHunger--;
damage++;
}else if (playerY==creeperY&&Math.abs(playerX-creeperX)<=1){
creeperHitPoints++;
creeperHunger--;
damage++;
}
}
//movment used when in run state
public static void runMovement(int x) {
if(creeperX-playerX>=0 && creeperY-playerY>=0){
    System.out.println("down right");
if(blocks.get(creeperX+creeperY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+creeperY*xSize+1).getBlocktype()==BlockType.sky){
    creeperX++;
}else if(blocks.get(creeperX+(creeperY+1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+(creeperY+1)*xSize).getBlocktype()==BlockType.sky){
creeperY++;}
}else if(creeperX-playerX>=0 && creeperY-playerY<=0){
    System.out.println("up right");
if(blocks.get(creeperX+creeperY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+creeperY*xSize+1).getBlocktype()==BlockType.sky){
    creeperX++;
}else if(blocks.get(creeperX+(creeperY-1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+(creeperY-1)*xSize).getBlocktype()==BlockType.sky){
creeperY--;}
    }else if(creeperX-playerX<=0 && creeperY-playerY>=0){
        System.out.println("left down");
if(blocks.get(creeperX+creeperY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+creeperY*xSize-1).getBlocktype()==BlockType.sky){
    creeperX--;
}else if(blocks.get(creeperX+(creeperY+1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+(creeperY+1)*xSize).getBlocktype()==BlockType.sky){
creeperY++;}
    }else if(creeperX-playerX<=0 && creeperY-playerY<=0){
        System.out.println("left up");
     if(blocks.get(creeperX+creeperY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+creeperY*xSize-1).getBlocktype()==BlockType.sky){
    creeperX--;
}else if(blocks.get(creeperX+(creeperY-1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+(creeperY-1)*xSize).getBlocktype()==BlockType.sky){
creeperY--;}
}else {
        System.out.println("wander");
wanderMovement();
}
}
//movement used to wander
public static void wanderMovement() {
if(direction==1&&Math.random()<.75 &&(blocks.get(creeperX+creeperY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+creeperY*xSize+1).getBlocktype()==BlockType.sky)){
creeperX++;
direction=1;
}else if(direction==0 && Math.random()<.75 &&(blocks.get(creeperX+creeperY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+creeperY*xSize-1).getBlocktype()==BlockType.sky)){
creeperX--;
direction=0;
}else if(direction==0 && (blocks.get(creeperX+creeperY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+creeperY*xSize+1).getBlocktype()==BlockType.sky)){
creeperX++;
direction=1;
}else if(direction==1 && blocks.get(creeperX+creeperY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(creeperX+creeperY*xSize-1).getBlocktype()==BlockType.sky){
creeperX--;
direction=0;
}
}  
public static abstract class State {
       
        //empty constructor
        public State() {}
        //methods
        public abstract void enter();
        public abstract void exit();
        public abstract void environment();
        public abstract void movement();
        public abstract int updateAndCheckTransitions();
        
    }
    
    
   // this class represent the creeper taking a chasing action 
    // the creeper will chase the playable character faster as hunger becomes higher 
    public static class Chase extends State {
	
        public Chase() {
           
            super();
        }
        
        
        public void enter() {
            System.out.println("The creeper is chasing you!");
        }
        public void exit() {            
        	System.out.println("chase exit");
        }
       
        public void environment(){
        timeAndHungerControls();
        }
         
        public void movement() {
             attack();
        	chaseMovement();
    }
        public int updateAndCheckTransitions() {
            //if too far away from player wander
         if(Math.abs(playerX-creeperX)+Math.abs(playerY-creeperY)>8){
                    return 1;                   
         }
         //keep chasing otherwise
        		return 0;
        	
              
    }
        
        
    }
      
    // this class represent the creeper taking a wander action 
    // the creeper will wander left and right
   public static class Wander extends State {
        public Wander() {
            super();
        }
        
        public void enter() {
            System.out.println("The creeper is wandering");
        }
        public void exit() {            
        	System.out.println("wander exit");
        }
                	                    
       public void environment(){
       timeAndHungerControls();
       }
        //moves creeper
        public void movement() {
        	wanderMovement();
        	//displayToTerminal();
        }
        public int updateAndCheckTransitions() {  
        	//chance of creeper switching to chasing state increases as distance decreases and hunger increases
        	if (Math.abs(playerX-creeperX)+ Math.abs(playerY-creeperY)- creeperHunger<= Math.random()*12 ) {
          	  return 0;
            }
                //else stay wander
                return 1;
        }            
         
    } 

   //functionality of the Creeper is in this main
    public static Mobs call(int x, int y, int state, int counter, int index, boolean sun, int X,int Y, int health, int hunger,boolean burning ,List<Blocks> list, int width, int dir){
         //set global variables equal to passed in values
        setEqual(x,y,counter,index,X,Y,health,hunger,list,width,dir, burning);
        counter++;
        // two states:  chase, wander
        int numberOfStates = 2;
        
        State[] states = new State[numberOfStates];
        states[0] = new Chase();
        states[1] = new Wander();
        
        
//variables keep track of the state the creeper is in
 int currentState = state;
 
       
       	
       	
       	//checks internal and external environment queues to see if the state will change or remain the same
            int nextState = states[currentState].updateAndCheckTransitions();
            //exits current state and enters new state
            //counter is for timeout
            if (nextState != currentState&& counter>=3) {
            	//prints out exit state 
                //states[currentState].exit();
                //changes curent state to next state
                currentState = nextState;  
             // prints out state so user is aware of the action the creeper may take
               // states[currentState].enter();
                counter=0;
            }
            //moves the creeper 
        states[currentState].movement();
       	//extra movement chance for creeper hunger level 0-50% chance;
       	if(Math.random()*hunger>=5) {
       		states[currentState].movement();
       	}
              states[currentState].environment();
              //returns Mob so blockpanel can update
             Mobs creeper= new Mobs(creeperX,creeperY,currentState, counter, creeperHunger, creeperHitPoints, superCharged, damage*strength, direction);
            return creeper;
        }
    
    
    




    
                    
}

