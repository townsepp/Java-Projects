
package BlockBuster;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BlockPanel extends javax.swing.JPanel implements ActionListener{
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    int screenWidth= screenSize.width;
    int screenHeight= screenSize.height;
    private Zombie zombieClass=new Zombie();
    private Skeleton skeletonClass=new Skeleton();
    private Creeper creeperClass= new Creeper();
    private Spider spiderClass= new Spider();
    private List<Blocks> blocks;
    private ArrayList<Blocks> newChest = new ArrayList<Blocks>();
    private ArrayList<ArrayList<Blocks>> chests= new ArrayList<ArrayList<Blocks>>();
    private ArrayList<BlockType> recipes= new ArrayList();
    private ArrayList<Blocks> recipeBook= new ArrayList<Blocks>();
    private ArrayList<BlockType> craftingRecipes= new ArrayList();
    private ArrayList<Blocks> craftingRecipeBook= new ArrayList<Blocks>();
    private ArrayList<BlockType> furnaceRecipes= new ArrayList();
    private ArrayList<Blocks> furnaceRecipeBook= new ArrayList<Blocks>();
    private ArrayList<Mobs> zombies= new ArrayList<Mobs>();
    private ArrayList<Mobs> creepers= new ArrayList<Mobs>();
    private ArrayList<Mobs> skeletons= new ArrayList<Mobs>();
    private ArrayList<Mobs> spiders= new ArrayList<Mobs>();
    private int xSize=100;
    private int ySize=30;
    private int yMidSize=6;
    private int skyLimit=15;
    private int blockSize=50;
    private final Blocks[] inventory=new Blocks[10];
    private final Blocks[] offHandInventory=new Blocks[60];
    private final int[] handleX= new int[4];
    private final int[] handleY= new int[4];
    private final Color brown= new Color(102,51,0);
    private final Color lightBrown= new Color(150,102,0);
    private final Color darkerGrey= new Color(50,50,50);
    private int playerX;
    private int playerY;
    private int mobOffsetX;
    private int mobOffsetY;
    boolean craftOptionAvailable=false;
    private int topBlock;
    private int bottomBlock;
    private int rightBlock;
    private int leftBlock;
    private int highlightedItem;
    private Blocks blockToBuild;
    private final Blocks[] furnaceIngredients= new Blocks[2];
    private final Blocks[] craftingIngredients= new Blocks[4];
    private final Blocks[] equippedArmor= new Blocks[4];
    private ButtonCommands direction;
    private boolean inventoryMode;
    private boolean craftingMode;
    private boolean furnaceMode;
    private boolean chestMode;
    private int inHandItem;
    private int hunger=100;
    private double health =100;
    private int mobMoveSpeed=10;//How many 100ms are between each movement for the mobs
    //to watch the AI close I would increase this so it is easier to see
    private int Timer=1;
    private int dayLength=200;// How many 100ms long the days and nighta are
    private boolean sun =false;//if it is day sun is true
    private int sunMoonOffset=0;//keeps sun and moon drawn at the right position
    private boolean enhancedCrafting=false;
    private Blocks emptyBlock= new Blocks(0,0,BlockType.empty, 0,0);
    private boolean isDead=true;
    private boolean gameStarted=false;
    private int currentChest;
    private int nextChestIndex;
   
    
   /*
    the driver for this class is action performed every 100ms it will rerun and reset the graphics,
    increment timer, change time of day, and perform mob actions when timer is equal to the mob move 
    speed. 
    
    the mobs are kept in ther own list(zombies, seletons, spiders, crepers) and when timer==mobMoveSpeed
    for each mob in the list it run the repective class's "call" method whihh is the FSM and will
    update state, move mobs, attack, etc. in each class chaseMovement() will run the Astar class 
    to find a path and return the direction to follow that path
    
    if you want to Make yourself not able to die there is one line in the zombieAction(), skeletonAction(),
    creeperAction(), and spiderAction() methods that says"isDead=true;". you can comment out these lines
    and will not die. i have commented above it to make it easy to see
    
    if you want to change the number of mobs to look at the individually it should be very easy
    there are 3 things you have to change. one is in the Blockpanel class initialSetting()method 
    and actionPerformed() 
     a line called spawnMobs(int zombies,int skeletons,int creepers,int spider)
    the other is in the MainFrame class in the keyPressed() method a method called 
    respawn( int zombies, int skeletons,int creepers,int spider). they are all set to 5 
    currently, change them however you need to look at the AI if you wish to do that.
    
    so you know what is hitting you, if you have no armor spider deal will take 1 heart, 
    skeltons 2(ranged), zombies 3, and creepers 10. so if you the start menu pops up right
    after starting you probobly spawned on a creeper
    
    Controls:
    When starting the game in the menu press R to start a new game, but everytime you die you must
    press space to respawn, not R to start again or Q to quit( it is still a little bugged at the moment).
    from there A,S,D,W are used to move, "enter" is used to use tool or block in hand(if tool it 
    will mine the block or hit mob the direction you are facing, if block it will place block in direction
    you are facing). holding Shift and A,S,D,W will change direction without moving. pressing 1 and 2 in 
    the regular game screen will allow you to move between your items.    Presing C will 
    take you to the crafting scren where you can use A,S,D,W to move hightlighted inventory item, pressing 
    space will move the item into the crafting ingredients if a block appear in the space to the right of the
    ingredients then if you hit enter it will craft that block and add it to inventory(ex: if you put wood
    block it will make 4 planks, 2 planks will make 4 sticks, 1 stick and 2 diamond will make diamond sword)
    pressing R will put the items in the crafting ingredient back into your inventory, 
    pressing 1 on an item when in crafting 
    while in crfting or inventory screens 
    screen will decrement its quantity by 1, and pressing 2 will remove the stack from inventory.
    pressing shift and 1,2,3,4 will take off piece of armor if equipped with 1,2,3,4 mapped to 
    helmet,chestplate,pants,boots respectively
    pressing i will open your full inventory with no crafting should work the same as crafting screen. 
    */
    
    
    
    
    /*these are the only methods significantly related to the AI , however they are not necesary to go over
    to understand what is going on.*/
    @Override
    public void actionPerformed(ActionEvent actionEvent){
    Timer++;
        if(Timer%mobMoveSpeed==0){
           // System.out.println("AP: "+blocks.get(14*xSize+17).getChestIndex());
        for(int i=0; i<zombies.size();i++){
           zombies.set(i,zombieAction(i));
        if(zombies.get(i).getHealth()<=0){
    zombies.remove(i);}}
    for(int i=0; i<creepers.size();i++){
       creepers.set(i,creeperAction(i));
    if(creepers.get(i).getHealth()<=0){
    creepers.remove(i);}}
    for(int i=0; i<skeletons.size();i++){
    skeletons.set(i,skeletonAction(i));
    if(skeletons.get(i).getHealth()<=0){
    skeletons.remove(i);}}
    for(int i=0; i<spiders.size();i++){
   spiders.set(i, spiderAction(i));
    if(spiders.get(i).getHealth()<=0){
    spiders.remove(i);}}   
    }
        if(Timer%dayLength==0){
        sun=!sun;
        if(!sun){
            //change this to set new amount of mobs
        spawnMobs(5,5,5,5);
        }
        Timer=1;
        }if(gameStarted){
            //can turn gravity on but cant climb up yet
        //gravity();
        }
        
    repaint();
    }
    public void attackMobs(int damage){
    for(int i=0; i<zombies.size();i++){
    if(playerX==zombies.get(i).getX()&&playerY-zombies.get(i).getY()<=1 &&playerY-zombies.get(i).getY()>=0&& direction==ButtonCommands.up){
zombies.get(i).setHealth(zombies.get(i).getHealth()-damage);
}else if(playerX==zombies.get(i).getX()&&playerY-zombies.get(i).getY()==-1&& direction==ButtonCommands.down){
zombies.get(i).setHealth(zombies.get(i).getHealth()-damage);
}else if (playerY==zombies.get(i).getY()&&playerX-zombies.get(i).getX()==1&& direction==ButtonCommands.left){
zombies.get(i).setHealth(zombies.get(i).getHealth()-damage);
}else if (playerY==zombies.get(i).getY()&&playerX-zombies.get(i).getX()==-1&& direction==ButtonCommands.right){
zombies.get(i).setHealth(zombies.get(i).getHealth()-damage);
}
    if(zombies.get(i).getHealth()<=0){
    zombies.remove(i);
}
    }
    
    for(int i=0; i<skeletons.size();i++){
    if(playerX==skeletons.get(i).getX()&&playerY-skeletons.get(i).getY()<=1 &&playerY-skeletons.get(i).getY()>=0&& direction==ButtonCommands.up){
skeletons.get(i).setHealth(skeletons.get(i).getHealth()-damage);
}else if(playerX==skeletons.get(i).getX()&&playerY-skeletons.get(i).getY()==-1&& direction==ButtonCommands.down){
skeletons.get(i).setHealth(skeletons.get(i).getHealth()-damage);
}else if (playerY==skeletons.get(i).getY()&&playerX-skeletons.get(i).getX()==1&& direction==ButtonCommands.left){
skeletons.get(i).setHealth(skeletons.get(i).getHealth()-damage);
}else if (playerY==skeletons.get(i).getY()&&playerX-skeletons.get(i).getX()==-1&& direction==ButtonCommands.right){
skeletons.get(i).setHealth(skeletons.get(i).getHealth()-damage);
}
    if(skeletons.get(i).getHealth()<=0){
    skeletons.remove(i);
}
    }
    
    for(int i=0; i<creepers.size();i++){
    if(playerX==creepers.get(i).getX()&&playerY-creepers.get(i).getY()<=1 &&playerY-creepers.get(i).getY()>=0&& direction==ButtonCommands.up){
creepers.get(i).setHealth(creepers.get(i).getHealth()-damage);
}else if(playerX==creepers.get(i).getX()&&playerY-creepers.get(i).getY()==-1&& direction==ButtonCommands.down){
creepers.get(i).setHealth(creepers.get(i).getHealth()-damage);
}else if (playerY==creepers.get(i).getY()&&playerX-creepers.get(i).getX()==1&& direction==ButtonCommands.left){
creepers.get(i).setHealth(creepers.get(i).getHealth()-damage);
}else if (playerY==creepers.get(i).getY()&&playerX-creepers.get(i).getX()==-1&& direction==ButtonCommands.right){
creepers.get(i).setHealth(creepers.get(i).getHealth()-damage);
}
    if(creepers.get(i).getHealth()<=0){
    creepers.remove(i);
}
    }
    
    for(int i=0; i<spiders.size();i++){
    if(playerX==spiders.get(i).getX()&&playerY-spiders.get(i).getY()<=1 &&playerY-spiders.get(i).getY()>=0&& direction==ButtonCommands.up){
spiders.get(i).setHealth(spiders.get(i).getHealth()-damage);
}else if(playerX==spiders.get(i).getX()&&playerY-spiders.get(i).getY()==-1&& direction==ButtonCommands.down){
spiders.get(i).setHealth(spiders.get(i).getHealth()-damage);
}else if (playerY==spiders.get(i).getY()&&playerX-spiders.get(i).getX()==1&& direction==ButtonCommands.left){
spiders.get(i).setHealth(spiders.get(i).getHealth()-damage);
}else if (playerY==spiders.get(i).getY()&&playerX-spiders.get(i).getX()==-1&& direction==ButtonCommands.right){
spiders.get(i).setHealth(spiders.get(i).getHealth()-damage);
}
    if(spiders.get(i).getHealth()<=0){
    spiders.remove(i);
}
    }
    }
    public Mobs zombieAction(int index){
            Mobs zombie= new Mobs(0,0,0,0,0,0, true,0,0);
            zombie=zombieClass.call(zombies.get(index).getX(), zombies.get(index).getY(), 
            zombies.get(index).getState(), zombies.get(index).getCounter(), 
            index,sun,playerX,playerY, zombies.get(index).getHealth(),zombies.get(index).getHunger(), zombies.get(index).isBurning(),
            blocks, xSize, zombies.get(index).getDirection());
            if(protection()==0){
                health-=zombie.getDamage();
            }else{
            health-=zombie.getDamage()-zombie.getDamage()*protection()/16; }   
            if(health<=0){
                //comment out the line below to make your self not able to die 1/4
           isDead=true;
        }
        return zombie;
    }
    public Mobs skeletonAction(int index){
     Mobs skeleton= new Mobs(0,0,0,0,0,0, true,0,0);
            skeleton=skeletonClass.call(skeletons.get(index).getX(), skeletons.get(index).getY(), 
            skeletons.get(index).getState(), skeletons.get(index).getCounter(), 
            index,sun,playerX,playerY, skeletons.get(index).getHealth(),skeletons.get(index).getHunger(), skeletons.get(index).isBurning(),
            blocks, xSize, skeletons.get(index).getDirection());
            if(protection()==0){
                health-=skeleton.getDamage();
            }else{
     health-=skeleton.getDamage()-skeleton.getDamage()*protection()/16; }         
        if(health<=0){
            //comment out the line below to make your self not able to die 2/4
           isDead=true;
        }
        return skeleton;
    
    }
    public Mobs creeperAction(int index){
         Mobs creeper= new Mobs(0,0,0,0,0,0, true,0,0);
            creeper=creeperClass.call(creepers.get(index).getX(), creepers.get(index).getY(), 
            creepers.get(index).getState(), creepers.get(index).getCounter(), 
            index,sun,playerX,playerY, creepers.get(index).getHealth(),creepers.get(index).getHunger(), creepers.get(index).isBurning(),
            blocks, xSize, creepers.get(index).getDirection());
            if(protection()==0){
                health-=creeper.getDamage();
            }else{
              
                health-=creeper.getDamage()-creeper.getDamage()*protection()/16;
            }
            if(creeper.getDamage()>0){
                int range=3;
                int offset=1;
                if(creeper.isBurning()){
                range=5;
                offset=2;
                }
                
            for(int i=0;i<range;i++){
            for(int j=0; j<range;j++){
            blocks.get(creeper.getX()+creeper.getY()*xSize+i-offset+(j-offset)*xSize).setEqual(emptyBlock);
            }
            }
            creeper.setHealth(0);
            }
        if(health<=0){
            //comment out the line below to make your self not able to die 3/4
           isDead=true;
        }
        return creeper;
    }
    public Mobs spiderAction(int index){
         Mobs spider= new Mobs(0,0,0,0,0,0, true,0,0);
            spider=spiderClass.call(spiders.get(index).getX(), spiders.get(index).getY(), 
            spiders.get(index).getState(), spiders.get(index).getCounter(), 
            index,sun,playerX,playerY, spiders.get(index).getHealth(),spiders.get(index).getHunger(), spiders.get(index).isBurning(),
            blocks, xSize, spiders.get(index).getDirection());
            if(protection()==0){
                health-=spider.getDamage();
            }else{
        health-=spider.getDamage()-spider.getDamage()*protection()/16; }   
            if(health<=0){
                //comment out the line below to make your self not able to die 4/4
           isDead=true;
        }
        return spider;
    }
    public void spawnMobs(int zom, int skel, int creep, int spid){
        int dir=0;
        int size=zombies.size();
        for(int i=0; i<size; i++){
        zombies.remove(0);
        }
    for(int i=0;i<zom;i++){
        if(Math.random()<.5){
            dir=1;
        }else{
         dir=0;
        }
        Mobs zombie= new Mobs(10+(int)(Math.abs(Math.random()-.05)*xSize), 14,0, 0,0,10,false,0, dir);
        zombies.add(zombie);
        }
    
    size=skeletons.size();
        for(int i=0; i<size; i++){
        skeletons.remove(0);
        }
    for(int i=0;i<skel;i++){
        if(Math.random()<.5){
            dir=1;
        }else{
         dir=0;
        }
        Mobs skeleton= new Mobs(10+(int)(Math.abs(Math.random()-.05)*xSize), 14,0, 0,0,10,false,0, dir);
        skeletons.add(skeleton);
        }    
    
    size=creepers.size();
        for(int i=0; i<size; i++){
        creepers.remove(0);
        }
    for(int i=0;i<creep;i++){
        if(Math.random()<.5){
            dir=1;
        }else{
         dir=0;
        }
        Mobs creeper= new Mobs(10+(int)(Math.abs(Math.random()-.05)*xSize), 14,0, 0,0,10,false,0, dir);
        creepers.add(creeper);
        }
    
    size=spiders.size();
        for(int i=0; i<size; i++){
        spiders.remove(0);
        }
    for(int i=0;i<spid;i++){
        if(Math.random()<.5){
            dir=1;
        }else{
         dir=0;
        }
        Mobs spider= new Mobs(10+(int)(Math.abs(Math.random()-.05)*xSize), 14,0, 0,0,10,false,0, dir);
        spiders.add(spider);
        }
    
    }
    public void initialSettings(){
     
        inHandItem=0;
     highlightedItem=0;
        health=100;
        hunger=100;
        inventoryMode=false;
        craftingMode=false;
        furnaceMode=false;
        chestMode=false;
            blocks=new ArrayList();
            makeBasicRecipes();
            makeCraftingRecipes();
            makeFurnaceRecipes();
            playerX=18;
            playerY=14;
            mobOffsetX=0;
        mobOffsetY=-4;
        topBlock=13*xSize+18;
        bottomBlock=15*xSize+18;
        direction=ButtonCommands.left;
        rightBlock=14*xSize+19;
        leftBlock=14*xSize+17;
        
       //modify these numbers to change amount of mobs
        spawnMobs(0,0,0,0);
        
        
        for(int i=0; i<10;i++){
            Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
             block.setSecondaryBlockType(BlockType.empty);
        inventory[i]=block;
        }
        for(int i=0; i<1;i++){
        Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
             block.setSecondaryBlockType(BlockType.empty);
             blockToBuild=block;}
        for(int i=0; i<60;i++){
            Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
            block.setSecondaryBlockType(BlockType.empty);
        offHandInventory[i]=block;
        }
        for(int i=0; i<4;i++){
            Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
            block.setSecondaryBlockType(BlockType.empty);
        craftingIngredients[i]=block;
        }
        for(int i=0; i<2;i++){
            Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
            block.setSecondaryBlockType(BlockType.empty);
        furnaceIngredients[i]=block;
        }
        for(int i=0; i<4;i++){
            Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
            block.setSecondaryBlockType(BlockType.empty);
        equippedArmor[i]=block;
        }
       inventory[0].setBlocktype(BlockType.sword);
       inventory[0].setSecondaryBlockType(BlockType.stone);
       inventory[0].setQuantity(1);
       inventory[0].setDurability(2000);
       inventory[0].setSelected(true);
       
       inventory[1].setBlocktype(BlockType.pick);
       inventory[1].setSecondaryBlockType(BlockType.diamondShard);
       inventory[1].setQuantity(1);
       inventory[1].setDurability(5000);
       
       inventory[2].setBlocktype(BlockType.axe);
       inventory[2].setSecondaryBlockType(BlockType.goldOre);
       inventory[2].setQuantity(1);
       inventory[2].setDurability(1000);
       
       inventory[3].setBlocktype(BlockType.hoe);
       inventory[3].setSecondaryBlockType(BlockType.plank);
       inventory[3].setQuantity(1);
       inventory[3].setDurability(1000);
       
       inventory[4].setBlocktype(BlockType.shovel);
       inventory[4].setSecondaryBlockType(BlockType.ironOre);
       inventory[4].setQuantity(1);
       inventory[4].setDurability(4000);
       
       inventory[5].setBlocktype(BlockType.craftingTable);
       inventory[5].setSecondaryBlockType(BlockType.empty);
       inventory[5].setQuantity(1);
       inventory[5].setDurability(4000);
       
       inventory[6].setBlocktype(BlockType.furnace);
       inventory[6].setSecondaryBlockType(BlockType.empty);
       inventory[6].setQuantity(1);
       inventory[6].setDurability(4000);
       
       nextChestIndex=1;
       inventory[7].setBlocktype(BlockType.chest);
       inventory[7].setSecondaryBlockType(BlockType.empty);
       inventory[7].setQuantity(1);
       inventory[7].setDurability(4000);
       inventory[7].setChestIndex(0);
       nextChestIndex++;
       
       inventory[9].setBlocktype(BlockType.chest);
       inventory[9].setSecondaryBlockType(BlockType.empty);
       inventory[9].setQuantity(1);
       inventory[9].setDurability(4000);
       inventory[9].setChestIndex(0);
       nextChestIndex++;
       
       for(int i=0; i<9; i++){
          Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
            block.setSecondaryBlockType(BlockType.empty);
       newChest.add(block);
       }
       
       
       chests.add(newChest);
       
       
       inventory[8].setBlocktype(BlockType.ironOre);
       inventory[8].setSecondaryBlockType(BlockType.empty);
       inventory[8].setQuantity(3);
       inventory[8].setDurability(4000);
       
        setBlocks();
        isDead=false;
        gameStarted=true;
        
    }
    //beyond this is not important to the AI for the most part
   
    
    
    
    public BlockPanel() {
        initComponents();
        }
    public void start(){
    Timer timer = new Timer(100, this);
        timer.start();}
    @Override
    public void paintComponent(Graphics graphics){
     super.paintComponent(graphics);
     if(isDead){
     drawStartScreen(graphics);
     }else if(!inventoryMode && !craftingMode && !furnaceMode&& !chestMode){
 drawBlocks(graphics);
 drawMobs(graphics);
 drawToolBar(graphics);
 drawPlayer(graphics);
 drawHealth(graphics);
 drawHunger(graphics);
 if(sun){
 drawSun(graphics);}
 else{
 drawMoon(graphics);}
     }else if(!craftingMode&& !furnaceMode&& !chestMode){
     drawFullInventory(graphics,0,0);
     drawToolBar(graphics);
     }else if( !furnaceMode && !chestMode){
     drawCraftingBook(graphics);
     }else if(!chestMode){
    drawFurnaceInterface(graphics,0,0);
    }else{
     drawChestInventory(graphics,0,0,blocks.get(currentChest).getChestIndex());
     }
 
 }
    public void drawStartScreen(Graphics graphics){
        graphics.setColor(Color.gray);
        graphics.fillRect(0,0,screenWidth, screenHeight);
        
        graphics.setColor(Color.black);
        graphics.drawRect(175,75,1400,250);
        graphics.drawRect(175,375,1400,250);
        graphics.drawRect(175,675,1400,250);
        graphics.setColor(Color.darkGray);
        graphics.fillRect(200,100,1400,250);
        graphics.fillRect(200,400,1400,250);
        graphics.fillRect(200,700,1400,250);
        graphics.setColor(Color.orange);
        Font defaultFont = new Font( "Ariel", Font.PLAIN, 12 );
        Font stringFont = new Font( "Ariel", Font.PLAIN, 100 );
        graphics.setFont( stringFont );
    graphics.drawString("Press R to Start New", 300, 250);
    graphics.drawString("Press Space to Respawn", 300, 550);
    graphics.drawString("Press Back Space to Quit", 300, 850);
    graphics.setFont( defaultFont );
    }
    public void drawMobs(Graphics graphics){
    drawSpider(graphics);
 drawZombie(graphics);
 drawSkeleton(graphics);
 drawCreeper(graphics);
    }
    public void gravity(){
    if(blocks.get(playerX+(playerY+1)*xSize).getBlocktype()==BlockType.sky||
            blocks.get(playerX+(playerY+1)*xSize).getBlocktype()==BlockType.empty){
        ButtonCommands temp= direction;
    move(ButtonCommands.down);
    direction=temp;
    }
    for(int i=0; i<zombies.size();i++){
    if(blocks.get(zombies.get(i).getX()+(zombies.get(i).getY()+1)*xSize).getBlocktype()==BlockType.sky||
            blocks.get(zombies.get(i).getX()+(zombies.get(i).getY()+1)*xSize).getBlocktype()==BlockType.empty){
        zombies.get(i).setY(zombies.get(i).getY()+1);
    }
    }
    
    for(int i=0; i<skeletons.size();i++){
    if(blocks.get(skeletons.get(i).getX()+(skeletons.get(i).getY()+1)*xSize).getBlocktype()==BlockType.sky||
            blocks.get(skeletons.get(i).getX()+(skeletons.get(i).getY()+1)*xSize).getBlocktype()==BlockType.empty){
        skeletons.get(i).setY(skeletons.get(i).getY()+1);
    }
    }
    
    for(int i=0; i<creepers.size();i++){
    if(blocks.get(creepers.get(i).getX()+(creepers.get(i).getY()+1)*xSize).getBlocktype()==BlockType.sky||
            blocks.get(creepers.get(i).getX()+(creepers.get(i).getY()+1)*xSize).getBlocktype()==BlockType.empty){
        creepers.get(i).setY(creepers.get(i).getY()+1);
    }
    }
    
    for(int i=0; i<spiders.size();i++){
    if(blocks.get(spiders.get(i).getX()+(spiders.get(i).getY()+1)*xSize).getBlocktype()==BlockType.sky||
            blocks.get(spiders.get(i).getX()+(spiders.get(i).getY()+1)*xSize).getBlocktype()==BlockType.empty){
        spiders.get(i).setY(spiders.get(i).getY()+1);
    }
    }
    }
    public void returnToStart(ButtonCommands key){
    switch(key){
        case left -> {
            for(int i=0; i<blocks.size();i++){
            blocks.get(i).setX(blocks.get(i).getX()+blockSize);
            }
            moveCoordinate(1,0);
            rightBlock-=1;
            leftBlock-=1;
            topBlock-=1;
            bottomBlock-=1;
            direction=ButtonCommands.left;
            }
        case right -> {
            for(int i=0; i<blocks.size();i++){
            blocks.get(i).setX(blocks.get(i).getX()-blockSize);
            }
            moveCoordinate(-1,0);
         rightBlock+=1;
            leftBlock+=1;
            topBlock+=1;
            bottomBlock+=1;
            direction=ButtonCommands.right;
            }
        case up -> {
            for(int i=0; i<blocks.size();i++){
            blocks.get(i).setY(blocks.get(i).getY()-blockSize);
            }
            moveCoordinate(0,-1);
            topBlock-=xSize;
            bottomBlock-=xSize;
            rightBlock-=xSize;
            leftBlock-=xSize;
            direction=ButtonCommands.up;
            }
        case down -> {
            for(int i=0; i<blocks.size();i++){
            blocks.get(i).setY(blocks.get(i).getY()+blockSize);
            }
            moveCoordinate(0,1);
            topBlock+=xSize;
            bottomBlock+=xSize;
            rightBlock+=xSize;
            leftBlock+=xSize;
            direction=ButtonCommands.down;
            }
    }
    }
    public void respawn(int zom, int skel, int creeper, int spider){
        isDead=false;
        while(playerX!=18 || playerY!=14){
        if(playerX>18){
        returnToStart(ButtonCommands.left);
        }
        if(playerX<18){
        returnToStart(ButtonCommands.right);
        }
        if(playerY>14){
        returnToStart(ButtonCommands.down);
        }
        if(playerY<14){
        returnToStart(ButtonCommands.up);
        }
        }
        health=100;
        hunger=100;
        inHandItem=0;
        highlightedItem=0;
        inventoryMode=false;
        craftingMode=false;
        topBlock=13*xSize+18;
        bottomBlock=15*xSize+18;
        direction=ButtonCommands.left;
        rightBlock=14*xSize+19;
        leftBlock=14*xSize+17; 
        spawnMobs(zom,skel,creeper,spider);
        
        for(int i=0; i<10;i++){
            Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
             block.setSecondaryBlockType(BlockType.empty);
        inventory[i].setEqual(block);
        }
        for(int i=0; i<1;i++){
        Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
             block.setSecondaryBlockType(BlockType.empty);
             blockToBuild.setEqual(block);}
        for(int i=0; i<60;i++){
            Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
            block.setSecondaryBlockType(BlockType.empty);
        offHandInventory[i].setEqual(block);
        }
        for(int i=0; i<4;i++){
            Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
            block.setSecondaryBlockType(BlockType.empty);
        craftingIngredients[i].setEqual(block);
        }
        for(int i=0; i<4;i++){
            Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
            block.setSecondaryBlockType(BlockType.empty);
        equippedArmor[i].setEqual(block);
        }
        
        inventory[0].setBlocktype(BlockType.pick);
        inventory[0].setSecondaryBlockType(BlockType.ironOre);
        inventory[0].setQuantity(1);
        inventory[0].setDurability(3000);
        inventory[0].setSelected(true);
    }
    public int typeWeapon(BlockType type){
        int strength=0;
        switch(inventory[inHandItem].getSecondaryBlockType()){
            case diamond->strength=5;
            case iron->strength=4;
            case gold->strength=3;
            case stone->strength=2;
            case plank->strength=1;
        }
    if(type==inventory[inHandItem].getBlocktype()){
    strength*=2;
    }
    return strength;
    }
    public void deleteBlocks(){
    for(Blocks block: blocks){
    blocks.remove(block);
    }
        System.out.println(blocks.size());
    }
    public void setBlocks(){
        if(gameStarted==true){
        deleteBlocks();
        }
        setUpperLevel();
        setMiddleLevel();
       setLowerLevelBlocks();
       moveBlocks();
    emptyBlock.setSecondaryBlockType(BlockType.empty);
    blocks.get(14*xSize+17).setBlocktype(BlockType.chest);
    blocks.get(14*xSize+17).setChestIndex(3);
    for(int i=0; i<9; i++){
          Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
            block.setSecondaryBlockType(BlockType.empty);
       newChest.add(block);
       }
       
              chests.add(newChest);
       chests.add(newChest);

       chests.add(newChest);
    }
    public void setLowerLevelBlocks(){
    int blockNumber=0;
       
    for(int i=0; i<ySize;i++){
    for(int j=0; j<xSize;j++){
        Blocks block= new Blocks(j*blockSize,blockSize*yMidSize+i*blockSize,BlockType.empty, 100,1);
        Random random =new Random();
        int tempInt=random.nextInt(100)+1;
        int randomInt=random.nextInt(100)+1;
        if(randomInt<50 ){
            if(randomInt<25 && blockNumber%xSize!=0){
        block.setBlocktype(blocks.get(xSize*skyLimit+xSize*yMidSize+i*xSize+j-1).getBlocktype());
        block.setDurability(blocks.get(xSize*skyLimit+xSize*yMidSize+i*xSize+j-1).getDurability());
       blocks.add(block);
       continue;
            }else if(randomInt<50 && blockNumber > xSize){
        block.setBlocktype(blocks.get(xSize*skyLimit+xSize*yMidSize+i*xSize+j-xSize).getBlocktype());
        block.setDurability(blocks.get(xSize*skyLimit+xSize*yMidSize+i*xSize+j-xSize).getDurability());
        blocks.add(block);
        continue;
            }
            
        }
        
        if(tempInt==1){
    block.setBlocktype(BlockType.diamond);
    block.setDurability(100);
    }else if (tempInt==2||tempInt==3){
       block.setBlocktype(BlockType.gold);
        block.setDurability(5);
    }else if (tempInt>3&&tempInt<=8){
        block.setBlocktype(BlockType.iron);
        block.setDurability(50);
    }else if (tempInt>8&&tempInt<=12){
        block.setBlocktype(BlockType.redstone);
        block.setDurability(5);
    }else if (tempInt>12&&tempInt<=15){
        block.setBlocktype(BlockType.lapis);
        block.setDurability(5);
    }else if (tempInt>15&&tempInt<=25){
        block.setBlocktype(BlockType.dirt);
        block.setDurability(5);
    }else if (tempInt>25&&tempInt<=30){
        block.setBlocktype(BlockType.coal);
        block.setDurability(10);
    }else if (tempInt>30&&tempInt<=35){
        block.setBlocktype(BlockType.diorite);
        block.setDurability(20);
    }else if (tempInt>35&&tempInt<=40){
        block.setBlocktype(BlockType.granite);
        block.setDurability(40);
    }else if (tempInt>40&&tempInt<=42){
        block.setBlocktype(BlockType.water);
        block.setDurability(0);
    }else if (tempInt>42&&tempInt<=99){
        block.setBlocktype(BlockType.stone);
        block.setDurability(30);
    }else{
        block.setBlocktype(BlockType.lava);
        block.setDurability(0);}
    blocks.add(block);
    
    
    
    blockNumber++;
    }}
    }
    public void setMiddleLevel(){
    int blockNumber=0;
       
    for(int i=0; i<yMidSize;i++){
    for(int j=0; j<xSize;j++){
        if(i==0){
        Blocks block= new Blocks(j*blockSize,i*blockSize,BlockType.dirt, 5,1);
        blocks.add(block);
        continue;
        }
        Blocks block= new Blocks(j*blockSize,i*blockSize,BlockType.empty, 100,1);
        Random random =new Random();
        int tempInt=random.nextInt(100)+1;
        int randomInt=random.nextInt(100)+1;
        if(randomInt<50 ){
            if(randomInt<25 && blockNumber%xSize!=0){
        block.setBlocktype(blocks.get(xSize*skyLimit+i*xSize+j-1).getBlocktype());
        block.setDurability(blocks.get(xSize*skyLimit+i*xSize+j-1).getDurability());
       blocks.add(block);
       continue;
            }else if(randomInt<50 && blockNumber > xSize){
        block.setBlocktype(blocks.get(xSize*skyLimit+i*xSize+j-xSize).getBlocktype());
        block.setDurability(blocks.get(xSize*skyLimit+i*xSize+j-xSize).getDurability());
        blocks.add(block);
        continue;
            }
            
        }
        
          if (tempInt>0&&tempInt<=50){
        block.setBlocktype(BlockType.dirt);
        block.setDurability(5);
    }else if (tempInt>50&&tempInt<=70){
        block.setBlocktype(BlockType.stone);
        block.setDurability(30);
    }else if (tempInt>70&&tempInt<=90){
        block.setBlocktype(BlockType.gravel);
        block.setDurability(10);
    }else if (tempInt>90&&tempInt<=100){
        block.setBlocktype(BlockType.diorite);
        block.setDurability(20);
    }
    blocks.add(block);
   
    blockNumber++;
    }
    }
    }
    public void setUpperLevel(){
     
        for(int i=0; i<skyLimit;i++){
        for(int j=0; j<xSize;j++){
                Blocks block= new Blocks(j*blockSize,i*blockSize-blockSize*skyLimit,BlockType.sky, 0,1);
                blocks.add(block);
        }
        }
        int treeCount=0;
        while(treeCount<xSize/10){
           Random random =new Random();
        int tempX=random.nextInt(xSize-1)+1;
        int treeIdentifier=random.nextInt(100)+1;
        BlockType treeType=BlockType.maple;
        if (treeIdentifier>0&&treeIdentifier<=25){
        treeType=BlockType.maple;
    }else if (treeIdentifier>25&&treeIdentifier<=50){
       treeType=BlockType.oak;
    }else if (treeIdentifier>50&&treeIdentifier<=75){
        treeType=BlockType.darkOak;
    }else if (treeIdentifier>75&&treeIdentifier<=100){
        treeType=BlockType.birch;
    }
        makeTree(treeType, tempX);
        treeCount++;
        }
        blocks.get(14*xSize+18).setBlocktype(BlockType.sky);
    }
    public void moveBlocks(){
    for(int i=0; i<blocks.size();i++){
            blocks.get(i).setY(blocks.get(i).getY()+blockSize*11);
            }
    }
    public void drawBlocks(Graphics graphics){
    for(Blocks block : blocks){
        switch(block.getBlocktype()){
            case diamond->drawDiamond(graphics, block.getX(),block.getY());
            case gold->drawGold(graphics, block.getX(),block.getY());
            case stone->drawStone(graphics, block.getX(),block.getY());
            case lava->drawLava(graphics, block.getX(),block.getY());
            case iron->drawIron(graphics, block.getX(),block.getY());
            case dirt->drawDirt(graphics, block.getX(),block.getY());
            case lapis->drawLapis(graphics, block.getX(),block.getY());
            case redstone->drawRedStone(graphics, block.getX(),block.getY());
            case coal->drawCoal(graphics, block.getX(),block.getY());
             case diorite->drawDiorite(graphics, block.getX(),block.getY());
             case granite->drawGranite(graphics, block.getX(),block.getY());
             case water->drawWater(graphics, block.getX(),block.getY());
             case oak->drawOak(graphics, block.getX(),block.getY());
             case darkOak->drawDarkOak(graphics, block.getX(),block.getY());
             case maple->drawMaple(graphics, block.getX(),block.getY());
             case birch->drawBirch(graphics, block.getX(),block.getY());
             case sky->drawSky(graphics, block.getX(),block.getY());
             case leaves->drawLeaves(graphics, block.getX(),block.getY());
             case gravel->drawGravel(graphics, block.getX(),block.getY());
             case plank->drawPlank(graphics, block.getX(),block.getY());
             case craftingTable->drawCraftingTable(graphics, block.getX(),block.getY());
             case furnace->drawFurnace(graphics, block.getX(),block.getY());
             case chest->drawChest(graphics, block.getX(),block.getY());
             
             
        }
    }
    }
    public void drawToolBar(Graphics graphics){
        int counter=0;
    for(int i=0; i<10;i++){
        boolean selected=false;
        if(counter==highlightedItem&& (craftingMode|| inventoryMode||furnaceMode|| chestMode)){
        selected=true;
        }
        if(counter==inHandItem&& !craftingMode&& !inventoryMode &&!furnaceMode&& !chestMode){
        selected=true;
        }
    drawToolBarSlot(graphics, selected,460+i*100, 970);
    counter++;
    }
     for(int i=0;i<10;i++){
    drawToolBarItems(graphics, 485+i*100, 995, inventory[i].getBlocktype(), inventory[i].getSecondaryBlockType(),inventory[i].getQuantity(),inventory[i].getDurability());
     }
    }
    public void drawDiamond(Graphics graphics, int x, int y){
    drawStone(graphics,x,y);
    graphics.setColor(Color.CYAN);
    drawDots(graphics, x, y);
    }
    public void drawStone(Graphics graphics, int x, int y){
    for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
    if((j+i)%4==0){
    graphics.setColor(Color.gray);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else {
    graphics.setColor(Color.lightGray);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,blockSize,blockSize);
    }
    public void drawLeaves(Graphics graphics, int x, int y){
    for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
    if((j+i)%4==0){
    graphics.setColor(brown);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else {
    graphics.setColor(Color.green);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,blockSize,blockSize);
    }
    public void drawDiorite(Graphics graphics, int x, int y){
    for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
    if((j+i)%4==0){
    graphics.setColor(Color.WHITE);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else {
    graphics.setColor(Color.gray);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);}
    public void drawGranite(Graphics graphics, int x, int y){
    for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
    if((j+i)%4==0){
    graphics.setColor(Color.WHITE);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else {
    graphics.setColor(Color.red);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);}
    public void drawGravel(Graphics graphics, int x, int y){
    for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
    if((j+i)%4==0){
    graphics.setColor(Color.gray);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else {
    graphics.setColor(Color.DARK_GRAY);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);}
    public void drawGold(Graphics graphics, int x, int y){
    drawStone(graphics,x,y);
    graphics.setColor(Color.YELLOW);
    drawDots(graphics, x, y);
    }
    public void drawDots(Graphics graphics, int x, int y){
    graphics.fillOval(x+15,y+10,6,6);
    graphics.fillOval(x+30,y+10,6,6);
    graphics.fillOval(x+15,y+35,6,6);
    graphics.fillOval(x+30,y+35,6,6);
    graphics.fillOval(x+10,y+22,6,6);
    graphics.fillOval(x+23,y+22,6,6);
    graphics.fillOval(x+35,y+22,6,6);
    };
    public void drawIron(Graphics graphics, int x, int y){
    drawStone(graphics,x,y);
    graphics.setColor(lightBrown);
    drawDots(graphics, x, y);
    }
    public void drawLava(Graphics graphics, int x, int y){
        int temp;
        for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
        Random rand=new Random();
         temp=rand.nextInt(4);
        switch (temp) {
            case 0->graphics.setColor(Color.red);
            case 1->graphics.setColor(Color.yellow);
            default->graphics.setColor(Color.orange);   
        }
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    }
    public void drawWater(Graphics graphics, int x, int y){
        int temp;
        for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
        Random rand=new Random();
         temp=rand.nextInt(4);
        switch (temp) {
            case 0->graphics.setColor(Color.cyan);
            default-> graphics.setColor(Color.blue);        }
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    }
    public void drawOak(Graphics graphics, int x, int y){
    for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
    if((j)%3==0){
    graphics.setColor(lightBrown);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else {
    graphics.setColor(brown);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    }
    public void drawDarkOak(Graphics graphics, int x, int y){
    for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
    if((j)%3==0){
    graphics.setColor(Color.black);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else {
    graphics.setColor(brown);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    }
    public void drawBirch(Graphics graphics, int x, int y){
    for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
    if((j)%3==0){
    graphics.setColor(Color.white);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else {
    graphics.setColor(lightBrown);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    }
    public void drawMaple(Graphics graphics, int x, int y){
    for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
    if((j)%3==0){
    graphics.setColor(Color.gray);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else {
    graphics.setColor(brown);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    }
    public void drawDirt(Graphics graphics, int x, int y){
    for(int i=0; i<10;i++){
    for(int j=0; j<10;j++){
    if((j+i)%4==0){
    graphics.setColor(darkerGrey);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else if((j+i)%2==0){
    graphics.setColor(lightBrown);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }else {
    graphics.setColor(brown);
    graphics.fillRect(x+5*i,y+5*j,5,5);
    }
    }
    }
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    
    }
    public void drawPlank(Graphics graphics, int x, int y){
    graphics.setColor(lightBrown);
    graphics.fillRect(x,y,50,50);
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    }
    public void drawCraftingTable(Graphics graphics, int x, int y){
    graphics.setColor(lightBrown);
    graphics.fillRect(x,y,50,50);
    graphics.setColor(Color.black);
    graphics.fillRect(x+5,y+5,40,40);
    graphics.setColor(brown);
    graphics.fillRect(x+15,y+15,20,20);
    graphics.setColor(lightBrown);
    graphics.fillRect(x+20,y+20,10,10);
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    }
    public void drawChest(Graphics graphics, int x, int y){
    graphics.setColor(lightBrown);
    graphics.fillRect(x,y,50,50);
    graphics.setColor(Color.black);
    graphics.fillRect(x+20,y+20,10,10);
    graphics.setColor(Color.gray);
    graphics.fillRect(x+23,y+23,4,4);
    
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    }
    public void drawFurnace(Graphics graphics, int x, int y){
    graphics.setColor(Color.lightGray);
    graphics.fillRect(x,y,50,50);
    graphics.setColor(Color.black);
    graphics.fillRect(x+5,y+5,40,40);
    graphics.setColor(Color.gray);
    graphics.fillRect(x+15,y+15,20,20);
    graphics.setColor(Color.lightGray);
    graphics.fillRect(x+20,y+20,10,10);
    graphics.setColor(Color.BLACK);
    graphics.drawRect(x,y,50,50);
    }
    public void drawArrow(Graphics graphics, int x, int y){
       graphics.setColor(brown);
        drawStick(graphics,x,y);
    graphics.setColor(Color.lightGray);
    drawDiagonal(graphics, x+40,y,4,3);
    }
    public void drawTorch(Graphics graphics, int x, int y){
       graphics.setColor(brown);
        drawStick(graphics,x,y);
    graphics.setColor(Color.orange);
    drawDiagonal(graphics, x+40,y,4,3);
    }
    public void drawLadder(Graphics graphics, int x, int y){
       graphics.setColor(brown);
        graphics.fillRect(x+10, y+10, 5, 30);
     graphics.fillRect(x+40, y+10, 5, 30);
      graphics.fillRect(x+10, y+15, 30, 3);
       graphics.fillRect(x+10, y+20, 30, 3);
        graphics.fillRect(x+10, y+25, 30, 3);
    }
    public void drawBow(Graphics graphics, int x, int y){
       graphics.setColor(brown);
        drawStick(graphics,x-10,y);
        graphics.setColor(brown);
        drawStick(graphics,x+10,y);
    }
    public void drawChestPlate(Graphics graphics, int x, int y, BlockType type){
       placeHandle(graphics, x, y, type, false);
       graphics.fillRect(x+10, y+10, 30, 30);
        drawDiagonal(graphics,x+31,y+14, 3,8);
        drawDiagonal(graphics,x-5,y+25, 8,3);
        
    }
    public void drawBoots(Graphics graphics, int x, int y, BlockType type){
       placeHandle(graphics, x, y, type, false);
       drawDiagonal(graphics,x+4,y+15, 6,4);
        drawDiagonal(graphics,x+30,y+44, 6,4);
        drawDiagonal(graphics,x+4,y+15, 2,6);
        drawDiagonal(graphics,x+30,y+44, 2,6);
        
    }
    public void drawPants(Graphics graphics, int x, int y, BlockType type){
       placeHandle(graphics, x, y, type, false);
       graphics.fillRect(x+5, y+5, 40, 10);
       graphics.fillRect(x+5, y+5, 14, 40);
       graphics.fillRect(x+31, y+5, 14, 40);
       // drawDiagonal(graphics,x+4,y+15, 2,8);
       // drawDiagonal(graphics,x+30,y+44, 8,2);
        
    }
    public void drawHelmet(Graphics graphics, int x, int y, BlockType type){
       placeHandle(graphics, x, y, type, false);
       graphics.fillRect(x+5, y+10, 40, 20);
       graphics.fillRect(x+5, y+30, 8, 20);
       graphics.fillRect(x+37, y+30, 8, 20);
        
        
    }
    public void drawStick(Graphics graphics, int x, int y){
    graphics.setColor(brown);
        drawDiagonal(graphics, x+5, y+35 ,19, 2);
    }
    public void drawSky(Graphics graphics, int x, int y){
    if(Timer<dayLength*3/4 && sun==true){
        graphics.setColor(Color.cyan);
    }else if(Timer<dayLength && sun==true){
        graphics.setColor(Color.blue);
    }else if(Timer<dayLength*3/4 && sun==false){
        graphics.setColor(Color.black);
    }else if(Timer<dayLength && sun==false){
        graphics.setColor(Color.blue);
    }
    graphics.fillRect(x,y,blockSize,blockSize);
    }
    public void drawSun(Graphics graphics){
        graphics.setColor(Color.yellow);
    graphics.fillOval((int)(1800*Timer/dayLength),(14-playerY)*50,200,200);
    }
    public void drawMoon(Graphics graphics){
    graphics.setColor(Color.white);
    graphics.fillOval((int)(1800*Timer/dayLength),(14-playerY)*50,200,200);
    }
    public void drawToolBarSlot(Graphics graphics, boolean highlighted, int x, int y){
    
        graphics.setColor(Color.darkGray);
    graphics.fillRect(x, y, 100, 100);
    graphics.setColor(Color.GRAY);
    graphics.fillRect(x+3, y+3, 94, 94);
    graphics.setColor(Color.LIGHT_GRAY);
    graphics.fillRect(x+6, y+6, 88, 88);
    graphics.setColor(Color.GRAY);
    graphics.fillRect(x+9, y+9, 82, 82);
    graphics.setColor(Color.darkGray);
    graphics.fillRect(x+12, y+12, 76, 76);
    graphics.setColor(Color.BLACK);
    if(highlighted==true && (craftingMode||inventoryMode||chestMode||furnaceMode)){
    graphics.setColor(Color.gray);
    graphics.fillRect(x+15,y+15,70,70);
     }
    if(highlighted==true && !craftingMode&& !inventoryMode && !chestMode && !furnaceMode){
    graphics.setColor(Color.gray);
    graphics.fillRect(x+15,y+15,70,70);
     }
    graphics.fillRect(x+15,y+15,70,70);
    }
    public void drawToolBarItems(Graphics graphics, int x, int y,BlockType type,BlockType secondaryType, int quantity, int durability){
        switch(type){
            case diamond->{drawDiamond(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case gold->{drawGold(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case stone->{drawStone(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case lava->{drawLava(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case flint->{drawFlint(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case iron->{drawIron(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case ironOre->{drawIronOre(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case redStonePiece->{drawRedStonePiece(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case diamondShard->{drawDiamondShard(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case lapisPiece->{drawLapisPiece(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case coalPiece->{drawCoalPiece(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case goldOre->{drawGoldOre(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case dirt->{drawDirt(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case pick->{drawPickAxe(graphics,x,y,secondaryType );
            drawDurability(graphics, x, y, durability, secondaryType);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case sword->{drawSword(graphics,x,y,secondaryType );
            drawDurability(graphics, x, y, durability, secondaryType);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case hoe->{drawHoe(graphics,x,y,secondaryType );
            drawDurability(graphics, x, y, durability, secondaryType);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case shovel->{drawShovel(graphics,x,y,secondaryType );
            drawDurability(graphics, x, y, durability, secondaryType);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case axe->{drawAxe(graphics,x,y,secondaryType );
            drawDurability(graphics, x, y, durability, secondaryType);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case lapis->{drawLapis(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case redstone->{drawRedStone(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case coal->{drawCoal(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case diorite->{drawDiorite(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case granite->{drawGranite(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case water->{drawWater(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case oak->{drawOak(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case darkOak->{drawDarkOak(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case maple->{drawMaple(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case birch->{drawBirch(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
            case leaves->{drawLeaves(graphics, x,y);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case gravel->{drawGravel(graphics, x,y);
             drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case plank->{drawPlank(graphics,x,y);
             drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case stick->{drawStick(graphics,x,y);
             drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case ladder->{drawLadder(graphics,x,y);
             drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case craftingTable->{drawCraftingTable(graphics,x,y);
             drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case furnace->{drawFurnace(graphics,x,y);
             drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case chest->{drawChest(graphics,x,y);
             drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case arrow->{drawArrow(graphics,x,y);
             drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case torch->{drawTorch(graphics,x,y);
             drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case bow->{drawBow(graphics,x,y);
             drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case chestPlate->{drawChestPlate(graphics,x,y,secondaryType );
            drawDurability(graphics, x, y, durability, secondaryType);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case pants->{drawPants(graphics,x,y,secondaryType );
            drawDurability(graphics, x, y, durability, secondaryType);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case boots->{drawBoots(graphics,x,y,secondaryType );
            drawDurability(graphics, x, y, durability, secondaryType);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             case helmet->{drawHelmet(graphics,x,y,secondaryType );
            drawDurability(graphics, x, y, durability, secondaryType);
            drawQuantity(graphics, x, y, quantity, String.valueOf(type));}
             
             
            
    }
    }
    public void drawPlayer(Graphics graphics){
        //head
        graphics.setColor(brown);
        placeHandle(graphics,0,0,equippedArmor[0].getSecondaryBlockType(),false);  
   graphics.fillRect(910+9,520-18,13,13);
   //face
   graphics.setColor(Color.black);
   //eyes
   graphics.fillRect(910+12,520-15,2,2);
   graphics.fillRect(910+17,520-15,2,2);
   //mouth
   graphics.fillRect(910+12,520-8,8,2);
   graphics.fillRect(910+11,520-10,2,2);
   graphics.fillRect(910+19,520-10,2,2);
        //chest
   graphics.setColor(Color.blue);
    placeHandle(graphics,0,0,equippedArmor[1].getSecondaryBlockType(),false);
   graphics.fillRect(910+5,520-5,20,15);
   //arms
   graphics.setColor(Color.black);
    placeHandle(graphics,0,0,equippedArmor[1].getSecondaryBlockType(),false);
   graphics.fillRect(910,520-5,5,15);
   graphics.fillRect(910+25,520-5,5,15);
   //legs
   graphics.setColor(Color.black);
    placeHandle(graphics,0,0,equippedArmor[2].getSecondaryBlockType(),false);
   graphics.fillRect(910+8,520+10,14,20);
   graphics.setColor(brown);
    placeHandle(graphics,0,0,equippedArmor[3].getSecondaryBlockType(),false);
   graphics.fillRect(910+7,520+25,16,5);
   //legsline
   graphics.setColor(Color.black);
   graphics.fillRect(910+15,520+10,1,20);
   if(direction==ButtonCommands.left){
   graphics.setColor(Color.white);
   graphics.fillRect(910-20,520,20,4);
   }else if(direction==ButtonCommands.right){
   graphics.setColor(Color.white);
   graphics.fillRect(910+30,520,20,4);
   }else if(direction==ButtonCommands.up){
   graphics.setColor(Color.white);
   graphics.fillRect(910+15,520-25,4,20);
   }else if(direction==ButtonCommands.down){
   graphics.setColor(Color.white);
   graphics.fillRect(910+15,520+15,4,20);
   }
   }
    public void drawZombie(Graphics graphics){
Color bodyColor;

for(int i=0; i<zombies.size();i++){
    if(Timer%4==0 && zombies.get(i).isBurning()){
         bodyColor=Color.red;
}else{
 bodyColor=Color.green;
}
    
       //head
        graphics.setColor(bodyColor);
   graphics.fillRect(10+(zombies.get(i).getX()+mobOffsetX)*50+9,20+(zombies.get(i).getY()+mobOffsetY)*50-18,13,13);
   //feature colors
   graphics.setColor(Color.red);
   //eyes
   graphics.fillRect(10+(zombies.get(i).getX()+mobOffsetX)*50+12,20+(zombies.get(i).getY()+mobOffsetY)*50-10,2,2);
   graphics.fillRect(10+(zombies.get(i).getX()+mobOffsetX)*50+19,20+(zombies.get(i).getY()+mobOffsetY)*50-10,2,2);
        //chest
   graphics.setColor(brown);
   graphics.fillRect(10+(zombies.get(i).getX()+mobOffsetX)*50+5,20+(zombies.get(i).getY()+mobOffsetY)*50-5,20,15);
   //arm
   graphics.setColor(bodyColor);
   graphics.fillRect(10+(zombies.get(i).getX()+mobOffsetX)*50,20+(zombies.get(i).getY()+mobOffsetY)*50-5,5,15);
   graphics.fillRect(10+(zombies.get(i).getX()+mobOffsetX)*50+25,20+(zombies.get(i).getY()+mobOffsetY)*50-5,5,15);
   //legs
   graphics.setColor(bodyColor);
   graphics.fillRect(10+(zombies.get(i).getX()+mobOffsetX)*50+8,20+(zombies.get(i).getY()+mobOffsetY)*50+10,14,20);
   //legsline
   graphics.setColor(Color.black);
   graphics.fillRect(10+(zombies.get(i).getX()+mobOffsetX)*50+15,20+(zombies.get(i).getY()+mobOffsetY)*50+10,1,20);}
    }
    public void drawCreeper(Graphics graphics){
Color bodyColor;

for(int i=0; i<creepers.size();i++){
    if(Timer%4==0 && creepers.get(i).isBurning()){
         bodyColor=Color.cyan;
}else{
 bodyColor=Color.green;
}
    
       //head
        graphics.setColor(bodyColor);
   graphics.fillRect(10+(creepers.get(i).getX()+mobOffsetX)*50+9,20+(creepers.get(i).getY()+mobOffsetY)*50-18,13,13);
   //feature colors
   graphics.setColor(Color.black);
   //eyes
   graphics.fillRect(10+(creepers.get(i).getX()+mobOffsetX)*50+12,20+(creepers.get(i).getY()+mobOffsetY)*50-10,2,2);
   graphics.fillRect(10+(creepers.get(i).getX()+mobOffsetX)*50+19,20+(creepers.get(i).getY()+mobOffsetY)*50-10,2,2);
        //chest
   graphics.setColor(bodyColor);
   graphics.fillRect(10+(creepers.get(i).getX()+mobOffsetX)*50+5,20+(creepers.get(i).getY()+mobOffsetY)*50-5,20,15);
    //legs
   graphics.setColor(bodyColor);
   graphics.fillRect(10+(creepers.get(i).getX()+mobOffsetX)*50+8,20+(creepers.get(i).getY()+mobOffsetY)*50+10,14,20);
   graphics.fillRect(5+(creepers.get(i).getX()+mobOffsetX)*50+8,30+(creepers.get(i).getY()+mobOffsetY)*50+10,24,10);

}
}
    public void drawSpider(Graphics graphics){
Color bodyColor;

for(int i=0; i<spiders.size();i++){
    if(Timer%4==0 && spiders.get(i).isBurning()){
         bodyColor=Color.blue;
}else{
 bodyColor=Color.darkGray;
}
    
       //head
        graphics.setColor(bodyColor);
   graphics.fillRect(-10+(spiders.get(i).getX()+mobOffsetX)*50+9,45+(spiders.get(i).getY()+mobOffsetY)*50-18,10,10);
//neck
   graphics.fillRect((spiders.get(i).getX()+mobOffsetX)*50+9,48+(spiders.get(i).getY()+mobOffsetY)*50-18,10,5);
//feature colors
   graphics.setColor(Color.red);
   //eyes
   graphics.fillRect(-11+(spiders.get(i).getX()+mobOffsetX)*50+12,40+(spiders.get(i).getY()+mobOffsetY)*50-10,2,2);
   graphics.fillRect(-11+(spiders.get(i).getX()+mobOffsetX)*50+19,40+(spiders.get(i).getY()+mobOffsetY)*50-10,2,2);
        //chest
   graphics.setColor(bodyColor);
   graphics.fillRect(8+(spiders.get(i).getX()+mobOffsetX)*50+5,25+(spiders.get(i).getY()+mobOffsetY)*50-5,20,20);
    //legs
   graphics.setColor(bodyColor);
   for(int j=0; j<3;j++){
   graphics.fillRect(-5+j*5+(spiders.get(i).getX()+mobOffsetX)*50+8,j*5+(spiders.get(i).getY()+mobOffsetY)*50+10,5,5);
   }
   for(int j=0; j<3;j++){
   graphics.fillRect(35-j*5+(spiders.get(i).getX()+mobOffsetX)*50+8,35-j*5+(spiders.get(i).getY()+mobOffsetY)*50+10,5,5);
   }
   for(int j=0; j<3;j++){
   graphics.fillRect(35-j*5+(spiders.get(i).getX()+mobOffsetX)*50+8,j*5+(spiders.get(i).getY()+mobOffsetY)*50+10,5,5);
   }
   for(int j=0; j<3;j++){
   graphics.fillRect(-5+j*5+(spiders.get(i).getX()+mobOffsetX)*50+8,35-j*5+(spiders.get(i).getY()+mobOffsetY)*50+10,5,5);
   }
}
}
    public void drawSkeleton(Graphics graphics){
Color bodyColor;

for(int i=0; i<skeletons.size();i++){
    if(Timer%4==0 && skeletons.get(i).isBurning()){
         bodyColor=Color.red;
}else{
 bodyColor=Color.white;
}
    
       //head
        graphics.setColor(bodyColor);
   graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50+9,20+(skeletons.get(i).getY()+mobOffsetY)*50-18,13,13);
   //feature colors
   graphics.setColor(Color.red);
   //eyes
   graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50+12,20+(skeletons.get(i).getY()+mobOffsetY)*50-10,2,2);
   graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50+19,20+(skeletons.get(i).getY()+mobOffsetY)*50-10,2,2);
        //chest
   graphics.setColor(Color.white);
   graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50+5,20+(skeletons.get(i).getY()+mobOffsetY)*50-5,20,15);
//rib lines
graphics.setColor(Color.black);
   graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50+5,22+(skeletons.get(i).getY()+mobOffsetY)*50-5,20,2);
graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50+5,27+(skeletons.get(i).getY()+mobOffsetY)*50-5,20,2);
graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50+5,32+(skeletons.get(i).getY()+mobOffsetY)*50-5,20,2);
//arm
   graphics.setColor(bodyColor);
   graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50,20+(skeletons.get(i).getY()+mobOffsetY)*50-5,5,15);
   graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50+25,20+(skeletons.get(i).getY()+mobOffsetY)*50-5,5,15);
   //legs
   graphics.setColor(bodyColor);
   graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50+8,20+(skeletons.get(i).getY()+mobOffsetY)*50+10,14,20);
   //legsline
   graphics.setColor(Color.black);
   graphics.fillRect(10+(skeletons.get(i).getX()+mobOffsetX)*50+15,20+(skeletons.get(i).getY()+mobOffsetY)*50+10,1,20);}
    
    }
    public void placeHandle(Graphics graphics, int x, int y, BlockType type, boolean tool){
        if(tool){
     handleX[0]=x+15;
        handleX[1]=x+55;
        handleX[2]=x+45;
        handleX[3]=x+5;
        handleY[0]=y+5;
        handleY[1]=y+45;
        handleY[2]=y+55;
        handleY[3]=y+15;}
        switch(type){
            case goldOre: graphics.setColor(Color.YELLOW);
            break;
            case diamondShard: graphics.setColor(Color.cyan);
            break;
            case ironOre: graphics.setColor(Color.lightGray);
            break;
            case stone: graphics.setColor(Color.darkGray);
            break;
            case plank: graphics.setColor(brown);
            break;
        }
    }
    public void drawDiagonal(Graphics graphics, int x, int y,  int num, int num2){
    for(int i=0;i<num;i++){
      for(int j=0; j<num2;j++){
          graphics.fillRect(x+j*2+i*2,y+j*2-i*2,4,4);
      }  
    }
    }
    public void drawPickAxe(Graphics graphics, int x, int y, BlockType type){
        placeHandle(graphics, x, y, type, true);
    graphics.fillOval(x-5, y-5, 50, 50);
    graphics.setColor(Color.BLACK);
    graphics.fillOval(x+2, y+2, 54, 54);
    graphics.setColor(brown);
    graphics.fillPolygon(handleX, handleY, 4);
    }
    public void drawAxe(Graphics graphics, int x, int y, BlockType type){
        placeHandle(graphics, x, y, type, true);
    graphics.setColor(brown);
    graphics.fillPolygon(handleX, handleY, 4);
    placeHandle(graphics, x, y, type, false);
    drawDiagonal(graphics,x+15,y+15, 6, 3);
    drawDiagonal(graphics,x+15,y+15, 3, 6);
    drawDiagonal(graphics,x-4,y+15, 8, 8);
    }
    public void drawHoe(Graphics graphics, int x, int y, BlockType type){
      placeHandle(graphics, x, y, type, true);
        graphics.setColor(brown);
    graphics.fillPolygon(handleX, handleY, 4); 
    placeHandle(graphics, x, y, type, false);
    drawDiagonal(graphics,x-5,y+15, 8, 4);
    }
    public void drawSword(Graphics graphics, int x, int y, BlockType type){
       placeHandle(graphics, x, y, type, true);
    graphics.setColor(brown);
    graphics.fillPolygon(handleX, handleY, 4);
        placeHandle(graphics, x-10, y-5, type, false);
        drawDiagonal(graphics,x+4,y+15, 6,14);
        drawDiagonal(graphics,x+30,y+44, 8,1);
        graphics.fillRect(x+4, y+4, 12, 12);
    }
    public void drawShovel(Graphics graphics, int x, int y, BlockType type){
        placeHandle(graphics, x, y, type, true);
    graphics.setColor(brown);
    graphics.fillPolygon(handleX, handleY, 4);
        placeHandle(graphics, x-10, y-5, type, false);
        drawDiagonal(graphics,x+4,y+19, 8,8);
        graphics.fillRect(x+4, y+4, 16, 16);
    }
    public void drawCoal(Graphics graphics, int x, int y){
    drawStone(graphics,x,y);
    graphics.setColor(Color.black);
    drawDots(graphics, x, y);
    }
    public void drawLapis(Graphics graphics, int x, int y){
    drawStone(graphics,x,y);
    graphics.setColor(Color.blue);
    drawDots(graphics, x, y);
    }
    public void drawRedStone(Graphics graphics, int x, int y){
    drawStone(graphics,x,y);
    graphics.setColor(Color.red);
    drawDots(graphics, x, y);
}
    public void drawIronOre(Graphics graphics, int x, int y){
    graphics.setColor(Color.gray);
   graphics.fillRect(x,y+15,50,20);
    }
    public void drawGoldOre(Graphics graphics, int x, int y){
    graphics.setColor(Color.yellow);
   graphics.fillRect(x,y+15,50,20);
    }
    public void drawFlint(Graphics graphics, int x, int y){
    graphics.setColor(Color.darkGray);
   graphics.fillRect(x+15,y,20,50);
    }
    public void drawDiamondShard(Graphics graphics, int x, int y){
    graphics.setColor(Color.cyan);
   graphics.fillOval(x+5,y,40,50);
    }
    public void drawCoalPiece(Graphics graphics, int x, int y){
    graphics.setColor(Color.darkGray);
   graphics.fillOval(x+5,y,40,50);
    }
    public void drawRedStonePiece(Graphics graphics, int x, int y){
    graphics.setColor(Color.red);
   graphics.fillOval(x+5,y,40,50);
    }
    public void drawLapisPiece(Graphics graphics, int x, int y){
    graphics.setColor(Color.blue);
   graphics.fillOval(x+5,y,40,50);
    }
    public boolean isTool(BlockType block){
        switch(block){
            case pick->{return true;}
            case sword->{return true;}
            case shovel ->{return true;}
            case hoe->{return true;}
            case axe->{return true;}
            case bucket->{return true;}
            case chestPlate->{return true;}
            case pants-> {return true;}
            case boots-> {return true;}
            case helmet-> {return true;}
            
        }
    return false;
    }
    public void moveAttackDirection(ButtonCommands type){
        int blockInDirection=0;
        switch(type){
            case left ->blockInDirection=leftBlock;
            case right ->blockInDirection=rightBlock;
            case down ->blockInDirection=bottomBlock;
            case up ->blockInDirection=topBlock;
        }
    hunger--;
                if(blocks.get(blockInDirection).getBlocktype()==BlockType.sky||blocks.get(blockInDirection).getBlocktype()==BlockType.empty){
                attackMobs(typeWeapon(BlockType.sword));
                }else{
                    if(!isSpecialBlock(blocks.get(blockInDirection))){
               addToInventory(blocks.get(blockInDirection));}
               if(blockInDirection<skyLimit*xSize){
               blocks.get(blockInDirection).setBlocktype(BlockType.sky);
               }else{
            blocks.get(blockInDirection).setBlocktype(BlockType.empty);}
            inventory[inHandItem].setDurability( inventory[inHandItem].getDurability()-blocks.get(blockInDirection).getDurability());
            isBroken();
           blocks.get(blockInDirection).setDurability(0);
            }
                
    }
    public boolean isSpecialBlock(Blocks block){
        BlockType type= block.getBlocktype();
        double rand= Math.random();
        switch(type){
            case diamond->{
                block.setBlocktype(BlockType.diamondShard);
                addToInventory(block);
            return true;
            }
            case coal->{  block.setBlocktype(BlockType.coalPiece);
                for(int i=0; i<rand*3;i++){
            addToInventory(block);
            return true;
                }}
            case redstone->{ block.setBlocktype(BlockType.redStonePiece);
            for(int i=0; i<rand*5;i++){
            addToInventory(block);
            return true;
            }}
            case lapis->{ block.setBlocktype(BlockType.lapisPiece);
            for(int i=0; i<rand*5;i++){
            addToInventory(block);
            return true;
            }}
            case gravel->{addToInventory(block);
                block.setBlocktype(BlockType.flint);
            for(int i=0; i<rand*2;i++){
            addToInventory(block);
            return true;
            }}
        }
        return false;
    }
    public void buttonFunction(ButtonCommands key){
         if(key==ButtonCommands.action && (craftingMode||furnaceMode)){
        craftItem();
        }else if(key==ButtonCommands.craftItem && (craftingMode||furnaceMode||chestMode)){
        craft();
        }else if(key==ButtonCommands.reset&& (craftingMode||furnaceMode)){
        returnCraftingIngredients();
        } else if(key==ButtonCommands.action && isTool(inventory[inHandItem].getBlocktype())){
        moveAttackDirection(direction);
        
        }else if(key==ButtonCommands.inv){
            if(inventoryMode==true){
            inventoryMode=false;
            }else{
            inventoryMode=true;
            craftingMode=false;
            furnaceMode=false;
            chestMode=false;
            }
            enhancedCrafting=false;
        }else if(key==ButtonCommands.craft){
            if(craftingMode==true){
            craftingMode=false;
            returnCraftingIngredients();
            }else{
            inventoryMode=false;
            furnaceMode=false;
            chestMode=false;
            craftingMode=true;
            }
            enhancedCrafting=false;
        }
        else if(craftingMode==false&&inventoryMode==false&&(key==ButtonCommands.invLeft||key==ButtonCommands.invRight)){
        moveItemInHand( key);
        }
        else if(craftingMode==false&&inventoryMode==false&&key==ButtonCommands.action && !isTool(inventory[inHandItem].getBlocktype())){
        placeBlock();
        }
        else if((craftingMode==true ||inventoryMode==true)&&(key==ButtonCommands.invLeft||key==ButtonCommands.invRight)){
        dropInventory( key);
        }else if((craftingMode==true ||inventoryMode==true)&&(key==ButtonCommands.dawnHelmet||key==ButtonCommands.dawnChestPlate||key==ButtonCommands.dawnPants||key==ButtonCommands.dawnBoots)){
        dawnArmor(key);
        }else if(craftingMode==false &&inventoryMode==false&&key==ButtonCommands.craftItem ){
        specialtyBlockFunction();
        }
        
    }
    public void specialtyBlockFunction(){
        BlockType type=BlockType.empty;
        switch(direction){
        case left->type=blocks.get(leftBlock).getBlocktype();
        case right->type=blocks.get(rightBlock).getBlocktype();
        case up->type=blocks.get(topBlock).getBlocktype();
        case down->type=blocks.get(bottomBlock).getBlocktype();
    }
    switch(type){
        case craftingTable->{enhancedCrafting=true;
        craftingMode=true;
        }
        case furnace->{
        furnaceMode=true;
        }
        case chest->{
        chestMode=true;
        switch(direction){
        case left->{currentChest=blocks.get(leftBlock).getChestIndex();
            System.out.println("in switch: "+blocks.get(leftBlock).getChestIndex());
            System.out.println("in switch: "+blocks.get(leftBlock).getBlocktype());
        }
        case right->currentChest=blocks.get(rightBlock).getChestIndex();
        case up->currentChest=blocks.get(topBlock).getChestIndex();
        case down->currentChest=blocks.get(bottomBlock).getChestIndex();
    }
        }
        case droppedItems->{
        
        }
    }
    }
    public void dawnArmor(ButtonCommands type){
    switch(type){
        case dawnHelmet->{
        if(equippedArmor[0].getBlocktype()!=BlockType.empty){
        addToInventory(equippedArmor[0]);
        equippedArmor[0].setEqual(emptyBlock);
        }
        }
        case dawnChestPlate->{
        if(equippedArmor[1].getBlocktype()!=BlockType.empty){
        addToInventory(equippedArmor[1]);
        equippedArmor[1].setEqual(emptyBlock);
        }
        }
        case dawnPants->{
        if(equippedArmor[2].getBlocktype()!=BlockType.empty){
        addToInventory(equippedArmor[2]);
        equippedArmor[2].setEqual(emptyBlock);
        }
        }
        case dawnBoots->{
        if(equippedArmor[3].getBlocktype()!=BlockType.empty){
        addToInventory(equippedArmor[3]);
        equippedArmor[3].setEqual(emptyBlock);
        }
        }
    }
    }
    public void dropInventory(ButtonCommands key){
    if (key==ButtonCommands.invLeft){
    if(highlightedItem<=9 &&inventory[highlightedItem].getQuantity()==1){
        inventory[highlightedItem].setBlocktype(BlockType.empty);
    inventory[highlightedItem].setDurability(0);
    inventory[highlightedItem].setQuantity(0);
    }else if(highlightedItem<=9 ){
    inventory[highlightedItem].setQuantity(inventory[highlightedItem].getQuantity()-1);
    }else if(highlightedItem>9 &&offHandInventory[highlightedItem-10].getQuantity()==1){
        offHandInventory[highlightedItem-10].setBlocktype(BlockType.empty);
    offHandInventory[highlightedItem-10].setDurability(0);
    offHandInventory[highlightedItem-10].setQuantity(0);
    }else if(highlightedItem>9 ){
    offHandInventory[highlightedItem-10].setQuantity(offHandInventory[highlightedItem-10].getQuantity()-1);
    }
    }
    else if (key==ButtonCommands.invRight){
    if(highlightedItem<=9 ){
        inventory[highlightedItem].setBlocktype(BlockType.empty);
    inventory[highlightedItem].setDurability(0);
    inventory[highlightedItem].setQuantity(0);
    }else if(highlightedItem>9 ){
        offHandInventory[highlightedItem-10].setBlocktype(BlockType.empty);
    offHandInventory[highlightedItem-10].setDurability(0);
    offHandInventory[highlightedItem-10].setQuantity(0);
    }
    }
    }
    public void isBroken(){
    if(inventory[inHandItem].getDurability()<=0){
    inventory[inHandItem].setBlocktype(BlockType.empty);
    inventory[inHandItem].setDurability(0);
        inventory[inHandItem].setSecondaryBlockType(BlockType.empty);

    }
    }
    public void moveItemInHand(ButtonCommands key){
    if(key==ButtonCommands.invLeft && inHandItem==0){
    inHandItem=9;
    }else if(key==ButtonCommands.invRight && inHandItem==9){
    inHandItem=0;
    }else if(key==ButtonCommands.invLeft ){
    inHandItem--;
    }else if(key==ButtonCommands.invRight ){
    inHandItem++;
    }
    }
    public void moveCoordinate(int x, int y){
        playerX-=x;
   playerY-=y;
   mobOffsetX+=x;
   mobOffsetY+=y;
    }
    public void move(ButtonCommands key){
   if(!craftingMode&&!inventoryMode&& !chestMode && !furnaceMode){
        switch(key){
        case left -> {
            if(blocks.get(leftBlock).getBlocktype()==BlockType.empty ||blocks.get(leftBlock).getBlocktype()==BlockType.sky){
            for(int i=0; i<blocks.size();i++){
            blocks.get(i).setX(blocks.get(i).getX()+blockSize);
            }
            moveCoordinate(1,0);
            rightBlock-=1;
            leftBlock-=1;
            topBlock-=1;
            bottomBlock-=1;
            hunger--;
            }
            direction=ButtonCommands.left;
            }
        case right -> {
            if(blocks.get(rightBlock).getBlocktype()==BlockType.empty||blocks.get(rightBlock).getBlocktype()==BlockType.sky){
            for(int i=0; i<blocks.size();i++){
            blocks.get(i).setX(blocks.get(i).getX()-blockSize);
            }
            moveCoordinate(-1,0);
         rightBlock+=1;
            leftBlock+=1;
            topBlock+=1;
            bottomBlock+=1;
             hunger--;
        }
            direction=ButtonCommands.right;
            }
        case up -> {
            if(blocks.get(topBlock).getBlocktype()==BlockType.empty||blocks.get(topBlock).getBlocktype()==BlockType.sky){
            for(int i=0; i<blocks.size();i++){
            blocks.get(i).setY(blocks.get(i).getY()+blockSize);
            }
            moveCoordinate(0,1);
            topBlock-=xSize;
            bottomBlock-=xSize;
            rightBlock-=xSize;
            leftBlock-=xSize;
             hunger--;
            }
            direction=ButtonCommands.up;
            }
        case down -> {
            if(blocks.get(bottomBlock).getBlocktype()==BlockType.empty||blocks.get(bottomBlock).getBlocktype()==BlockType.sky){
            for(int i=0; i<blocks.size();i++){
            blocks.get(i).setY(blocks.get(i).getY()-blockSize);
            }
            moveCoordinate(0,-1);
            topBlock+=xSize;
            bottomBlock+=xSize;
            rightBlock+=xSize;
            leftBlock+=xSize;
             hunger--;
            }
            direction=ButtonCommands.down;
            }
    }
    }else {
   moveThroughInventory(key);
   }
    }
    public void setDirection(ButtonCommands key){
    direction=key;
    }
    public void moveThroughInventory(ButtonCommands direction){
   int tempHighlight=highlightedItem;
        switch(direction){
        case right -> {
            if( highlightedItem==9){
            highlightedItem=0;
            }else if((highlightedItem-10)%12==11){
            highlightedItem-=11;
            }else if(highlightedItem>69&&(highlightedItem-70)%3==2){
            highlightedItem-=2;
            }else{        
           highlightedItem++; 
            }
            }
        case left -> {
            if(highlightedItem==0 ){
            highlightedItem=9;
            }else if((highlightedItem-10)%12==0 && highlightedItem!=70){
            highlightedItem+=11;
            }else if(highlightedItem>69&&(highlightedItem-70)%3==0){
            highlightedItem+=2;
            }else{        
           highlightedItem--; 
            } 
            }
        case up -> {
            if(highlightedItem>9 && highlightedItem<57){
            highlightedItem+=12; 
            }else if(highlightedItem>=58 && !chestMode){
            highlightedItem+=12;
            highlightedItem=highlightedItem%70;
            }else if(highlightedItem<=9 ){
            highlightedItem+=10;
            }else if(highlightedItem>=58 && highlightedItem<70&& chestMode){
            highlightedItem=70;
           
            }else if(highlightedItem<76 && highlightedItem>=70&& chestMode){
            highlightedItem+=3;
            }else if(highlightedItem>=76 && chestMode){
            highlightedItem=0;
            }
            }
        case down -> {
            if(highlightedItem>=19 && highlightedItem<=21){
            highlightedItem=9; 
            }else if(highlightedItem<=9 && !chestMode){
            highlightedItem+=58;
            }else if(highlightedItem>=10 && highlightedItem<=18) {
            highlightedItem-=10;
            }else if(highlightedItem>72 &&chestMode) {
            highlightedItem-=3;
            }else if(highlightedItem>=70 &&highlightedItem<=72 &&chestMode) {
            highlightedItem=58;
            }else if(highlightedItem<=9  &&chestMode) {
            highlightedItem=76;
            }else {
            highlightedItem-=12;
            }
    }
        
    }
        if(tempHighlight<=9&&highlightedItem<=9){
        inventory[tempHighlight].setSelected(false);
        inventory[highlightedItem].setSelected(true);
        }else if(tempHighlight<=9 && highlightedItem>=9 && highlightedItem<70){
        inventory[tempHighlight].setSelected(false);
        offHandInventory[highlightedItem-10].setSelected(true);
        }else if(tempHighlight>9 && tempHighlight<70 && highlightedItem<=9){
        offHandInventory[tempHighlight-10].setSelected(false);
        inventory[highlightedItem].setSelected(true);
        }else if(tempHighlight>9 && tempHighlight<70 && highlightedItem>9 && highlightedItem<70){
         offHandInventory[tempHighlight-10].setSelected(false);
        offHandInventory[highlightedItem-10].setSelected(true);
        }
        
        else if(tempHighlight>9 &&tempHighlight<70 && highlightedItem>=70){
        offHandInventory[tempHighlight-10].setSelected(false);
        chests.get(currentChest).get(highlightedItem-70).setSelected(true);
        }else if(tempHighlight<=9 &&  highlightedItem>=70){
         inventory[tempHighlight].setSelected(false);
        chests.get(currentChest).get(highlightedItem-70).setSelected(true);
        }else if(tempHighlight>70 && highlightedItem<=9){
        chests.get(currentChest).get(tempHighlight-70).setSelected(false);
        inventory[highlightedItem].setSelected(true);
        }else if(tempHighlight>70 &&  highlightedItem<70){
        chests.get(currentChest).get(tempHighlight-70).setSelected(false);
        offHandInventory[highlightedItem-10].setSelected(true);
        }
    } 
    public void craft(){
    if (craftingMode){
    if(highlightedItem<=9){
        if(addToCraftingIngredients(inventory[highlightedItem].getBlocktype(),inventory[highlightedItem].getSecondaryBlockType(),inventory[highlightedItem].getDurability())){
    inventory[highlightedItem].setQuantity(inventory[highlightedItem].getQuantity()-1);
    if (inventory[highlightedItem].getQuantity()==0){
    inventory[highlightedItem].setBlocktype(BlockType.empty);
    }
    }
    }else if(highlightedItem>9){
       if(addToCraftingIngredients(offHandInventory[highlightedItem-10].getBlocktype(),offHandInventory[highlightedItem-10].getSecondaryBlockType(),offHandInventory[highlightedItem-10].getDurability())) {
    offHandInventory[highlightedItem-10].setQuantity(offHandInventory[highlightedItem-10].getQuantity()-1);
    if (offHandInventory[highlightedItem-10].getQuantity()==0){
    offHandInventory[highlightedItem-10].setBlocktype(BlockType.empty);
    }
    }
    }   
    }
    else if (furnaceMode){
    if(highlightedItem<=9){
        if(addToFurnaceIngredients(inventory[highlightedItem].getBlocktype(),inventory[highlightedItem].getSecondaryBlockType(),inventory[highlightedItem].getDurability())){
    inventory[highlightedItem].setQuantity(inventory[highlightedItem].getQuantity()-1);
    if (inventory[highlightedItem].getQuantity()==0){
    inventory[highlightedItem].setBlocktype(BlockType.empty);
    }
    }
    }else if(highlightedItem>9&& highlightedItem<70){
       if(addToFurnaceIngredients(offHandInventory[highlightedItem-10].getBlocktype(),offHandInventory[highlightedItem-10].getSecondaryBlockType(),offHandInventory[highlightedItem-10].getDurability())) {
    offHandInventory[highlightedItem-10].setQuantity(offHandInventory[highlightedItem-10].getQuantity()-1);
    if (offHandInventory[highlightedItem-10].getQuantity()==0){
    offHandInventory[highlightedItem-10].setBlocktype(BlockType.empty);
    }
    }
    }   
    }else if (chestMode){
    if(highlightedItem<=9){
        if(addToChestInventory(inventory[highlightedItem])) {  
            inventory[highlightedItem].setQuantity(inventory[highlightedItem].getQuantity()-1);
    if (inventory[highlightedItem].getQuantity()==0){
    inventory[highlightedItem].setBlocktype(BlockType.empty);
    }
    }
    }else if(highlightedItem>9&&highlightedItem<70){
       if(addToChestInventory(offHandInventory[highlightedItem-10])) {
    offHandInventory[highlightedItem-10].setQuantity(offHandInventory[highlightedItem-10].getQuantity()-1);
    if (offHandInventory[highlightedItem-10].getQuantity()==0){
    offHandInventory[highlightedItem-10].setBlocktype(BlockType.empty);
    }
    }
    }  else if(highlightedItem>70){
       addToInventory(chests.get(currentChest).get(highlightedItem-70));
    chests.get(currentChest).get(highlightedItem-70).setQuantity(chests.get(currentChest).get(highlightedItem-70).getQuantity()-1);
    if (chests.get(currentChest).get(highlightedItem-70).getQuantity()==0){
    chests.get(currentChest).get(highlightedItem-70).setBlocktype(BlockType.empty);
    }
    } 
    }
    }
    public void placeBlock(){
    if(!isTool(inventory[inHandItem].getBlocktype())){
    switch(direction){
        case left-> {
            if(blocks.get(leftBlock).getBlocktype()==BlockType.sky ||blocks.get(leftBlock).getBlocktype()==BlockType.empty){
            blocks.get(leftBlock).setBlocktype(inventory[inHandItem].getBlocktype());
            blocks.get(leftBlock).setDurability(inventory[inHandItem].getDurability());
            blocks.get(leftBlock).setChestIndex(inventory[inHandItem].getChestIndex());
            inventory[inHandItem].setQuantity(inventory[inHandItem].getQuantity()-1);
            if(inventory[inHandItem].getQuantity()==0){
            inventory[inHandItem].setBlocktype(BlockType.empty);
            inventory[inHandItem].setDurability(0);}
            }
            }
        case right-> {
            if(blocks.get(rightBlock).getBlocktype()==BlockType.sky ||blocks.get(rightBlock).getBlocktype()==BlockType.empty){
            blocks.get(rightBlock).setBlocktype(inventory[inHandItem].getBlocktype());
            blocks.get(rightBlock).setDurability(inventory[inHandItem].getDurability());
            blocks.get(rightBlock).setChestIndex(inventory[inHandItem].getChestIndex());
            inventory[inHandItem].setQuantity(inventory[inHandItem].getQuantity()-1);
            if(inventory[inHandItem].getQuantity()==0){
            inventory[inHandItem].setBlocktype(BlockType.empty);
            inventory[inHandItem].setDurability(0);}
            }
            }
        case down-> {
            if(blocks.get(bottomBlock).getBlocktype()==BlockType.sky ||blocks.get(bottomBlock).getBlocktype()==BlockType.empty){
            blocks.get(bottomBlock).setBlocktype(inventory[inHandItem].getBlocktype());
            blocks.get(bottomBlock).setDurability(inventory[inHandItem].getDurability());
            blocks.get(bottomBlock).setChestIndex(inventory[inHandItem].getChestIndex());
            inventory[inHandItem].setQuantity(inventory[inHandItem].getQuantity()-1);
            if(inventory[inHandItem].getQuantity()==0){
            inventory[inHandItem].setBlocktype(BlockType.empty);
            inventory[inHandItem].setDurability(0);}
            }
        }
        case up-> {  
            if(blocks.get(topBlock).getBlocktype()==BlockType.sky ||blocks.get(topBlock).getBlocktype()==BlockType.empty){
            blocks.get(topBlock).setBlocktype(inventory[inHandItem].getBlocktype());
            blocks.get(topBlock).setDurability(inventory[inHandItem].getDurability());
            blocks.get(topBlock).setChestIndex(inventory[inHandItem].getChestIndex());
            inventory[inHandItem].setQuantity(inventory[inHandItem].getQuantity()-1);
            if(inventory[inHandItem].getQuantity()==0){
            inventory[inHandItem].setBlocktype(BlockType.empty);
            inventory[inHandItem].setDurability(0);}
            }
        }
        }
    }
    }
    public boolean addToCraftingIngredients(BlockType type, BlockType typeTwo, int dura){
        if(craftingIngredients[0].getBlocktype()==BlockType.empty){
        craftingIngredients[0].setBlocktype(type);
        craftingIngredients[0].setSecondaryBlockType(typeTwo);
        craftingIngredients[0].setDurability(dura);
        showCraftingOption();
    }else if(craftingIngredients[1].getBlocktype()==BlockType.empty){
        craftingIngredients[1].setBlocktype(type);
        craftingIngredients[1].setSecondaryBlockType(typeTwo);
        craftingIngredients[1].setDurability(dura);
        showCraftingOption();
    }else if(craftingIngredients[2].getBlocktype()==BlockType.empty){
        craftingIngredients[2].setBlocktype(type);
        craftingIngredients[2].setSecondaryBlockType(typeTwo);
        craftingIngredients[2].setDurability(dura);
        showCraftingOption();
    }else if(craftingIngredients[3].getBlocktype()==BlockType.empty){
        craftingIngredients[3].setBlocktype(type);
        craftingIngredients[3].setSecondaryBlockType(typeTwo);
        craftingIngredients[3].setDurability(dura);
        showCraftingOption();
    }else {
        showCraftingOption();
        
        return false;
    }
    return true;
    }
    public boolean addToFurnaceIngredients(BlockType type, BlockType typeTwo, int dura){
       if(furnaceIngredients[0].getBlocktype()==type){
        furnaceIngredients[0].setQuantity(furnaceIngredients[0].getQuantity()+1);
        showFurnaceOption();
         return true;
    }else if(furnaceIngredients[1].getBlocktype()==type){
       furnaceIngredients[1].setQuantity(furnaceIngredients[1].getQuantity()+1);
        showFurnaceOption();
         return true;
    }else if(furnaceIngredients[0].getBlocktype()==BlockType.empty){
        furnaceIngredients[0].setBlocktype(type);
        furnaceIngredients[0].setQuantity(1);
        furnaceIngredients[0].setSecondaryBlockType(typeTwo);
        furnaceIngredients[0].setDurability(dura);
        showFurnaceOption();
         return true;
    }else if(furnaceIngredients[1].getBlocktype()==BlockType.empty){
        furnaceIngredients[1].setBlocktype(type);
        furnaceIngredients[1].setQuantity(1);
        furnaceIngredients[1].setSecondaryBlockType(typeTwo);
        furnaceIngredients[1].setDurability(dura);
        showFurnaceOption();
         return true;
    }else {
        showFurnaceOption();
    }
        return false;
   
    }
    public void addToInventory(Blocks type){
        boolean added =false;
        
    for(int i=0; i<10&& added==false;i++){
    
    if(inventory[i].getBlocktype()==type.getBlocktype() && !isTool(type.getBlocktype())
            &&type.getBlocktype()!=BlockType.chest){
        if(inventory[i].getQuantity()<20){
    inventory[i].setQuantity(inventory[i].getQuantity()+1);
    added=true;}
    }}
    if(added==false){
        for(int i=0; i<60&& added==false;i++){
    if(offHandInventory[i].getQuantity()<20){
    if(offHandInventory[i].getBlocktype()==type.getBlocktype()&& !isTool(type.getBlocktype())
            &&type.getBlocktype()!=BlockType.chest){
    offHandInventory[i].setQuantity(offHandInventory[i].getQuantity()+1);
    added=true;}
    }}}
        for(int i=0; i<10&& added==false;i++){
    if(inventory[i].getBlocktype()==BlockType.empty||inventory[i].getBlocktype()==BlockType.sky){
    inventory[i].setBlocktype(type.getBlocktype());
    inventory[i].setSecondaryBlockType(type.getSecondaryBlockType());
    inventory[i].setQuantity(1);
    inventory[i].setDurability(type.getDurability());
    if(type.getBlocktype()==BlockType.chest){
    inventory[i].setChestIndex(type.getChestIndex());
    }
    added=true;
    }}
    
        if(added==false){
        for(int i=0; i<60&& added==false;i++){
    if(offHandInventory[i].getBlocktype()==BlockType.empty||offHandInventory[i].getBlocktype()==BlockType.empty){
    offHandInventory[i].setBlocktype(type.getBlocktype());
    offHandInventory[i].setSecondaryBlockType(type.getSecondaryBlockType());
    offHandInventory[i].setQuantity(1);
    offHandInventory[i].setDurability(type.getDurability());
    if(type.getBlocktype()==BlockType.chest){
    offHandInventory[i].setChestIndex(type.getChestIndex());
    }
    added=true;
    
    }
        }
        }
    } 
    public boolean addToChestInventory(Blocks type){
        boolean added =false;
        System.out.println(currentChest);
        switch(direction){
        
        }
        System.out.println(currentChest);
    for(int i=0; i<9&& added==false;i++){
    
    if(chests.get(currentChest).get(i).getBlocktype()==type.getBlocktype() && !isTool(type.getBlocktype())
            &&type.getBlocktype()!=BlockType.chest){
        if(chests.get(currentChest).get(i).getQuantity()<20){
    chests.get(currentChest).get(i).setQuantity(chests.get(currentChest).get(i).getQuantity()+1);
    added=true;
        return true;
        }
    }}
    
        for(int i=0; i<9&& added==false;i++){
    if(chests.get(currentChest).get(i).getBlocktype()==BlockType.empty||chests.get(currentChest).get(i).getBlocktype()==BlockType.sky){
    chests.get(currentChest).get(i).setBlocktype(type.getBlocktype());
    chests.get(currentChest).get(i).setSecondaryBlockType(type.getSecondaryBlockType());
    chests.get(currentChest).get(i).setQuantity(1);
    chests.get(currentChest).get(i).setDurability(type.getDurability());
    added=true;
    return true;
    }}
   return false;
    } 
    public void drawQuantity(Graphics graphics, int x, int y, int quantity, String name){
    graphics.setColor(Color.WHITE);
        graphics.drawString(Integer.toString(quantity), x-10, y);
        drawName(graphics, x,y,name);
    }
    public void drawName(Graphics graphics, int x, int y, String name){
        graphics.drawString(name, x+10, y);
    }
    public void drawDurability(Graphics graphics, int x, int y, int durability, BlockType type){
    int good=2;
    int bad=2;
    int avg=2;
    switch(type){
        case diamondShard ->{good=3000;
        bad=1000;
        avg=2000;}
        case goldOre ->{good=600;
        bad=200;
        avg=400;}
        case plank ->{good=1200;
        bad=400;
        avg=800;}
        case stone ->{good=1800;
        bad=600;
        avg=1200;}
        case ironOre ->{good=2400;
        bad=800;
        avg=1600;}
    }
    if(durability>=good){
    graphics.setColor(Color.green);
    for(int i=0; i<durability/(bad/2);i++){
    graphics.fillRect(x+i*5, y+50, 4, 4);}
    }else if(durability>=avg){
    graphics.setColor(Color.yellow);
    for(int i=0; i<durability/(bad/2);i++){
    graphics.fillRect(x+i*5, y+50, 4, 4);}
    }else if(durability>=bad){
    graphics.setColor(Color.orange);
    for(int i=0; i<durability/(bad/2);i++){
    graphics.fillRect(x+i*5, y+50, 4, 4);}
    }else if(durability<bad){
    graphics.setColor(Color.red);
    for(int i=0; i<durability/(bad/2);i++){
    graphics.fillRect(x+i*5, y+50, 4, 4);}
    }
    }
    public void drawHealth(Graphics graphics){
   graphics.setColor(Color.black);
   graphics.drawString("Health: ", 10, 35);
        for(int i=0; i<10; i++){
        if(i<health/10){
        graphics.setColor(Color.red);}
        else{
        graphics.setColor(Color.black);}
    graphics.fillRect(55+25*i, 25, 20, 20);}
    }
    public void drawHunger(Graphics graphics){
        graphics.setColor(Color.black);
   graphics.drawString("Hunger: ",10 , 65);
        for(int i=0; i<10; i++){
        if(i<hunger/10){
        graphics.setColor(Color.orange);}
        else{
        graphics.setColor(Color.black);}
    graphics.fillOval(55+25*i, 50, 20, 20);}
    }
    public void drawFullInventory(Graphics graphics, int x, int y){
    int counter=0;
    drawEquippedArmor(graphics, x, y);
        for(int i=0; i<5;i++){
        for(int j=0; j<12;j++){
            boolean selected=false;
            if(counter==highlightedItem-10){
            selected=true;
            }
    drawToolBarSlot(graphics, selected,x+360+j*2*blockSize, y+570-i*2*blockSize);
    counter++;
        }
    }
    for(int j=0; j<5;j++){
     for(int i=0;i<12;i++){
        drawToolBarItems(graphics, x+385+i*2*blockSize, y+595-j*2*blockSize, offHandInventory[i+12*j].getBlocktype(),offHandInventory[i+12*j].getSecondaryBlockType(), offHandInventory[i+12*j].getQuantity(),offHandInventory[i+12*j].getDurability());
    }
    }
    }
    public void drawChestInventory(Graphics graphics, int x, int y, int index){
    
        drawFullInventory(graphics, 100,300);
        drawToolBar(graphics);
        int counter=0;
    
        for(int i=0; i<3;i++){
        for(int j=0; j<3;j++){
            boolean selected=false;
            if(counter==highlightedItem-70){
            selected=true;
            }
    drawToolBarSlot(graphics, selected,x+460+j*2*blockSize, y+320-i*2*blockSize);
    counter++;
        }
    }
    for(int i=0; i<3;i++){
     for(int j=0;j<3;j++){
          //System.out.println(chests.get(index).get(0).getBlocktype());
        // System.out.println(chests.get(index).get(1).getBlocktype());
        drawToolBarItems(graphics, x+485+j*2*blockSize, y+345-i*2*blockSize, chests.get(index).get(i*3+j).getBlocktype(),chests.get(index).get(i*3+j).getSecondaryBlockType(), chests.get(index).get(i*3+j).getQuantity(),chests.get(index).get(i*3+j).getDurability());
    }
    }
    }
    public void drawFurnaceInterface(Graphics graphics, int x, int y){
    
        drawFullInventory(graphics, 100,300);
        drawToolBar(graphics);
           
    for(int i=0; i<2;i++){
    drawToolBarSlot(graphics,false,400+2*blockSize,100+i*blockSize*4);
    drawToolBarItems(graphics, 425+2*blockSize, 125+i*blockSize*4, furnaceIngredients[i].getBlocktype(),furnaceIngredients[i].getSecondaryBlockType(), furnaceIngredients[i].getQuantity(),furnaceIngredients[i].getDurability());
        }
    drawBigArrow(graphics,650,225);
    drawToolBarSlot(graphics,false,700,200);
    drawToolBarItems(graphics, 725, 225, blockToBuild.getBlocktype(),blockToBuild.getSecondaryBlockType(), blockToBuild.getQuantity(),blockToBuild.getDurability());
        
    }
    public void drawCraftingBook(Graphics graphics){
    drawFullInventory(graphics, 100, 250);
    drawToolBar(graphics);
    drawBigArrow(graphics,1500,225);
    
    for(int i=0; i<2;i++){
        for(int j=0; j<2;j++){
    drawToolBarSlot(graphics,false,1250+i*2*blockSize,150+j*2*blockSize);
    drawToolBarItems(graphics, 1275+i*2*blockSize, 175+j*2*blockSize, craftingIngredients[j+2*i].getBlocktype(),craftingIngredients[j+2*i].getSecondaryBlockType(), 1,craftingIngredients[j+2*i].getDurability());
        }}
    drawToolBarSlot(graphics,false,1550,200);
    drawToolBarItems(graphics, 1575, 225, blockToBuild.getBlocktype(),blockToBuild.getSecondaryBlockType(), blockToBuild.getQuantity(),blockToBuild.getDurability());
    }
    public void drawEquippedArmor(Graphics graphics, int x, int y){
    for(int i=0; i<4;i++){
        
    drawToolBarSlot(graphics,false,200+x,175+i*2*blockSize+y);
    drawToolBarItems(graphics, 225+x, 200+i*2*blockSize+y, equippedArmor[i].getBlocktype(),equippedArmor[i].getSecondaryBlockType(), 1,equippedArmor[i].getDurability());
        
    }
    }
    public void drawBigArrow(Graphics graphics, int x, int y){
    graphics.setColor(Color.black);
        graphics.fillRect(x-30, y+12, 30, 20);
    graphics.fillRect(x, y, 5, 45);
     graphics.fillRect(x+5, y+5, 5, 35);
      graphics.fillRect(x+10, y+10, 5, 25);
       graphics.fillRect(x+15, y+15, 5, 15);
        graphics.fillRect(x+20, y+20, 5, 5);
    
    }
    public void makeTree(BlockType treeType, int x){
    boolean treeStoppedGrowing=false;
    int treeHeight=0;
    //grow tree
        while(treeStoppedGrowing==false){
       Random random =new Random();
        int tempX=random.nextInt(100)+1;
        if(treeHeight==7 || tempX>80 && treeHeight>=3){
        treeStoppedGrowing=true;
        }else {
            blocks.get((skyLimit-1-treeHeight)*xSize+x).setBlocktype(treeType);
            blocks.get((skyLimit-1-treeHeight)*xSize+x).setDurability(25);
            treeHeight++;
        }
        }
        //grow leaves
        blocks.get((skyLimit-1-treeHeight)*xSize+x).setBlocktype(BlockType.leaves);
        blocks.get((skyLimit-1-treeHeight)*xSize+x).setDurability(5);
        blocks.get((skyLimit-1-treeHeight)*xSize+x+1).setBlocktype(BlockType.leaves);
        blocks.get((skyLimit-1-treeHeight)*xSize+x+1).setDurability(5);
        blocks.get((skyLimit-1-treeHeight)*xSize+x-1).setBlocktype(BlockType.leaves);      
        blocks.get((skyLimit-1-treeHeight)*xSize+x-1).setDurability(5); 
        blocks.get((skyLimit-treeHeight)*xSize+x+1).setBlocktype(BlockType.leaves);
        blocks.get((skyLimit-treeHeight)*xSize+x+1).setDurability(5);
        blocks.get((skyLimit-treeHeight)*xSize+x-1).setBlocktype(BlockType.leaves);
        blocks.get((skyLimit-treeHeight)*xSize+x-1).setDurability(5);
        Random random =new Random();
        int tempX=random.nextInt(100)+1;
        int leaveLength=0;
        if(tempX>0&& tempX<=40){
            leaveLength=1;
        }else if(tempX>40&& tempX<=80){
            leaveLength=2;
        }else if(tempX>80&& tempX<=100){
            leaveLength=3;
        }
        for(int j=0; j<2;j++){
        for(int i=0; i<leaveLength;i++){
        blocks.get((skyLimit-treeHeight+j)*xSize+x-1-i).setBlocktype(BlockType.leaves);
        blocks.get((skyLimit-treeHeight+j)*xSize+x-1-i).setDurability(5);
        blocks.get((skyLimit-treeHeight+j)*xSize+x+1+i).setBlocktype(BlockType.leaves);
        blocks.get((skyLimit-treeHeight+j)*xSize+x+1+i).setDurability(5);
        }
        }
    }
    public void makeBasicRecipes(){
        
        BlockType type1= BlockType.empty;
       
        
        //planks
        for(int i=0;i<4;i++){
            switch(i){
                case 0-> type1=BlockType.maple;
                case 1->type1=BlockType.oak;
                case 2->type1=BlockType.darkOak;
                case 3->type1=BlockType.birch; }  
     recipes.add(type1);
     recipes.add(BlockType.empty);
     recipes.add(BlockType.empty);
     recipes.add(BlockType.empty);
     Blocks block=new Blocks(1550,200,BlockType.plank,20,4);
            block.setSelected(false);
             block.setSecondaryBlockType(BlockType.empty);
        recipeBook.add(block);}
        
        //sticks
        recipes.add(BlockType.plank);
     recipes.add(BlockType.plank);
     recipes.add(BlockType.empty);
     recipes.add(BlockType.empty);
       Blocks stick=new Blocks(1550,200,BlockType.stick,1,4);
            stick.setSelected(false);
             stick.setSecondaryBlockType(BlockType.empty);
        recipeBook.add(stick);
    //ladder
    recipes.add(BlockType.stick);
     recipes.add(BlockType.stick);
     recipes.add(BlockType.stick);
     recipes.add(BlockType.stick);
       Blocks ladder=new Blocks(1550,200,BlockType.ladder,1,2);
            ladder.setSelected(false);
             ladder.setSecondaryBlockType(BlockType.empty);
        recipeBook.add(ladder);
        //crafting table
    recipes.add(BlockType.plank);
     recipes.add(BlockType.plank);
     recipes.add(BlockType.plank);
     recipes.add(BlockType.plank);
       Blocks craftTable=new Blocks(1550,200,BlockType.craftingTable,1,1);
            craftTable.setSelected(false);
             craftTable.setSecondaryBlockType(BlockType.empty);
        recipeBook.add(craftTable);
        //furnace
         recipes.add(BlockType.stone);
     recipes.add(BlockType.stone);
     recipes.add(BlockType.stone);
     recipes.add(BlockType.stone);
       Blocks furnace=new Blocks(1550,200,BlockType.furnace,1,1);
            furnace.setSelected(false);
             furnace.setSecondaryBlockType(BlockType.empty);
        recipeBook.add(furnace);
        
        //arrow
         recipes.add(BlockType.flint);
     recipes.add(BlockType.stick);
     recipes.add(BlockType.empty);
     recipes.add(BlockType.empty);
       Blocks arrow=new Blocks(1550,200,BlockType.arrow,1,2);
            arrow.setSelected(false);
             arrow.setSecondaryBlockType(BlockType.empty);
        recipeBook.add(arrow);
        //torch 
        recipes.add(BlockType.coalPiece);
     recipes.add(BlockType.stick);
     recipes.add(BlockType.empty);
     recipes.add(BlockType.empty);
       Blocks torch=new Blocks(1550,200,BlockType.torch,1,4);
            arrow.setSelected(false);
             arrow.setSecondaryBlockType(BlockType.empty);
        recipeBook.add(torch);
        
        
    }
    public void makeCraftingRecipes(){
                BlockType type1= BlockType.empty;

     //pickaxes
        for(int i=0;i<5;i++){
            switch(i){
                case 0-> type1=BlockType.goldOre;
                case 1->type1=BlockType.plank;
                case 2->type1=BlockType.stone;
                case 3->type1=BlockType.ironOre;
                case 4->type1=BlockType.diamondShard;}
     craftingRecipes.add(type1);
     craftingRecipes.add(type1);
     craftingRecipes.add(BlockType.stick);
     craftingRecipes.add(BlockType.stick);
     Blocks block=new Blocks(1550,200,BlockType.pick,1000*(i+1),1);
            block.setSelected(false);
             block.setSecondaryBlockType(type1);
        craftingRecipeBook.add(block);}
        
            //axes
        for(int i=0;i<5;i++){
            switch(i){
                case 0-> type1=BlockType.goldOre;
                case 1->type1=BlockType.plank;
                case 2->type1=BlockType.stone;
                case 3->type1=BlockType.ironOre;
                case 4->type1=BlockType.diamondShard;}      
     craftingRecipes.add(type1);
     craftingRecipes.add(type1);
     craftingRecipes.add(type1);
     craftingRecipes.add(BlockType.stick);
     Blocks block=new Blocks(1550,200,BlockType.axe,1000*(i+1),1);
            block.setSelected(false);
             block.setSecondaryBlockType(type1);
        craftingRecipeBook.add(block);}
        
        //shovel
        for(int i=0;i<5;i++){
            switch(i){
                case 0-> type1=BlockType.goldOre;
                case 1->type1=BlockType.plank;
                case 2->type1=BlockType.stone;
                case 3->type1=BlockType.ironOre;
                case 4->type1=BlockType.diamondShard;} 
     craftingRecipes.add(type1);
     craftingRecipes.add(BlockType.stick);
     craftingRecipes.add(BlockType.stick);
     craftingRecipes.add(BlockType.empty);
     Blocks block=new Blocks(1550,200,BlockType.shovel,1000*(i+1),1);
            block.setSelected(false);
             block.setSecondaryBlockType(type1);
        craftingRecipeBook.add(block); }
        
        //swords
        for(int i=0;i<5;i++){
            switch(i){
                case 0-> type1=BlockType.goldOre;
                case 1->type1=BlockType.plank;
                case 2->type1=BlockType.stone;
                case 3->type1=BlockType.ironOre;
                case 4->type1=BlockType.diamondShard;}
     craftingRecipes.add(type1);
     craftingRecipes.add(type1);
     craftingRecipes.add(BlockType.stick);
     craftingRecipes.add(BlockType.empty);
     Blocks block=new Blocks(1550,200,BlockType.sword,1000*(i+1),1);
            block.setSelected(false);
             block.setSecondaryBlockType(type1);
        craftingRecipeBook.add(block); }
        
        //hoes
        for(int i=0;i<5;i++){
            switch(i){
                case 0-> type1=BlockType.goldOre;
                case 1->type1=BlockType.plank;
                case 2->type1=BlockType.stone;
                case 3->type1=BlockType.ironOre;
                case 4->type1=BlockType.diamondShard;}
     craftingRecipes.add(type1);
     craftingRecipes.add(BlockType.empty);
     craftingRecipes.add(BlockType.empty);
     craftingRecipes.add(BlockType.stick);
     Blocks block=new Blocks(1550,200,BlockType.hoe,1000*(i+1),1);
            block.setSelected(false);
             block.setSecondaryBlockType(type1);
        craftingRecipeBook.add(block); }
        //bow
         craftingRecipes.add(BlockType.stick);
     craftingRecipes.add(BlockType.stick);
     craftingRecipes.add(BlockType.string);
     craftingRecipes.add(BlockType.empty);
       Blocks bow=new Blocks(1550,200,BlockType.bow,1,1);
            bow.setSelected(false);
             bow.setSecondaryBlockType(BlockType.empty);
        craftingRecipeBook.add(bow);
        //chestplates
        for(int i=0;i<3;i++){
            switch(i){
                case 0-> type1=BlockType.goldOre;
                case 1->type1=BlockType.ironOre;
                case 2->type1=BlockType.diamondShard;}
     craftingRecipes.add(type1);
     craftingRecipes.add(type1);
     craftingRecipes.add(type1);
     craftingRecipes.add(type1);
     Blocks block=new Blocks(1550,200,BlockType.chestPlate,1000*(i+1),1);
            block.setSelected(false);
             block.setSecondaryBlockType(type1);
        craftingRecipeBook.add(block);}
    
    //pants
        for(int i=0;i<3;i++){
            switch(i){
                case 0-> type1=BlockType.goldOre;
                case 1->type1=BlockType.ironOre;
                case 2->type1=BlockType.diamondShard;}
     craftingRecipes.add(type1);
     craftingRecipes.add(type1);
     craftingRecipes.add(type1);
     craftingRecipes.add(BlockType.empty);
     Blocks block=new Blocks(1550,200,BlockType.pants,1000*(i+1),1);
            block.setSelected(false);
             block.setSecondaryBlockType(type1);
        craftingRecipeBook.add(block);}
        
        //helmet
        for(int i=0;i<3;i++){
            switch(i){
                case 0-> type1=BlockType.goldOre;
                case 1->type1=BlockType.ironOre;
                case 2->type1=BlockType.diamondShard;}
     craftingRecipes.add(type1);
     craftingRecipes.add(type1);
     craftingRecipes.add(BlockType.empty);
     craftingRecipes.add(BlockType.empty);
     Blocks block=new Blocks(1550,200,BlockType.helmet,1000*(i+1),1);
            block.setSelected(false);
             block.setSecondaryBlockType(type1);
        craftingRecipeBook.add(block);}
        //boots
        for(int i=0;i<3;i++){
            switch(i){
                case 0-> type1=BlockType.goldOre;
                case 1->type1=BlockType.ironOre;
                case 2->type1=BlockType.diamondShard;}
     craftingRecipes.add(type1);
     craftingRecipes.add(BlockType.empty);
     craftingRecipes.add(BlockType.empty);
     craftingRecipes.add(BlockType.empty);
     Blocks block=new Blocks(1550,200,BlockType.boots,1000*(i+1),1);
            block.setSelected(false);
             block.setSecondaryBlockType(type1);
        craftingRecipeBook.add(block);}
        
        craftingRecipes.add(BlockType.plank);
     craftingRecipes.add(BlockType.plank);
     craftingRecipes.add(BlockType.plank);
     craftingRecipes.add(BlockType.ironOre);
     Blocks chest=new Blocks(1550,200,BlockType.chest,20,1);
            chest.setSelected(false);
             chest.setSecondaryBlockType(BlockType.empty);
        craftingRecipeBook.add(chest);
    }
    public void makeFurnaceRecipes(){
    BlockType type1= BlockType.empty;
BlockType type2= BlockType.empty;
BlockType fuel= BlockType.empty;
     //ores
        for(int i=0;i<2;i++){
            for(int j=0; j<7; j++){
            switch(i){
                case 0-> {type1=BlockType.gold;
                type2=BlockType.goldOre;
                }
                case 1->{type1=BlockType.iron;
                type2=BlockType.ironOre;}
                }
            switch(j){
                case 0-> fuel=BlockType.coalPiece;
                case 1->fuel=BlockType.plank;
                case 2-> fuel= BlockType.maple;
                case 3-> fuel= BlockType.oak;
                case 4-> fuel= BlockType.darkOak;
                case 5-> fuel= BlockType.birch;
                case 6-> fuel= BlockType.lava;
            }
                System.out.println(i+": "+type1+" + "+fuel+" -> "+type2);
     furnaceRecipes.add(type1);
     furnaceRecipes.add(fuel);
     
     Blocks block=new Blocks(1550,200,type2,1000*(i+1),1);
            block.setSelected(false);
             block.setSecondaryBlockType(BlockType.empty);
        furnaceRecipeBook.add(block);
                System.out.println(furnaceRecipeBook.get(i*7+j).getBlocktype());
            }
        }
    }
    public void craftItem(){
    if(craftOptionAvailable){
        if(blockToBuild.getBlocktype()==BlockType.chest){
        blockToBuild.setChestIndex(nextChestIndex);
        for(int i=0; i<9; i++){
          Blocks block=new Blocks(100,100,BlockType.empty,0,0);
            block.setSelected(false);
            block.setSecondaryBlockType(BlockType.empty);
       newChest.add(block);
       }
       chests.add(newChest);
        nextChestIndex++;
        }
            for(int i=0; i<blockToBuild.getQuantity();i++){
    addToInventory(blockToBuild);}
        
        clearCraftingIngredients();
    }else if (canAddArmor()){
    if(highlightedItem<=9){
        equippedArmor[armorType()].setEqual(inventory[highlightedItem]);
        inventory[highlightedItem].setEqual(emptyBlock);
    }else if(highlightedItem>9){
    equippedArmor[armorType()].setEqual(offHandInventory[highlightedItem-10]);
        offHandInventory[highlightedItem-10].setEqual(emptyBlock);
    }
    }else if( craftingIngredients[0].getBlocktype()==BlockType.empty&& highlightedItem<=9){
    Blocks temp = new Blocks(0,0,BlockType.empty,0,0);
    temp.setEqual(inventory[highlightedItem]);
    Blocks empty= new Blocks(0,0,BlockType.empty,0,0);
    inventory[highlightedItem].setEqual(empty);
    for(int i=0; i<temp.getQuantity(); i++){
    addToInventory(temp);}
    }else  if( craftingIngredients[0].getBlocktype()==BlockType.empty&& highlightedItem>9){
    Blocks temp = new Blocks(0,0,BlockType.empty,0,0);
    temp.setEqual(offHandInventory[highlightedItem-10]);
    Blocks empty= new Blocks(0,0,BlockType.empty,0,0);
    offHandInventory[highlightedItem-10].setEqual(empty);
    for(int i=0; i<temp.getQuantity(); i++){
    addToInventory(temp);}
    }
    
    
    }
    public boolean canAddArmor(){
        if(highlightedItem<=9){
            switch(inventory[highlightedItem].getBlocktype()){
                case helmet->{if(equippedArmor[0].getBlocktype()==BlockType.empty){
                return true;}}
                case chestPlate->{if(equippedArmor[1].getBlocktype()==BlockType.empty){
                return true;}}
                case pants->{if(equippedArmor[2].getBlocktype()==BlockType.empty){
                return true;}}
                case boots->{if(equippedArmor[3].getBlocktype()==BlockType.empty){
                return true;}}
                
    }
            
        }else if(highlightedItem>9 && highlightedItem<70){
        switch(offHandInventory[highlightedItem-10].getBlocktype()){
                case helmet->{if(equippedArmor[0].getBlocktype()==BlockType.empty){
                return true;}}
                case chestPlate->{if(equippedArmor[1].getBlocktype()==BlockType.empty){
                return true;}}
                case pants->{if(equippedArmor[2].getBlocktype()==BlockType.empty){
                return true;}}
                case boots->{if(equippedArmor[3].getBlocktype()==BlockType.empty){
                return true;}}
        }
        }
    return false;
    }
    public int armorType(){
        if(highlightedItem<=9){
    switch(inventory[highlightedItem].getBlocktype()){
                case helmet->{
                return 0;}
                case chestPlate->{
                return 1;}
                case pants->{
                return 2;}
                case boots->{
                return 3;}
    }
        }else if(highlightedItem>9){
    switch(offHandInventory[highlightedItem-10].getBlocktype()){
                case helmet->{
                return 0;}
                case chestPlate->{
                return 1;}
                case pants->{
                return 2;}
                case boots->{
                return 3;}
    }
    }
    return 0;
    }
    public int protection(){
        int helmet=0;
        int chestPlate=0;
        int pants=0;
        int boots=0;
        
        switch(equippedArmor[0].getSecondaryBlockType()){
            case goldOre->{helmet=1;}
            case ironOre->{helmet=2;}
            case diamondShard->{helmet=3;}
        }
        switch(equippedArmor[1].getSecondaryBlockType()){
            case goldOre->{chestPlate=1;}
            case ironOre->{chestPlate=2;}
            case diamondShard->{chestPlate=3;}
        }
        switch(equippedArmor[2].getSecondaryBlockType()){
            case goldOre->{pants=1;}
            case ironOre->{pants=2;}
            case diamondShard->{pants=3;}
        }
        switch(equippedArmor[3].getSecondaryBlockType()){
            case goldOre->{boots=1;}
            case ironOre->{boots=2;}
            case diamondShard->{boots=3;}
        }
        int total= helmet+chestPlate+pants+boots;
        
    return total;
    }
    public void showCraftingOption(){
        int recipeNumber=0;
        int recipeIngredientNumber=0;
        boolean itemsMatch=false;
       List<BlockType> tempIngredients=new ArrayList();
       List<BlockType> tempRecipe=new ArrayList();
        for(int j=0; j<recipeBook.size();j++){
            
            int counter=0;
            for(int k=tempIngredients.size()-1; k>=0; k--){
            tempRecipe.remove(k);
        }
            for(int k=tempIngredients.size()-1; k>=0; k--){
            tempIngredients.remove(k);
            }
            for(int k=0; k<4; k++){
            tempIngredients.add(craftingIngredients[k].getBlocktype());
            tempRecipe.add(recipes.get(recipeIngredientNumber+k));
        }
           
            ii:
    for(int i=0; i<4;i++ ){
        for(int k=0; k<tempRecipe.size(); k++){
            if(tempRecipe.get(0)==tempIngredients.get(k)){
            tempIngredients.remove(k);
            tempRecipe.remove(0);
            counter++;
            if(counter==4){
            itemsMatch=true;
            break ii;
            }
              break;
        }    
    }   
    }
    recipeIngredientNumber+=4;
    if(itemsMatch==true&& counter==4){
        blockToBuild.setBlocktype(recipeBook.get(recipeNumber).getBlocktype());
        blockToBuild.setSecondaryBlockType(recipeBook.get(recipeNumber).getSecondaryBlockType());
        blockToBuild.setQuantity(recipeBook.get(recipeNumber).getQuantity());
        blockToBuild.setDurability(recipeBook.get(recipeNumber).getDurability());
        craftOptionAvailable=true;
       break;
        }
    recipeNumber++;
        }
        recipeNumber=0;
        recipeIngredientNumber=0;
        if(enhancedCrafting){
        for(int j=0; j<craftingRecipeBook.size();j++){
            
            int counter=0;
            for(int k=tempIngredients.size()-1; k>=0; k--){
            tempRecipe.remove(k);
        }
            for(int k=tempIngredients.size()-1; k>=0; k--){
            tempIngredients.remove(k);
            }
            for(int k=0; k<4; k++){
            tempIngredients.add(craftingIngredients[k].getBlocktype());
            tempRecipe.add(craftingRecipes.get(recipeIngredientNumber+k));
        }
           
            ii:
    for(int i=0; i<4;i++ ){
        for(int k=0; k<tempRecipe.size(); k++){
            if(tempRecipe.get(0)==tempIngredients.get(k)){
            tempIngredients.remove(k);
            tempRecipe.remove(0);
            counter++;
            if(counter==4){
            itemsMatch=true;
            break ii;
            }
              break;
        }    
    }   
    }
    recipeIngredientNumber+=4;
    if(itemsMatch==true&& counter==4){
        blockToBuild.setBlocktype(craftingRecipeBook.get(recipeNumber).getBlocktype());
        blockToBuild.setSecondaryBlockType(craftingRecipeBook.get(recipeNumber).getSecondaryBlockType());
        blockToBuild.setQuantity(craftingRecipeBook.get(recipeNumber).getQuantity());
        blockToBuild.setDurability(craftingRecipeBook.get(recipeNumber).getDurability());
        craftOptionAvailable=true;
       break;
        }
    recipeNumber++;
        }
        }
        if(itemsMatch==false){
        blockToBuild.setBlocktype(BlockType.empty);
    blockToBuild.setSecondaryBlockType(BlockType.empty);
    blockToBuild.setQuantity(0);
    blockToBuild.setDurability(0);
    craftOptionAvailable=false;
        }
    }
    public void showFurnaceOption(){
    boolean itemsMatch=false;
    int recipeNumber=0;
    for(int i=0; i<furnaceRecipeBook.size();i++){
    
    if(furnaceIngredients[0].getBlocktype()==furnaceRecipes.get(i*2) && 
            furnaceIngredients[1].getBlocktype()==furnaceRecipes.get(i*2+1) &&
            furnaceIngredients[0].getQuantity()==furnaceIngredients[1].getQuantity()){
    itemsMatch=true;
    recipeNumber=i;
    }
    }
   
    if(itemsMatch==true){
        blockToBuild.setBlocktype(furnaceRecipeBook.get(recipeNumber).getBlocktype());
        blockToBuild.setSecondaryBlockType(furnaceRecipeBook.get(recipeNumber).getSecondaryBlockType());
        blockToBuild.setQuantity(furnaceRecipeBook.get(recipeNumber).getQuantity()*furnaceIngredients[0].getQuantity());
        blockToBuild.setDurability(furnaceRecipeBook.get(recipeNumber).getDurability());
        craftOptionAvailable=true;
        }
        if(itemsMatch==false){
        blockToBuild.setBlocktype(BlockType.empty);
    blockToBuild.setSecondaryBlockType(BlockType.empty);
    blockToBuild.setQuantity(0);
        blockToBuild.setDurability(0);
        //dont know why but jsut in case saved this
    //blockToBuild.setDurability(recipeBook.get(recipeNumber-1).getDurability());
    craftOptionAvailable=false;
        }
    }
    public void clearCraftingIngredients(){
    for(int i=0; i<4; i++){
       
    craftingIngredients[i].setBlocktype(BlockType.empty);
    craftingIngredients[i].setSecondaryBlockType(BlockType.empty);
    }
    for(int i=0; i<2; i++){
       
    furnaceIngredients[i].setBlocktype(BlockType.empty);
    furnaceIngredients[i].setSecondaryBlockType(BlockType.empty);
    }
    blockToBuild.setBlocktype(BlockType.empty);
    blockToBuild.setSecondaryBlockType(BlockType.empty);
    blockToBuild.setQuantity(0);
    craftOptionAvailable=false;
    }
    public void returnCraftingIngredients(){
    for(int i=0; i<4; i++){
       addToInventory(craftingIngredients[i]);
       craftingIngredients[i].setBlocktype(BlockType.empty);
    craftingIngredients[i].setSecondaryBlockType(BlockType.empty);
    }
    for(int i=0; i<2; i++){
        for(int j=0; j<furnaceIngredients[i].getQuantity();j++){
       addToInventory(furnaceIngredients[i]);}
       furnaceIngredients[i].setBlocktype(BlockType.empty);
    furnaceIngredients[i].setSecondaryBlockType(BlockType.empty);
    }
    blockToBuild.setBlocktype(BlockType.empty);
    blockToBuild.setSecondaryBlockType(BlockType.empty);
    blockToBuild.setQuantity(0);
    }
    public int getXSize(){
    return xSize;
    }
    public boolean getIsDead(){
    return isDead;
    }
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setPreferredSize(new java.awt.Dimension(1700, 1200));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
