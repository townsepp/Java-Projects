
package BlockBuster;

import java.awt.Color;

public class Blocks {
    private int x;
    private int y;
    private BlockType blockType;
    private BlockType secondaryBlockType;
    private int durability;
    private boolean selected;
    private Color color;  
    private int quantity;
    private int treestate; 
    private int parentX;
    private int parentY;
    private double gDist;
    private boolean inPath;
    private int chestIndex;
 
public Blocks(int x, int y, BlockType blockType, int durability, int quantity){
 this.x=x;
 this.y=y;
 this.blockType=blockType;
 this.durability=durability;
 this.quantity=quantity;
}
   public void setEqual(Blocks block){
       this.x=block.getX();
        this.y=block.getY();
   this.blockType=block.getBlocktype();
   this.secondaryBlockType=block.getSecondaryBlockType();
   this.durability=block.getDurability();
   this.quantity=block.getQuantity();
   
   }

    public int getChestIndex() {
        return chestIndex;
    }

    public void setChestIndex(int chestIndex) {
        this.chestIndex = chestIndex;
    }
   
    public int getX() {
        return x;
    }
   public void setX(int x) {
        this.x = x;
    }
   public int getY() {
        return y;
    }
    public void setY(int y) {
        this.y = y;
    }
    public BlockType getBlocktype() {
        return blockType;
    }
    public void setBlocktype(BlockType blocktype) {
        this.blockType = blocktype;
    }

    public BlockType getSecondaryBlockType() {
        return secondaryBlockType;
    }

    public void setSecondaryBlockType(BlockType secondaryBlockType) {
        this.secondaryBlockType = secondaryBlockType;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    
 public int getDurability() {
        return durability;
    }
    public void setDurability(int durability) {
        this.durability = durability;
    }
    public Color getColor() {
        return color;
    }
    public void setColor(Color color) {
        this.color = color;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }


    public int getTreestate() {
        return treestate;
    }

    public void setTreestate(int treestate) {
        this.treestate = treestate;
    }

    public int getParentX() {
        return parentX;
    }

    public void setParentX(int parentX) {
        this.parentX = parentX;
    }

    public int getParentY() {
        return parentY;
    }

    public void setParentY(int parentY) {
        this.parentY = parentY;
    }

    public double getgDist() {
        return gDist;
    }

    public void setgDist(double gDist) {
        this.gDist = gDist;
    }

    public boolean isInPath() {
        return inPath;
    }

    public void setInPath(boolean inPath) {
        this.inPath = inPath;
    }
    public int getCost(){
        
    switch(blockType) {
        
                case empty:
                    return 1;
                case sky:
                    return 1;
                default:
                    return 1000;
            }
       
    }
     
}
