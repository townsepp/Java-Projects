
package BlockBuster;

import java.util.ArrayList;
import java.util.List;

public class Skeleton  {

    
    public Skeleton() {
        
    }
    
    private static List<Blocks> blocks= new ArrayList();//
    private static int playerX ;// keeps track of playable character's x coordinate
    private static int playerY ;// keeps track of playable character's y coordinate
    private static int skeletonX;// keeps track of skeleton's x coordinate
    private static int skeletonY;// keeps track of skeleton's y coordinate
    private static int skeletonHitPoints = 10; //hit points the skeleton has
    private static boolean isBurning;//if skeleton is burning
    private static int playerHitPoints = 10; //hit points the playable character has
    private static int skeletonHunger = 0;// level of hunger the skeleton has, higher hunger level mean more hungry
    private static int sunOut = 0;// if sun is out sun will have value of 1 if sun is down sun will have value of 0
    private static int speed=1; // speed of skeleton, only one speed for now but can change for later us
    private static BlockPanel blockPanel= new BlockPanel();// access to blockpanel class
    private static AStar star;//access to Astr class
    private static int xSize;//how many horizaontl blokcs wide the map is
    private static int damage=0;//how many times player is hit
    private static int strength=20;//strength of hits
   private static int direction;//direction to wander

//set globla variables equla to passed in variables
   public static void setEqual(int x, int y, int counter, int index, int X,int Y,
        int health, int hunger,List<Blocks> list, int width, int dir, boolean sun, boolean burning){
direction=dir;
        damage=0;
    	skeletonX=x;
        skeletonY=y;
        playerX=X;
        playerY=Y;
       skeletonHitPoints=health;
       skeletonHunger=hunger;
        xSize=width;
         blocks=list;
         if(sun==true){
       sunOut=1;
       }else{
       sunOut=0;
       }
         isBurning=burning;
}
//displays info to command line if needed
   public static void displayToTerminal() {
	System.out.println("PlayerX: "+playerX);
	System.out.println("PlayerY: "+playerY);
	System.out.println("SkeletonX: "+skeletonX);
	System.out.println("SkeletonY: "+skeletonY);
	System.out.println("Skeleton hit Points: "+skeletonHitPoints);
	System.out.println("Player hit Points: "+playerHitPoints);
	System.out.println("hunger: "+skeletonHunger);
	System.out.println("Sun: "+sunOut);
}    
   //changes hunger and health if in sun
public static void timeAndHungerControls() {
	//if skeleton is not in shade of tree and sun is out it takes damage here
	if(isInSun()&& sunOut==1) {
  	   skeletonHitPoints--;
           isBurning=true;
     }else{
      isBurning=false; }

 //20% chance for hunger to change with random int
	
	if(Math.random() <= .05 ) {
		skeletonHunger++;
	} 
	//keeps hunger from becoming too large
	if(skeletonHunger>=10) {
		skeletonHunger=10;
        }
      }
//movement used when chasing player
public static void chaseMovement() {
    if( Math.abs(skeletonY-playerY)+Math.abs(skeletonX-playerX)<=8 ){
switch(star.planPath( skeletonX,  skeletonY,  playerX,  playerY,  blocks, xSize)){
    case left->skeletonX--;
    case right->skeletonX++;
    case up->skeletonY--;
    case down->skeletonY++;
    case mine-> wanderMovement();
}
    }
         
}
//attacks player if it can
public static boolean attack(){
    int tempX=skeletonX;
    int tempY=skeletonY;
    if(playerY==skeletonY&& Math.abs(playerX-skeletonX)<=4){
    while(tempX!=playerX){
if(!(blocks.get(tempX+skeletonY*xSize).getBlocktype()==BlockType.empty || 
        blocks.get(tempX+skeletonY*xSize).getBlocktype()==BlockType.sky)){
    return false;
}    
if(playerX-tempX<0){
tempX--;
}else{
tempX++;
}
}
    } else if(playerX==skeletonX&& Math.abs(playerY-skeletonY)<=4){
    while(tempY!=playerY){
if(!(blocks.get(skeletonX+tempY*xSize).getBlocktype()==BlockType.empty || 
        blocks.get(skeletonX+tempY*xSize).getBlocktype()==BlockType.sky)){
    return false;
}  
if(playerY-tempY<0){
tempY--;
}else{
tempY++;
}
}
    }else{
    return false;
    }
     damage++;
    return true;
}
//movement used for run state
public static void runMovement(int x) {
if(skeletonX-playerX>=0 && skeletonY-playerY>=0){
    System.out.println("down right");
if(blocks.get(skeletonX+skeletonY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+skeletonY*xSize+1).getBlocktype()==BlockType.sky){
    skeletonX++;
}else if(blocks.get(skeletonX+(skeletonY+1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+(skeletonY+1)*xSize).getBlocktype()==BlockType.sky){
skeletonY++;}
}else if(skeletonX-playerX>=0 && skeletonY-playerY<=0){
    System.out.println("up right");
if(blocks.get(skeletonX+skeletonY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+skeletonY*xSize+1).getBlocktype()==BlockType.sky){
    skeletonX++;
}else if(blocks.get(skeletonX+(skeletonY-1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+(skeletonY-1)*xSize).getBlocktype()==BlockType.sky){
skeletonY--;}
    }else if(skeletonX-playerX<=0 && skeletonY-playerY>=0){
        System.out.println("left down");
if(blocks.get(skeletonX+skeletonY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+skeletonY*xSize-1).getBlocktype()==BlockType.sky){
    skeletonX--;
}else if(blocks.get(skeletonX+(skeletonY+1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+(skeletonY+1)*xSize).getBlocktype()==BlockType.sky){
skeletonY++;}
    }else if(skeletonX-playerX<=0 && skeletonY-playerY<=0){
        System.out.println("left up");
     if(blocks.get(skeletonX+skeletonY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+skeletonY*xSize-1).getBlocktype()==BlockType.sky){
    skeletonX--;
}else if(blocks.get(skeletonX+(skeletonY-1)*xSize).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+(skeletonY-1)*xSize).getBlocktype()==BlockType.sky){
skeletonY--;}
}else {
        System.out.println("wander");
wanderMovement();
}
}
//movement used to get out of sun usually to hide under tree
public static void hideMovement(){
    
    if(isInSun()){      
    int testClosestTree=0;
    int closestTree=0;
    for(int j=0; j<skeletonY  ;j++){
        testClosestTree=j;
        if(testClosestTree%2==0){
            testClosestTree=-testClosestTree/2;
        }else{
        testClosestTree=testClosestTree/2+1;
        }
        for(int i=0; i<skeletonY  ;i++){
       
        if(skeletonX+testClosestTree+i*blockPanel.getXSize()>=0){
        if(blocks.get(skeletonX+testClosestTree+i*blockPanel.getXSize()).getBlocktype()!=BlockType.empty&&
               blocks.get(skeletonX+testClosestTree+i*blockPanel.getXSize()).getBlocktype()!=BlockType.sky ){
        closestTree=testClosestTree;
            break;
        }
    }
        }
        if(closestTree!=0){
    break;
    }   
    }
    if(closestTree<0){
    skeletonX--;
    }else if(closestTree>0){
    skeletonX++;
    }else if(Math.abs(playerX-skeletonX)+ Math.abs(playerY-skeletonY)<=6){
    chaseMovement();
    }else{
    wanderMovement();
    }
    }else{
     if(Math.abs(playerX-skeletonX)+ Math.abs(playerY-skeletonY)<=6){
    chaseMovement();
    }else{
    wanderMovement();
    }
    }
    if(isInSun()){
        isBurning=true;
    }else{
    isBurning=false;
    }
    
}
//wandering movement
public static void wanderMovement() {
if(direction==1&&Math.random()<.75 &&(blocks.get(skeletonX+skeletonY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+skeletonY*xSize+1).getBlocktype()==BlockType.sky)){
skeletonX++;
direction=1;
}else if(direction==0 && Math.random()<.75 &&(blocks.get(skeletonX+skeletonY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+skeletonY*xSize-1).getBlocktype()==BlockType.sky)){
skeletonX--;
direction=0;
}else if(direction==0 && (blocks.get(skeletonX+skeletonY*xSize+1).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+skeletonY*xSize+1).getBlocktype()==BlockType.sky)){
skeletonX++;
direction=1;
}else if(direction==1 && blocks.get(skeletonX+skeletonY*xSize-1).getBlocktype()==BlockType.empty ||
        blocks.get(skeletonX+skeletonY*xSize-1).getBlocktype()==BlockType.sky){
skeletonX--;
direction=0;
}
}  
//checks is skeleton is in sun
public static boolean isInSun(){
Boolean inSun=true;
    for(int i=0; i<skeletonY && inSun==true ;i++){
        if(blocks.get(skeletonX+i*blockPanel.getXSize()).getBlocktype()!=BlockType.empty&&
               blocks.get(skeletonX+i*blockPanel.getXSize()).getBlocktype()!=BlockType.sky ){
        inSun=false;
        break;
        }
    }
    return  inSun;
}

public static abstract class State {
       
        //empty constructor
        public State() {}
        //methods
        public abstract void enter();
        public abstract void exit();
        public abstract void environment();
        public abstract void movement();
        public abstract int updateAndCheckTransitions();
        
    }
    
    // this class represents the skeleton taking a hiding action 
    //usually will hide when the sun is out 
    public static class Hide extends State {
        public Hide() {
            super();
        }
        
        public void enter() {
            System.out.println("The skeleton is trying to hide under tree.");
        }
        public void exit() {            
        	System.out.println("hide exit");
        }
                	                    
       public void environment(){
       timeAndHungerControls();
       }
        //moves skeleton and prints out 
        public void movement() {
        	hideMovement();
                attack();
        	//displayToTerminal();
        }
        public int updateAndCheckTransitions() {  
        	//chance of skeleton switching to chasing state increases as distance decreases
        	if ((Math.abs(playerX-skeletonX)+ Math.abs(playerY-skeletonY)<Math.random()*16 && !isInSun()) || skeletonHunger>=9) {
          	  return 0;
          	  //switch to run if health is low and player is nearby
            }else if(skeletonHitPoints<=2&& Math.abs(playerX-skeletonX)+ Math.abs(playerY-skeletonY)<6 ){
            	return 2;
                //if out of sun wander
            }if(!isInSun()){
            return 3;
            //otherwise keep hiding
            }
                return 1;
        }            
         
    }
   // this class represents the skeleton taking the run action
    // when health is low the skeleton will run away from the playable character
    public static class Run extends State {
        public Run() {
            super();
        }
        
        public void enter() {
            System.out.println("The skeleton is running from you!");
        }
        public void exit() {  
        	System.out.println("run exit");
        }
        
        public void environment(){
        timeAndHungerControls();
        }
        public void movement() {
        	runMovement(0);
                attack();
        	//displayToTerminal();
    }
        public int updateAndCheckTransitions() { 
            //if hungry enough and out of sun and close to player start chasing
            if(!isInSun() && skeletonHunger>=8 && Math.abs(playerX-skeletonX)+Math.abs(playerY-skeletonY)<6) {
            	return 0;
                //if in sun hide
            }else if(isInSun()){
            	return 1;
                //if player is far wander
            }else if(Math.abs(playerX-skeletonX)+Math.abs(playerY-skeletonY)>6){
            	return 3;
                //else keep running
            }
        return 2;
    }    
    }      
   // this class represent the skeleton taking a chasing action 
    // the skeleton will chase the playable character faster as hunger becomes higher 
    public static class Chase extends State {
	
        public Chase() {
           
            super();
        }
        
        
        public void enter() {
            System.out.println("The skeleton is chasing you!");
        }
        public void exit() {            
        	System.out.println("chase exit");
        }
       
        public void environment(){
        timeAndHungerControls();
        }
         
        public void movement() {
            //if it from current position can attack dont move closer to player
            if(!attack()){
        	chaseMovement();}
    }
        public int updateAndCheckTransitions() {
            //if sun is down and health is low chance of running decreases as hunger increases from 10%-100%
        	if(!isInSun() && skeletonHitPoints<=2 && Math.random()>.1*skeletonHunger) {
           return 2;
            //if sun is up the chance of hiding decreases as hunger increases from 5%-50% chance
           }else if(isInSun()&& sunOut==1){
        		return 1;
                        //if player is too far away from skeletons wander
        	}else if(Math.abs(playerX-skeletonX)+Math.abs(playerY-skeletonY)>6){
                    return 3;
                    //keep chasing otherwise
                }else {
        		return 0;
        	}
              
    }
        
        
    } 
    // this class represent the skeleton taking a wander action 
    // the skeleton will move left and right
   public static class Wander extends State {
        public Wander() {
            super();
        }
        
        public void enter() {
            System.out.println("The skeleton is wandering");
        }
        public void exit() {            
        	System.out.println("wander exit");
        }
                	                    
       public void environment(){
       timeAndHungerControls();
       }
        //moves skeleton and prints out 
        public void movement() {
        	wanderMovement();
        	//displayToTerminal();
        }
        public int updateAndCheckTransitions() {  
        	//chance of skeleton switching to chasing state increases as distance decreases
        	if (Math.abs(playerX-skeletonX)+ Math.abs(playerY-skeletonY)-skeletonHunger< Math.random()*16 && !isInSun()) {
          	  return 0;
          	  //if in sun Hide
            }else if( isInSun()){
            	return 1;
                // if health is low and player close run
            }else if(Math.abs(playerX-skeletonX)+ Math.abs(playerY-skeletonY)< 6 && skeletonHitPoints<=2){
            	return 2;
            }
                //else keep wander
                return 3;
        }            
         
    } 

   //functionality of the Skeleton is in this main
    public static Mobs call(int x, int y, int state, int counter, int index, boolean sun, int X,int Y, int health, int hunger,boolean burning ,List<Blocks> list, int width, int dir){
        //set global variables equal to passed in values
        setEqual(x,y,counter,index,X,Y,health,hunger,list,width,dir, sun, burning);
        counter++;
        // four states: run, chase, hide, wander
        int numberOfStates = 4;
        
        State[] states = new State[numberOfStates];
        states[0] = new Chase();
        states[1] = new Hide();
        states[2] = new Run();
        states[3] = new Wander();
        
        
//variables keep track of the state the skeleton is in

 int currentState = state;
 
       
       	
       	
       	//checks internal and external environment queues to see if the state will change or remain the same
            int nextState = states[currentState].updateAndCheckTransitions();
            //exits current state and enters new state
            //counter is for timeout
            if (nextState != currentState&& counter>=2) {
            	//prints out exit state 
                //states[currentState].exit();
                //changes curent state to next state
                currentState = nextState;  
             // prints out state so user is aware of the action the skeleton may take
                //states[currentState].enter();
                counter=0;
            }
            //moves the skeleton 
        states[currentState].movement();
       	//extra movement chance for skeleton hunger level 0-50% chance;
       	if(Math.random()*hunger>=5) {
       		states[currentState].movement();
       	}
              states[currentState].environment();
              
              //returns Mob to update information in Blockpanel
             Mobs skeleton= new Mobs(skeletonX,skeletonY,currentState, counter, skeletonHunger, skeletonHitPoints, isBurning, damage*strength, direction);
            return skeleton;
        }
    
    
    




    
                    
}

