package BlockBuster;


public class Mobs {
    private int y;
    private int x;
    private int state;
    private int counter;
    private int hunger;
    private int health;
    private boolean burning;
    private int damage;
    private int direction;
    public Mobs(int x, int y, int state,int counter, int hunger, int health, boolean isBurning, int damage, int direction){
    this.x=x;
    this.y=y;
    this.state=state;
    this.counter=counter;
    this.hunger=hunger;
    this.health=health;
    this.burning=isBurning;
    this.damage=damage;
    this.direction=direction;
    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public boolean isBurning() {
        return burning;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public void setBurning(boolean burning) {
        this.burning = burning;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public int getHunger() {
        return hunger;
    }

    public void setHunger(int hunger) {
        this.hunger = hunger;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    

    
    
}
