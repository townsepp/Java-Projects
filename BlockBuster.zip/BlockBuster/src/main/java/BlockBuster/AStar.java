
package BlockBuster;

import java.util.List;
import java.util.Scanner;


public class AStar {
    
    private static final int WIDTH = 10;
    private static final int HEIGHT = 10;
    
    
 
    private static String characterType;
    private static int startX;
    private static int startY;
    private static int goalX;
    private static int goalY;
    private static int fringeCount;
    private static int treeCount;
    private static int heuristictype;
    private static Tile[][] graph = new Tile[WIDTH][HEIGHT];
    private static int totalCost=1001;
    
       
    public static double heuristic(int x, int y, int gx, int gy) {    
    
        int manhattan = Math.abs(gx - x) + Math.abs(gy - y);
        if (heuristictype == 0) {
            return manhattan;
        }
        
        else {
                  int cost=0;  
            return cost; 
        }
    }
        
    public static class Tile {            
        private char tileType;
        private int x;
        private int y;
        private int treestate; 
        private int parentX;
        private int parentY;
        private double gDist;
        private boolean inPath;
            
        public Tile() {}

        public double getCost() {
            switch(tileType) {
                //X is empty or sky blocks
                case 'X': 
                    return 1;
                    //O is any other blocks
                case 'O':
                    return 1000;
        
            }
            return 0;
        }
    }
        
    // Returns the tile in the fringe with the lowest f = g + h measure
    public static Tile getBest(Tile[][] graph) {
        double bestH = 100000;
        Tile bestTile = new Tile();
        bestTile.x = -1; // Hack to let caller know that nothing was in fringe (failure)
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                if (graph[i][j].treestate == 1) {   // Fringe node
                    double h = graph[i][j].gDist + heuristic(i, j, goalX, goalY);
                    if (h < bestH) {
                        bestH = h;
                        bestTile = graph[i][j];
                    }
                }
            }
        }
        return bestTile;
    }
    
        
    // When a node is expanded, we check each adjacent node. This method takes the graph,
    // the coordinates of the parent tile (the one expanded) and its child (the adjacent tile).
    public static void checkAdjacent(Tile[][] graph, int parentX, int parentY, int childX, int childY) {
    
        // If already in tree, exit
        if (graph[childX][childY].treestate == 2) {
            return;
        }
        // If unexplored, add to fringe with path from parent and distance based on
        // distance from start to parent and cost of entering the node.
        if (graph[childX][childY].treestate == 0) {
            graph[childX][childY].treestate = 1;
            graph[childX][childY].gDist = graph[parentX][parentY].gDist + graph[childX][childY].getCost();
            graph[childX][childY].parentX = parentX;
            graph[childX][childY].parentY = parentY;
        
            // Add to stats of nodes added to fringe
            fringeCount++;
            return;
        }       
        // If fringe, reevaluate based on new path
        if (graph[childX][childY].treestate == 1) {
            if (graph[parentX][parentY].gDist + graph[childX][childY].getCost() < graph[childX][childY].gDist) { 
                // Shorter path through parent, so change path and cost.
                graph[childX][childY].gDist = graph[parentX][parentY].gDist + graph[childX][childY].getCost();
                graph[childX][childY].parentX = parentX;
                graph[childX][childY].parentY = parentY;        
            }
            return;
        }
    }
        
    // Once the goal has been found, we need the path found to the goal. This method
    // works backward from the goal through the parents of each tile. It also totals
    // up the cost of the path and returns it.
    public static double finalPath(Tile[][] graph) {
        double cost = 0;
    
        // Start at goal
        int x = goalX;
        int y = goalY;
    
        // Loop until start reached
        while (x != startX || y != startY) {
        
            // Add node to path and add to cost
            graph[x][y].inPath = true;
            cost += graph[x][y].getCost();
        
            // Work backward to parent and continue
            int tempx = graph[x][y].parentX;
            int tempy = graph[x][y].parentY;
            x = tempx;
            y = tempy;
        }
        graph[startX][startY].inPath = true;
        totalCost=(int)cost;
        return cost;
    }

    // This method prints the map at the end. Each tile contains the tile type, 
    //  a * if that tile was in the final path.
    public static void printGraph(Tile[][] graph) {
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                System.out.print(graph[j][i].tileType);
                //System.out.print(graph[j][i].treestate);
                if (graph[j][i].inPath) {
                    System.out.print("*");
                }
                else {
                    System.out.print(" ");
                }
                System.out.print("  ");
            }
            System.out.print("\n");
        }    
    }

   
    public static void setProperties(int startingX, int startingY, int playerX,int  playerY) {
        // sets start X and goal X as centered in map as can get
        if(startingX-playerX>=0 && (startingX-playerX)%2==1){
        startX=5+Math.abs(startingX-playerX)/2;
        goalX=startX-Math.abs(startingX-playerX);
        }else if(startingX-playerX>=0){
        startX=4+Math.abs(startingX-playerX)/2;
        goalX=startX-Math.abs(startingX-playerX);
        }else if(startingX-playerX<0){
        startX=4-Math.abs(startingX-playerX)/2;
        goalX=startX+Math.abs(startingX-playerX);
        }
        //sets start x and goal X as close to centered as can get
         if(startingY-playerY>0&&(startingY-playerY)%2==0 ){
        startY=5+Math.abs(startingY-playerY)/2;
        goalY=startY-Math.abs(startingY-playerY);
        } else if(startingY-playerY>0){
        startY=6+Math.abs(startingY-playerY)/2;
        goalY=startY-Math.abs(startingY-playerY);
        }else if(startingY-playerY<=0){
        startY=5-Math.abs(startingY-playerY)/2;
        goalY=startY+Math.abs(startingY-playerY);
        }
        //manhattan distance
        heuristictype = 0;
    }   
        
    public static void makeGraph(int startingX, int startingY, int playerX, int playerY, int xSize,List<Blocks> blocks ) { 
//find the 10x10 set of block around start and goal to leave room for path finding around obstacles
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                Tile t = new Tile();
                graph[i][j] = t;
                //if sky or empty type make X
                if(blocks.get((startingX+playerX)/2+i-4+((startingY+playerY)/2-5+j)*xSize).getBlocktype()==BlockType.empty ||
                   blocks.get((startingX+playerX)/2+i-4+((startingY+playerY)/2-5+j)*xSize).getBlocktype()==BlockType.sky  ){
                    graph[i][j].tileType = 'X'; 
                }else{
                    //otherwise make O
                graph[i][j].tileType = 'O'; 
                }   // Tile type based on above map
                graph[i][j].treestate = 0; // Initially unexplored
                graph[i][j].x = i;         // Each tile knows its location in array
                graph[i][j].y = j;
                graph[i][j].parentX = -1;  // Initially no parents on path fro start
                graph[i][j].parentY = -1;
                graph[i][j].inPath = false;    // Initially not in path from start
            }
        }
        
    }   
    

    // Main A* search method. Takes graph as parameter, and returns whether search successful
    public static int search() {
        fringeCount = 1;
        boolean goalFound = false;
    
        // Add start state to tree, path cost = 0
        graph[startX][startY].treestate = 1;
        graph[startX][startY].gDist = 0;    
    
        // Loop until goal added to tree
        while (!goalFound) {
        
            // Get the best tile in the fringe
            Tile bestTile = getBest(graph);
            if (bestTile.x == -1) {
                // The default tile was returned, which means the fringe was empty.
                // This means the search has failed.
                //System.out.print("Search failed!!!!!!\n");
                printGraph(graph);
                return 0;
            }
        
            // Otherwise, add that best tile to the tree (removing it from fringe)
            int x = bestTile.x;
            int y = bestTile.y;
            graph[x][y].treestate = 2;
            treeCount++;
        
            // If it is a goal, done!
            if (x == goalX && y == goalY) {
                goalFound = true;
                //System.out.print("Found the goal!!!!!\n");
            
                // Compute the path taken and its cost, printing the explored graph,
                // the path  cost, and the number of tiles explored (which should be
                // as small as possible!)
                double cost = finalPath(graph);
               /* printGraph(graph);
                System.out.print("Path cost: " + cost+ "\n");
                System.out.print(treeCount + " tiles added to tree\n");
                System.out.print(fringeCount + " tiles added to fringe\n");
            */
                return 1;
            }
        
            // Otherwise, we look at the 4 adjacent tiles to the one just added
            // to the tree (making sure each  is in the graph!) and either add it
            // to the tree or recheck its path.
      /*      
            // Special cases for teleport pads
            if (x == t1x && y == t1y) {
                System.out.println("Teleport checked");
                checkAdjacent(graph, x, y, t2x, t2y);
            }
            if (x == t2x && y == t2y) {
                checkAdjacent(graph, x, y, t1x, t1y);
            }
  */              
            
            if (x > 0) { // Tile to left
                checkAdjacent(graph, x, y, x-1, y);
            }
            if (x < WIDTH-1) { // Tile to right
                checkAdjacent(graph, x, y, x+1, y);
            }
            if (y > 0) { // Tile above
                checkAdjacent(graph, x, y, x, y-1);
            }
            if (y < HEIGHT-1) { // Tile below
                checkAdjacent(graph, x, y, x, y+1);
            }
        
        }
        return 1;
    }
    
    
    public static ButtonCommands planPath(int startingX, int startingY, int playerX, int playerY, List<Blocks> blocks,int xSize) {
    
        
        makeGraph(startingX,startingY, playerX, playerY,xSize,blocks);
        
        setProperties(startingX, startingY, playerX, playerY);
        
        search();
        
        //if path longer than 10 dont return direction
  if(totalCost<=10){
            
            //returns direction to move onto next step of path 
        if(graph[startX+1][startY].inPath==true){
  return ButtonCommands.right;
        }else if(graph[startX-1][startY].inPath==true){
  return ButtonCommands.left;
        }else if(graph[startX][startY-1].inPath==true){
  return ButtonCommands.up;
        }else if(graph[startX][startY+1].inPath==true){
  return ButtonCommands.down;
        }
        //if actino is returned error occured
        return ButtonCommands.action;
            }
    
        return ButtonCommands.mine;
    
    }
    
}
