
package BlockBuster;

import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
public class MainFrame extends javax.swing.JFrame implements KeyListener{
boolean shift=false;
boolean started=false;
    public MainFrame() {
        initComponents();
        this.addKeyListener((KeyListener) this);
        this.setFocusable(true);
        this.blockPanel.start();

    }

   
    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent keyEvent) {
       
       if( blockPanel.getIsDead()&& keyEvent.getKeyCode()==KeyEvent.VK_SPACE){
        this.blockPanel.respawn(5,5,5,5);//mofidy these number to change amout of mobs
       } else if( blockPanel.getIsDead()&& keyEvent.getKeyCode()==KeyEvent.VK_R){
           if(started){
               System.out.println("restarted");
               this.blockPanel.respawn(5,5,5,5);
           this.blockPanel.setBlocks();}
           if(!started){
        this.blockPanel.initialSettings();
           started=true;
               System.out.println("pls");
           }
           
           
       }else if(shift){
        switch(keyEvent.getKeyCode()) {
            case KeyEvent.VK_SHIFT -> shift=true;
            case KeyEvent.VK_A -> this.blockPanel.setDirection(ButtonCommands.left);
            case KeyEvent.VK_W -> this.blockPanel.setDirection(ButtonCommands.up);
            case KeyEvent.VK_S -> this.blockPanel.setDirection(ButtonCommands.down);
            case KeyEvent.VK_D -> this.blockPanel.setDirection(ButtonCommands.right);
            case KeyEvent.VK_1 -> this.blockPanel.buttonFunction(ButtonCommands.dawnHelmet);
            case KeyEvent.VK_2 -> this.blockPanel.buttonFunction(ButtonCommands.dawnChestPlate);
            case KeyEvent.VK_3 -> this.blockPanel.buttonFunction(ButtonCommands.dawnPants);
            case KeyEvent.VK_4 -> this.blockPanel.buttonFunction(ButtonCommands.dawnBoots);
        } 
        }else{
switch(keyEvent.getKeyCode()) {
            case KeyEvent.VK_SHIFT -> shift=true;
            case KeyEvent.VK_A -> this.blockPanel.move(ButtonCommands.left);
            case KeyEvent.VK_W -> this.blockPanel.move(ButtonCommands.up);
            case KeyEvent.VK_D -> this.blockPanel.move(ButtonCommands.right);
            case KeyEvent.VK_S -> this.blockPanel.move(ButtonCommands.down);
            case KeyEvent.VK_I -> this.blockPanel.buttonFunction(ButtonCommands.inv);
            case KeyEvent.VK_C -> this.blockPanel.buttonFunction(ButtonCommands.craft);
            case KeyEvent.VK_R -> this.blockPanel.buttonFunction(ButtonCommands.reset);
            case KeyEvent.VK_1 -> this.blockPanel.buttonFunction(ButtonCommands.invLeft);
            case KeyEvent.VK_2 -> this.blockPanel.buttonFunction(ButtonCommands.invRight);
            case KeyEvent.VK_SPACE -> this.blockPanel.buttonFunction(ButtonCommands.craftItem);
            case KeyEvent.VK_ENTER -> this.blockPanel.buttonFunction(ButtonCommands.action);
            
        }
        }
 
        }
    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_SHIFT){
            shift=false;
            
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        blockPanel = new BlockBuster.BlockPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout blockPanelLayout = new javax.swing.GroupLayout(blockPanel);
        blockPanel.setLayout(blockPanelLayout);
        blockPanelLayout.setHorizontalGroup(
            blockPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1900, Short.MAX_VALUE)
        );
        blockPanelLayout.setVerticalGroup(
            blockPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(blockPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1900, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(blockPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1100, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private BlockBuster.BlockPanel blockPanel;
    // End of variables declaration//GEN-END:variables
}
