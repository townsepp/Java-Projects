
package BlockBuster;
public enum ButtonCommands {
   save,
   load,
   exit,
   right,
   rightUp,
   leftUp,
   leftDown,
   rightDown,
   left,
   up,
   down,
   invLeft,
   invRight,
   mine,
   inv,
   craft,
   choose,
   craftItem,
   reset,
   place,
   action,
   dawnHelmet,
   dawnChestPlate,
   dawnPants,
   dawnBoots
}
