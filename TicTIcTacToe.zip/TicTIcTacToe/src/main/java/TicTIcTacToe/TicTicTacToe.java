
package TicTIcTacToe;

import java.util.*;

public class TicTicTacToe {

    
    public static float evaluate(char[][] board, char ai) {
        
       /*
my heuristic value is generated  by looking at the position and number of in a row sequences there are.
        First I see if there is a win or lose condition and if it is the win the heuristic is 1000 and 
        if loss -1000. From here if there the ai has marks in the center 4 squares the value of the 
        heuristic is increased by 10 for each and subtracted by 10 for each mark the player has in the 
        center. I then add 1 to the value for each 2 in a row the ai has and then subtract 1 for each
        one the player has. Next I add 50 if the ai has 3 in a row and subtract 50 if the player does.
        Finally I see if the ai can get 3 in a row with an open fourth that is empty and if it is I add 
        150 to the value and do the same but subtract 150 from the value for the player. This should make
        the ai automatically choose options that have the most "in a rows" resulting. The heuristic should 
        be higher for an option that creates forks between "in a rows" when possible.
*/
        
int value = 0;
        //character of the player
        char player='X';
        if(ai=='X') {
        	player = 'O';
        }
        // if there is a win available the heuristic value is the max
        if(fourInARow(board,ai)==true) {
     	return 1000;
        }
        // if there is a win available for player the heuristic value is the min
        if(fourInARow(board,player)==true) {
         	return -1000;
            }
        // essentially adds 10 if the ai has a move in the center 4 squares
        //subtracts 10 if player is in center 4 squares
        for(int row=1; row<3;row++) {
        for(int col=1; col<3; col++) {
        	if(board[row][col]==ai) {
        		value+=20;
        	}
        	if(board[row][col]==player) {
        		value-=20;
        	}
        }	
        }
      //adds 1 to value if ai has two in a row -1 if player has two in a row
        //the more 2 in a rows the more 1s added or subtracted
        value+=countTwos(board, ai)-countTwos(board, player);
        //adds 50 if AI can get 3 in a row -50 if player can get 3 in a row
        //the more 3 in a rows the more 50 added or subtracted
        value+=(countThrees(board, ai)*50)-(countThrees(board, player)*50);
      //adds 150 if AI can get 3 in a row with open fourth available -150 if player can get 3 in a row with open fourth
        //the more 3 in a rows the more 150s added or subtracted
        value+=(openThreeInARow(board, ai)*150)-(openThreeInARow(board, player)*150);
         
        
        //return value of heuristic
        return value;
    }
    
// checks to see if there are 3 in a row with and open fourth in that sequence
public static int openThreeInARow(char[][] board, char who) {
    	int count=0;
    	count=openRowOfThree(board,who)+openColOfThree(board,who)+openDiagonalOfThree(board,who);
    return count;
    }
//checks rows for open 3 in a row
public static int openRowOfThree(char[][] board, char who) {
    //total rows that have 3 of a char and an open 4th	
	int total=0;
	
    	for(int i=0; i<4;i++) {
    		int count=0;
    		int empty=0;
    		for(int j=0; j<4;j++) {
    		if(board[i][j]==who) {
    			count++;
    		}
    		if(board[i][j]==' ') {
    			empty++;
    		}
    	}
    		if(count==3 && empty==1) {
    			total++;
    		}
    		}
    	return total;
    }
//check columns for open 3 in a row
public static int openColOfThree(char[][] board, char who) {
	//total col that have 3 of a char and an open 4th		
	int total=0;
    	for(int i=0; i<4;i++) {
    		int count=0;
    		int empty=0;
    		for(int j=0; j<4;j++) {
    		if(board[j][i]==who) {
    			count++;
    		}
    		if(board[j][i]==' ') {
    			empty++;
    		}
    	}
    		if(count==3 && empty==1) {
    			total++;
    		}
    		}
    	return total;
    }
//checks the two possible diagonals for open 3 in a rows    
public static int openDiagonalOfThree(char[][] board, char who) {
	//total diagonals that have 3 of a char and an open 4th		
	int total=0;
    	int count=0;
    	int empty=0;
    	//check diagonal positive slope
    	for(int i=0; i<4; i++) {
    	if(board[i][i]==who) {
    		count++;
    	}
    	if(board[i][i]==' ') {
    		empty++;
    	}
    	}
    	if(count==3 && empty==1) {
			total++;
		}
    	//check diagonal negative slope
    	for(int i=0; i<4; i++) {
        	if(board[i][3-i]==who) {
        		count++;
        	}
        	if(board[i][3-i]==' ') {
        		empty++;
        	}
        	}
        	if(count==3 && empty==1) {
    			total++;
    		}
    	
    	return total;
    	
    }
//count number of two in a row
public static int countTwos(char[][] board, char who) {
	int total=0;
	int count=0;
	
	for(int i=0;i<4;i++) {
		if(countCol(board,i,who)==2) {
		count++;
		}
	}
	for(int i=0;i<4;i++) {
		if(countRow(board,i,who)==2) {
		count++;
		}
	}
	for(int j=0;j<3;j++) {
	for(int i=0;i<4;i++) {
		if(countDiagonal(board,i,j,true,who)==2) {
		count++;
		}
		if(countDiagonal(board,i,j,false,who)==2) {
			count++;
			}
	}
	}
	total+=countDiags(board, who);
	return total;
}
//counts diagonals
public static int countDiags(char[][] board, char who) {
// total 2 in a rows diagonal
	int total=0;
	int count=0;
	int count2=0;
	// checks 2 of the positive sloped diagonals
	for(int i=0;i<3;i++) {
	if(board[1+i][i] == who ) {
		count++;
	}
	if(board[i][1+i] == who ) {
		count2++;
	}
	}
		if(count==2) {
			total++;
		}
		if(count2==2) {
			total++;
		}
	count=0;
	count2=0;
	// checks 2 of the negative sloped diagonals
	for(int i=0;i<3;i++) {
		if(board[2-i][i] == who ) {
			count++;
		}
		if(board[3-i][1+i] == who ) {
			count2++;
		}
		}
			if(count==2) {
				total++;
			}
			if(count2==2) {
				total++;
			}
			count=0;
			count2=0;
			// checks the positive and negative sloped 4 long diagonal for 2 in a row
			for(int i=0;i<4;i++) {
				if(board[i][i] == who ) {
					count++;
				}
				if(board[3-i][3-i] == who ) {
					count2++;
				}
				}
					if(count==2) {
						total++;
					}
					if(count2==2) {
						total++;
					}	
	return total;
}









    public static boolean fourInARow(char[][] board, char who) {
        for (int i = 0; i < 4; i++) {
            if (countRow(board, i, who) == 4) {
                //cout << "Win in row " << i << "\n";
                return true;
            }
        }
        for (int i = 0; i < 4; i++) {            
            if (countCol(board, i, who) == 4) {            
                //cout << "Win in column " << i << "\n";
                return true;
            }   
        }
        if (countDiagonal(board, 0, 0, true, who) == 4) {
            return true;
            }
        if (countDiagonal(board, 0, 3, false, who) == 4) {
            return true;
            }

        return false;
    }
    
    
    public static int countThrees(char[][] board, char who) {
      int row, col;
      int X, O;
      int score = 0;

      /* check all rows */
      for (row = 0; row < 4; row++)
        score += threeRow(board, row, who);

      /* check all columns */
      for (col = 0; col < 4; col++)
        score += threeCol(board, col, who);

      /* check all diagonals */
      score += threeDiagonal(board, true, who);      
      score += threeDiagonal(board, false, who);
      
      return score;
      }
   
   
    public static int threeRow(char[][] board, int row, char who) { 
        int count = 0;
        for (int col = 0; col < 2; col++) {
          if (board[row][col] == who &&
              board[row][col+1] == who &&
              board[row][col+2] == who) count++;            
        }
        return count;
    }
    
  
    public static int threeCol(char[][] board, int col, char who) {  
        int count = 0;
        for (int row = 0; row < 2; row++) {
          if (board[row][col] == who &&
              board[row+1][col] == who &&
              board[row+2][col] == who) count++;            
        }
        return count;
    }
    
    /**
     * Returns number of threes in a row along a diagonal
     * @param board
     * @param up true if up from right, false if up from left
     * @param who
     * @return 
     */
    public static int threeDiagonal(char[][] board, boolean right, char who) {
        int count = 0;
        if (right) {
            for (int row = 0; row < 2; row++)
                for (int col = 0; col < 2; col++)
                    if (board[row][col] == who &&
                        board[row+1][col+1] == who &&
                        board[row+2][col+2] == who) {
                        count++;
                    }
            return count;
        }    
        else {
            for (int row = 0; row < 2; row++)
                for (int col = 2; col < 4; col++)
                    if (board[row][col] == who &&
                        board[row+1][col-1] == who &&
                        board[row+2][col-2] == who) {
                        count++;
                    }
            return count;
        }
    }
    
    /**
     * Returns the number of who in a given row
     * @param board
     * @param row
     * @param who
     * @return 
     */
    public static int countRow(char[][] board, int row, char who) {
        int count = 0;
        for (int col = 0; col < 4; col++) {
            if (board[row][col] == who) count++;
        }
        return count;
    }
    
    /**
     * Returns the number of who in a given column
     * @param board
     * @param col
     * @param who
     * @return 
     */
    public static int countCol(char[][] board, int col, char who) {
        int count = 0;
        for (int row = 0; row < 4; row++) {
            if (board[row][col] == who) count++;
        }
        return count;
    }
    
    /**
     * Number of who on diagonal
     * @param board
     * @param row Lowest row value
     * @param col Lowest col value if right diagonal, highest if left diagonal
     * @param right Does diagonal increase in right or left direction
     * @param who
     * @return 
     */
    public static int countDiagonal(char[][] board, int row, int col, boolean right, char who) {
        int count = 0;
        if (right) {
            while (row < 4 && col < 4) {
                if (board[row][col] == who) {
                    count++;
                }
                row++;
                col++;
            }  
        }
        else {
            while (row < 4 && col >= 0) {
                if (board[row][col] == who) {
                    count++;
                }
                row++;
                col--;
            }  
        }
        return count;
    }
    
    static final int MAXLEVEL = 2;
    
 
/* This is the main function for playing the game. It alternatively
   prompts the user for a move, and uses the minmax algorithm in 
   conjunction with the given evaluation function to determine the
   opposing move. This continues until the board is full. It returns
   the number scored by X minus the number scored by O. */

    public static boolean run(int[] scores, char who) { 
        int i, j;
        char current, other;
        int playerrow, playercol;
        int[] location = new int[2];  // Allows us to pass row, col by reference
        int move = 1;

        /* Initialize the board */
        char[][] board = new char[4][4];
        for (i = 0; i < 4; i++) { 
            for (j = 0; j < 4; j++) {
                board[i][j] = ' ';
            }
        }

        if (who == 'O') display(board);

        while (move <= 16) {
            if (move % 2 == 1) {
                current = 'X';
                other = 'O';
            }
            else {                
                current = 'O';
                other = 'X';
            }

            if (current == who) {        /* The computer's move */
                choose(location, board, who);  /* Call function to compute move */
                System.out.println("Computer chooses " + (location[0]+1) + ", " + (location[1]+1));
                if (board[location[0]][location[1]] == ' ') 
                    board[location[0]][location[1]] = current;
                else {
                    System.out.println("BUG! " + (location[0]+1) + ", " + (location[1]+1) + " OCCUPIED!!!");
                    System.exit(0);
                }
                if (fourInARow(board, who)) {
                    System.out.println("Computer has 4 in a row! Computer wins!");
                    display(board);
                    return true;
                }
            }

            else {                       /* Ask for player's move */
                Scanner in = new Scanner(System.in);
                System.out.print("Player " + current + ", enter row: ");
                playerrow = in.nextInt();
                System.out.print("Player " + current + ", enter column: ");
                playercol = in.nextInt();
                while (board[playerrow-1][playercol-1] != ' ' ||
                    playerrow < 1 || playerrow > 4 ||
                    playercol < 1 || playercol > 4) {
                        System.out.println("Illegal move! You cannot use that square!");
                
                        System.out.print("Player " + current + ", enter row: ");
                        playerrow = in.nextInt();
                        System.out.print("Player " + current + ", enter column: ");
                        playercol = in.nextInt();
                }
                playercol--; playerrow--;
                board[playerrow][playercol] = current;
                if (fourInARow(board, current)) {
                    System.out.println("Player has 4 in a row! Player wins!");
                    display(board);
                    return true;            
                }
            }
 
            display(board);    /* Redisplay board to show the move */

            move++; /* Increment the move number and do next move. */
        }
        scores[0] = countThrees(board, 'X');
        scores[1] = countThrees(board, 'O');
        return false;
    }


    
/* This displays the current configuration of the board. */

    public static void display(char[][] board) {
        int row, col;  
        int scores[] = new int[2];
        System.out.print("\n");
        for (row = 3; row >= 0; row--) {
            System.out.print("  +-+-+-+-+\n");
            System.out.print((row+1) + " ");
            for (col = 0; col < 4; col++) {
            if (board[row][col] == 'X')  /* if contents are 0, print space */
                System.out.print("|X");
            else if (board[row][col] == 'O')
                System.out.print("|0");
            else System.out.print("| ");
            }
            System.out.print("|\n");
        }
        System.out.print("  +-+-+-+-+\n");  /* print base, and indices */
        System.out.print("   1 2 3 4\n");
        scores[0] = countThrees(board, 'X');
        scores[1] = countThrees(board, 'O');
        System.out.println("X: " + scores[0]);
        System.out.println("O: " + scores[1]);
    }
   
/* Basic function for choosing the computer's move. It essentially
   initiates the first level of the MINMAX algorithm, and returns
   the column number it chooses. */

    public static void choose(int[] location, char[][] board, char who) {
        int move; 
        float value;
        getmax(location, board, 1, who);
    }


/* This handles any MAX level of a MINMAX tree. This essentially handles moves for the computer. */

    public static float getmax(int[] location, char[][] board, int level, char who) {
        char[][] tempboard = new char[4][4];
        int r,c = 0;
        float max = -1001;
        float val;
        int[] tempLocation = new int[2];
        for (r = 0; r < 4; r++)
            for (c = 0; c < 4; c++) {  /* Try each row and column in board */
                if (board[r][c] == ' ') {     /* Make sure square not full */

                /* To avoid changing original board  during tests, make a copy */
                copy(tempboard, board); 

                /* Find out what would happen if we chose this column */
                tempboard[r][c] = who;

                /* If this is the bottom of the search tree (that is, a leaf) we need
                    to use the evaluation function to decide how good the move is */
                if (level == MAXLEVEL) 
                    val = evaluate(tempboard, who);

                /* Otherwise, this move is only as good as the worst thing our
                    opponent can do to us. */
                else
                    val = getmin(tempLocation, tempboard, level+1, who);

                /* Return the highest evaluation, and set call by ref. parameter
                    "move" to the corresponding column */
                if (val > max) {
                    max = val;
                    if (level==1) {location[0] = r; location[1] = c;}
                 }

            }
        }
        return max;
    }

/* This handles any MIN level of a MINMAX tree. This essentially handles moves for the player. */

    public static float getmin(int[] location, char[][] board, int level, char who) {
        char[][] tempboard = new char[4][4];
        int r,c = 0;   
        int[] tempLocation = new int[2];
        float min = 10001;
        float val;

        /* Since this is opponent's move, we need to figure out which they are */
        char other;
        if (who == 'X') other = 'O'; else other = 'X'; 

        for (r = 0; r < 4; r++)
            for (c = 0; c < 4; c++) {  /* Try each row and column in board */
                if (board[r][c] == ' ') {     /* Make sure square not full */

                    /* To avoid changing original board  during tests, make a copy */
                    copy(tempboard, board);

                    /* Find out what would happen if opponent chose this column */
                    tempboard[r][c] = other;

                    /* If this is the bottom of the search tree (that is, a leaf) we need
                    to use the evaluation function to decide how good the move is */
                    if (level == MAXLEVEL)  
                        val = evaluate(tempboard, who);

                    /* Otherwise, find the best thing that we can do if opponent
                        chooses this move. */
                    else
                        val = getmax(tempLocation, tempboard, level+1, who);

                    /* Return the lowest evaluation (which we will assume will be 
                        chosen by opponent, and set call by ref. parameter
                        "move" to the corresponding column */
                    if (val < min) {
                        min = val;
                        // *move = col;
                    }
                }
            }
        return min;
   }


/* This function makes a copy of a given board. This is necessary to be
   able to "try out" the effects of different moves without messing up
   the actual current board. */

    public static void copy(char[][] a, char[][] b) {
        int i, j;
        for (i = 0; i < 4; i++) { 
            for (j = 0; j < 4; j++) {
                a[i][j] = b[i][j];  
            }
        }
    }
   


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        char player, computer;
        int[] scores = new int[2];
        /* Decide who goes first */
        System.out.print("Do you want to play X or O: ");
        Scanner in = new Scanner(System.in);
        player = in.nextLine().charAt(0);
        if (player == 'X') computer = 'O';
        else computer = 'X';
        boolean win = false;
        win = run(scores, computer);
        if (!win)
            System.out.println("\nFinal score: \nX: " + scores[0] + "\nO: " + scores[1] + "\n");
        }
}