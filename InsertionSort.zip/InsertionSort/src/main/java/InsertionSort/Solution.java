package InsertionSort;

import java.util.*;

public class Solution {

    //displays the array to the user
    public static void display(int[] list) {
        //outputs the "[" to terminal
        System.out.print("[");
        //cycles through each element in the array "list"
        for (int i = 0; i < list.length; i++) {
            //outputs the i th element of "list" and a "," if it's not the last element
            if (i < list.length - 1) {
                System.out.print(+list[i] + ", ");
            } else {
                 //outputs the i th element of "list" and a "]" if it's the last element
                System.out.print(+list[i] + "]");
            }
        }
    }
    //takes in an array and sorts it using insertion sort
    public static int[] insertionSort(int[] list) {
        //keeps track of what step the 
        int count = 0;
        //if N==0 display the starting array
       
        //cycles through each of the element of "list" 
        outerLoop:
        for (int i = 1; i < list.length; i++) {
            // the value of the element of the array that is being inserted into the array
            int currentValue = list[i];
            //index of the element that will be compared to currentValue
            int checkValue = i - 1;
            //while the value of currentValue is not greater than the checkValue element value keep swapping
            while (checkValue >= 0 && list[checkValue] > currentValue) {

                //change value of element before checkvalue to the value of the element checkValue
                list[checkValue + 1] = list[checkValue];
                //decrement checkvalue
                checkValue--;
                //set value of the element of 
                list[checkValue + 1] = currentValue;
                //increment count to know that the step number has changed
                count++;
                //if the step number is equal to n display the list

            }

        }

        return list;
    }

    public static void main(String[] args) {
        //which step of the insertion sort that is output
        
        //the array that is to be sorted 
        int[] list = {11, 12, 9, 5, 6,13,1,3,4,2,8,7,10};
        //sorts the list and displays the nth step of sorting of the array
        display(insertionSort(list));
    }

}
