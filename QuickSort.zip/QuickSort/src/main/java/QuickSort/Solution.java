package QuickSort;

public class Solution {
    
    public static void display(int[][] list) {
        System.out.print("{");
        for (int j = 0; j < list.length; j++) {
            System.out.print("[");
            for (int i = 0; i < list[j].length; i++) {
                if (i < list[j].length - 1) {
                    System.out.print(list[j][i] + ", ");
                } else {
                    System.out.print(list[j][i] + "]");
                }
            }
        }
        System.out.print("}");

    }

    //sorts sub list by acending order
    public static int partitionAscending(int[] list, int firstIndex, int lastIndex) {
        //ses pivot equal to last element in current sub list
        int pivot = list[lastIndex];
        //sets i equal to index of first element of sub list 
        int i = firstIndex;
        //sorts sub list by ascending order
        for (int j = firstIndex; j < lastIndex; j++) {
            if (list[j] < pivot) {
                int temp = list[i];
                list[i] = list[j];
                list[j] = temp;
                i++;
            }
        }
        //changes places of ith list element and last element
        int temp = list[i];
        list[i] = list[lastIndex];
        list[lastIndex] = temp;

        return i;
    }

    //sorts sub list by descending order
    public static int partitionDescending(int[] list, int firstIndex, int lastIndex) {
        //sets pivot equal to last element in current sub list
        int pivot = list[lastIndex];
        //sets i equal to index of first element of sub list 
        int i = firstIndex;
        //sorts sub list by descending order
        for (int j = firstIndex; j < lastIndex; j++) {
            if (list[j] > pivot) {
                int temp = list[i];
                list[i] = list[j];
                list[j] = temp;
                i++;
            }
        }
        //changes places of ith list element and last element
        int temp = list[i];
        list[i] = list[lastIndex];
        list[lastIndex] = temp;
        return i;
    }

    //sorts list by ascending order
    public static int[] quickSortAscending(int[] list, int firstIndex, int lastIndex) {
        //creates a partition in the current list and create two more sub lists around that partition
        //recurrsively calls this function until sub lists are small enough
        if (firstIndex < lastIndex) {
            int partitionIndex = partitionAscending(list, firstIndex, lastIndex);
            quickSortAscending(list, firstIndex, partitionIndex - 1);
            quickSortAscending(list, partitionIndex + 1, lastIndex);

        }
        return list;
    }
    
    //sorts list by descending order    
    public static int[] quickSortDescending(int[] list, int firstIndex, int lastIndex) {
        //creates a partition in the current list and create two more sub lists around that partition
        //recurrsively calls this function until sub lists are small enough
        if (firstIndex < lastIndex) {
            int partitionIndex = partitionDescending(list, firstIndex, lastIndex);
            quickSortDescending(list, firstIndex, partitionIndex - 1);
            quickSortDescending(list, partitionIndex + 1, lastIndex);

        }
        return list;
    }

    //sorts an input array ascending then descending nd returns both as 2d array
    public static int[][] sort(int[] list) {
        // 2d array that will be returned
        int[][] arr = new int[2][list.length];
        //first element of array set to ascending list
        arr[0] = quickSortAscending(list, 0, list.length - 1);
        int[] temp = list.clone();
        //2nd element of array set to descending list
        arr[1] = quickSortDescending(temp, 0, list.length - 1);

        return arr;
    }

    public static void main(String[] args) {
        int[] arr = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
        Solution ob = new Solution();
        display(ob.sort(arr));

    
    }
}
