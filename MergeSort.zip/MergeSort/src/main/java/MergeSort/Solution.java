package MergeSort;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
 
public class Solution {

    //creates random array of numbers 1-n
    
    public static int[] randomArray(int n){
       List<Integer> list= new ArrayList<Integer>();
        int i=1;
        while(i<=n){
            Random rand= new Random();
            list.add(rand.nextInt(i), i);
            i++;
        }
         int[] array = new int[n];
        for(int j=0; j<n;j++){
        array[j]=list.get(j);
        }
    return array;
    }
    //displays both arrays
    
    public static void display(int[][] arr) {
        int[] list = arr[0];
        int[] list2 = arr[1];
        //outputs the "[" to terminal
        System.out.print("{[");
        //cycles through each element in the array "list"
        for (int i = 0; i < list.length; i++) {
            //outputs the i th element of "list" and a "," if it's not the last element
            if (i < list.length - 1) {
                System.out.print(+list[i] + ", ");
            } else {
                //outputs the i th element of "list" and a "]" if it's the last element
                System.out.print(+list[i] + "], ");
            }
        }
        System.out.print("[");
        for (int i = 0; i < list2.length; i++) {
            //outputs the i th element of "list" and a "," if it's not the last element
            if (i < list2.length - 1) {
                System.out.print(+list2[i] + ", ");
            } else {
                //outputs the i th element of "list" and a "]" if it's the last element
                System.out.print(+list2[i] + "]");
            }
        }
        System.out.print("}");
    }
     
    //has first ,last and middle index as paramters to denote which subarrays are to merge
    //then merges them into one array in ascending values
    public static void mergeArraysAscending(int[] list, int firstIndex, int lastIndex, int middleIndex) {

        //create the two sub arrays using the firstIndex, lastIndex, middleIndex to denote length
        int[] list1 = new int[middleIndex - firstIndex + 1];
        int[] list2 = new int[lastIndex - middleIndex];
        //sets values of first sub array
        for (int i = 0; i < list1.length; i++) {
            list1[i] = list[i + firstIndex];
        }
        //sets values of second subarray
        for (int i = 0; i < list2.length; i++) {
            list2[i] = list[i + middleIndex + 1];
        }
        //index on the first sub array
        int list1Index = 0;
        //index of second sub array
        int list2Index = 0;
        //index of full array
        int listIndex = firstIndex;
        // while list 1 or list 2 have not been sorted through keeps sorting
        while (list1Index < list1.length && list2Index < list2.length) {
            //if value in list 1 is < value in list 2 set value of full array equal to list 1 index
            //then incremen index of list 1
            if (list1[list1Index] < list2[list2Index]) {
                list[listIndex] = list1[list1Index];
                list1Index++;
                //otherwise set value at index of full list equal to list 2 value and increment list 2 index
            } else {
                list[listIndex] = list2[list2Index];
                list2Index++;
            }
            //increment the index of full list after every loop
            listIndex++;
        }
        //if any value of list 1 are left set the next value indexes of full list equal to them
        while (list1Index < list1.length) {
            list[listIndex] = list1[list1Index];
            list1Index++;
            listIndex++;
        }
        //if any value of list 2 are left set the next value indexes of full list equal to the
        while (list2Index < list2.length) {
            list[listIndex] = list2[list2Index];
            list2Index++;
            listIndex++;
        }

    }

    //has first ,last and middle index as paramters to denote which subarrays are to merge
    //then merges them into one array in descening values
    public static void mergeArraysDescending(int[] list, int firstIndex, int lastIndex, int middleIndex) {
        //create the two sub arrays using the firstIndex, lastIndex, middleIndex to denote length
        int[] list1 = new int[middleIndex - firstIndex + 1];
        int[] list2 = new int[lastIndex - middleIndex];
        //sets values of first sub array
        for (int i = 0; i < list1.length; i++) {
            list1[i] = list[i + firstIndex];
        }
        //sets values of second subarray
        for (int i = 0; i < list2.length; i++) {
            list2[i] = list[i + middleIndex + 1];
        }
        //index on the first sub array
        int list1Index = 0;
        //index of second sub array
        int list2Index = 0;
        //index of full array
        int listIndex = firstIndex;
        // while list 1 or list 2 have not been sorted through keeps sorting
        while (list1Index < list1.length && list2Index < list2.length) {
            //if value in list 1 is > value in list 2 set value of full array equal to list 1 index
            //then incremen index of list 1
            if (list1[list1Index] > list2[list2Index]) {
                list[listIndex] = list1[list1Index];
                list1Index++;
                //otherwise set value at index of full list equal to list 2 value and increment list 2 index
            } else {
                list[listIndex] = list2[list2Index];
                list2Index++;
            }
            //increment the index of full list after every loop
            listIndex++;
        }
        //if any value of list 1 are left set the next value indexes of full list equal to them
        while (list1Index < list1.length) {
            list[listIndex] = list1[list1Index];
            list1Index++;
            listIndex++;
        }
        //if any value of list 2 are left set the next value indexes of full list equal to the
        while (list2Index < list2.length) {
            list[listIndex] = list2[list2Index];
            list2Index++;
            listIndex++;
        }

    }

    //recursively seperates the array into smaller arrays then merges in ascending value
    public static void sortArraysAscending(int[] list, int firstIndex, int lastIndex) {

        //if array is not completely split keep recurrsively splitting it into smaller arrays
        if (firstIndex < lastIndex) {
            //denotes which index is the middle and seperate the two sub arrays
            int middleIndex = firstIndex + (lastIndex - firstIndex) / 2;
            //first sub array recursively passed into function again
            sortArraysAscending(list, firstIndex, middleIndex);
            //second sub array recursively passed into function again
            sortArraysAscending(list, middleIndex + 1, lastIndex);
            //merges the two above sub arrays
            mergeArraysAscending(list, firstIndex, lastIndex, middleIndex);

        }

    }

    //recursively seperates the array into smaller arrays then merges in descending value
    public static void sortArraysDescending(int[] list, int firstIndex, int lastIndex) {
        //if array is not completely split keep recurrsively splitting it into smaller arrays
        if (firstIndex < lastIndex) {
            //denotes which index is the middle and seperate the two sub arrays
            int middleIndex = firstIndex + (lastIndex - firstIndex) / 2;
            //first sub array recursively passed into function again
            sortArraysDescending(list, firstIndex, middleIndex);
            //second sub array recursively passed into function again
            sortArraysDescending(list, middleIndex + 1, lastIndex);
            //merges the two above sub arrays
            mergeArraysDescending(list, firstIndex, lastIndex, middleIndex);

        }

    }

    // sorts input array in ascending and descending value and returns both arrays
    public static int[][] mergeSort(int[] list) {
        //sets values of starting and last index
        int firstIndex = 0;
        int lastIndex = list.length - 1;
        //two dimensional array the lists will be held in
        int arr[][] = new int[2][list.length];
        //sorts arrays in ascending value
        sortArraysAscending(list, firstIndex, lastIndex);
        // value of ascending value sorted list saved
        arr[0] = list;
        //copies list
        int[] temp = list.clone();
        //sorts array in descending value
        sortArraysDescending(temp, firstIndex, lastIndex);
        // value of descending value sorted list saved
        arr[1] = temp;
        //returns both arrays in arr
        return arr;
    }

    public static void main(String[] args) {
        int n=15;
        int[] list = randomArray(n);
        int[] list2= {};
        int[][] start = new int[2][n];
        start[0]=list;
        start[1]=list2;
        display(start);
        System.out.println("");
        //sorts the list and displays the nth step of sorting of the array
        Solution ob = new Solution();
        int[][] test = new int[1][1];
        test = ob.mergeSort(list);

        display(test);
    }

}
