
package ChessImproved;

import java.awt.Color;

public class PawnUpgradeSelect extends javax.swing.JFrame {

    public PawnUpgradeSelect() {
        initComponents();
        
    }
 int col=0;
 int row=0;

    public  void squareLocation(int col, int row){
    this.col=col;
    this.row=row;
    }
    public void chosenPiece(PieceType type){
        
    Board.pieceChoice(type, col ,row);
    dispose();
    }
    
    
    
    @Override
    public void setDefaultCloseOperation(int operation){
    dispose();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Queen = new javax.swing.JButton();
        Rook = new javax.swing.JButton();
        Bishop = new javax.swing.JButton();
        Knight = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(700, 200));
        setLayout(new java.awt.GridLayout(1, 4));

        Queen.setText("Queen");
        Queen.setOpaque(true);
        Queen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QueenActionPerformed(evt);
            }
        });
        add(Queen);

        Rook.setText("Rook");
        Rook.setOpaque(true);
        Rook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RookActionPerformed(evt);
            }
        });
        add(Rook);

        Bishop.setText("Bishop");
        Bishop.setOpaque(true);
        Bishop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BishopActionPerformed(evt);
            }
        });
        add(Bishop);

        Knight.setText("Knight");
        Knight.setOpaque(true);
        Knight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KnightActionPerformed(evt);
            }
        });
        add(Knight);
    }// </editor-fold>//GEN-END:initComponents

    private void QueenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QueenActionPerformed
       chosenPiece(PieceType.queen);
    }//GEN-LAST:event_QueenActionPerformed

    private void RookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RookActionPerformed
        chosenPiece(PieceType.rook);
    }//GEN-LAST:event_RookActionPerformed

    private void BishopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BishopActionPerformed
        chosenPiece(PieceType.bishop);
    }//GEN-LAST:event_BishopActionPerformed

    private void KnightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KnightActionPerformed
        chosenPiece(PieceType.knight);
    }//GEN-LAST:event_KnightActionPerformed
public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Color.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Color.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Color.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Color.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Bishop;
    private javax.swing.JButton Knight;
    private javax.swing.JButton Queen;
    private javax.swing.JButton Rook;
    // End of variables declaration//GEN-END:variables
}
