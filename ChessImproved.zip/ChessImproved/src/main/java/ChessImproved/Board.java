
package ChessImproved;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;


public class Board extends javax.swing.JPanel {

   static javax.swing.JButton[][] buttons;
   static Square[][] squares = new Square[8][8];
   static Color playerOneColor=Color.white;
   static Color playerTwoColor=Color.black;
   static Color playerOneBackgroundColor= Color.ORANGE;
   static Color playerTwoBackgroundColor= Color.BLUE;
   Boolean pieceSelected=false;
   int colNum=0;
   int rowNum=0;
   static char  player='W';
   
   
    public Board() {
        initComponents();
        initialSettings();
    }
    public void createButtons(){
    buttons= new javax.swing.JButton[][]{
        {a1,a2,a3,a4,a5,a6,a7,a8},
        {b1,b2,b3,b4,b5,b6,b7,b8},
        {c1,c2,c3,c4,c5,c6,c7,c8},
        {d1,d2,d3,d4,d5,d6,d7,d8},
        {e1,e2,e3,e4,e5,e6,e7,e8},
        {f1,f2,f3,f4,f5,f6,f7,f8},
        {g1,g2,g3,g4,g5,g6,g7,g8},
        {h1,h2,h3,h4,h5,h6,h7,h8}
    };
    for(int i=0; i<8; i++){
        for(int j=0; j<8; j+=2){
            if(i%2==0){
        buttons[i][j].setBackground(playerOneBackgroundColor);
        buttons[i][j+1].setBackground(playerTwoBackgroundColor);
            }else{
        buttons[i][j].setBackground(playerTwoBackgroundColor);
        buttons[i][j+1].setBackground(playerOneBackgroundColor);
            }
        }}
    for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            
    buttons[i][j].addActionListener(new ActionListener() { 
  @Override
  public void actionPerformed(ActionEvent e) { 
      int col=0;
      int row=0;
      outerLoop:
      for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
      if(e.getSource().equals(buttons[i][j])){
          col=i;
          row=j;
          break outerLoop;
      }
      }
      }  
      
      
      
     if(!pieceSelected && squares[col][row].getPieceType()!=PieceType.empty && 
             squares[col][row].getColor()==player)
     {
         pieceSelected=true;
         colNum=col;
         rowNum=row;
         squares[col][row].setSelected(true);
         highlightSquare(col,row);
     } else if(pieceSelected && squares[col][row].isPossibleMove()){
     move(col,row);
     pieceSelected=false;
     loadBackColors();
     }else if(pieceSelected && squares[col][row].isCanCastle()){
     castle(col,row);
     pieceSelected=false;
     loadBackColors();
     }else if (pieceSelected && squares[col][row].getColor()==player){
     for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            squares[i][j].setSelected(false);
        }
      }
     squares[col][row].setSelected(true);
     colNum=col;
     rowNum=row;
     highlightSquare(col,row);
     resetPossibleMoves();
     }else if (pieceSelected && !squares[col][row].isPossibleMove()){
     pieceSelected=false;
     for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            squares[i][j].setSelected(false);
        }
      }
     loadBackColors();
     }
     
     
     
     if(pieceSelected){
     showPossibleMoves(col,row);
     }else{
     resetPossibleMoves();
     }
     
     
     
  }} );
    }
    }
    }
    public void initialSettings(){
        loadColors();
    createButtons();
for(int i=0; i<8; i++){
for(int j=0; j<8; j++){
 Square square= new Square(i,j);
 squares[i][j]=square;
}
}

squares[0][0].setPieceType(PieceType.rook);
squares[0][0].setColor('W');
squares[1][0].setPieceType(PieceType.knight);
squares[1][0].setColor('W');
squares[2][0].setPieceType(PieceType.bishop);
squares[2][0].setColor('W');
squares[3][0].setPieceType(PieceType.queen);
squares[3][0].setColor('W');
squares[4][0].setPieceType(PieceType.king);
squares[4][0].setColor('W');
squares[5][0].setPieceType(PieceType.bishop);
squares[5][0].setColor('W');
squares[6][0].setPieceType(PieceType.knight);
squares[6][0].setColor('W');
squares[7][0].setPieceType(PieceType.rook);
squares[7][0].setColor('W');
for(int i=0; i<8; i++){
squares[i][1].setPieceType(PieceType.pawn);
squares[i][1].setColor('W');
}

squares[0][7].setPieceType(PieceType.rook);
squares[0][7].setColor('B');
squares[1][7].setPieceType(PieceType.knight);
squares[1][7].setColor('B');
squares[2][7].setPieceType(PieceType.bishop);
squares[2][7].setColor('B');
squares[3][7].setPieceType(PieceType.queen);
squares[3][7].setColor('B');
squares[4][7].setPieceType(PieceType.king);
squares[4][7].setColor('B');
squares[7][7].setPieceType(PieceType.rook);
squares[7][7].setColor('B');
squares[6][7].setPieceType(PieceType.knight);
squares[6][7].setColor('B');
squares[5][7].setPieceType(PieceType.bishop);
squares[5][7].setColor('B');
for(int i=0; i<8; i++){
squares[i][6].setPieceType(PieceType.pawn);
squares[i][6].setColor('B');
}

drawPiecePositions();
}



    public void showPossibleMoves(int col, int row){
    switch(squares[col][row].getPieceType()){
        case rook->rookMovement(col,row);
        case knight-> knightMovement(col,row);
        case bishop-> bishopMovement(col,row);
        case king-> kingMovement(col,row);
        case queen->{ rookMovement(col,row);
        bishopMovement(col,row);}
        case pawn-> pawnMovement(col,row);
    }
    highlightPossibleMoves();
    }
    public void resetPossibleMoves(){
    for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
        squares[i][j].setPossibleMove(false);
        squares[i][j].setCanCastle(false);
        }
    }
    
    }
    public void highlightPossibleMoves(){
    for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            if(squares[i][j].isPossibleMove()){
            buttons[i][j].setBackground(Color.red);
            }
            if(squares[i][j].isCanCastle()){
            buttons[i][j].setBackground(Color.blue);
            }
        
        }
    }
    }
    public void rookMovement(int col, int row){
        
    for(int i=1;i<8-col;i++){
    if(squares[col+i][row].getPieceType()==PieceType.empty){
    squares[col+i][row].setPossibleMove(true);
    }else if(squares[col+i][row].getColor()!=player){
    squares[col+i][row].setPossibleMove(true);
    break;
    }else{
    break;
    }
    }
    
    for(int i=1;i<col+1;i++){
    if(squares[col-i][row].getPieceType()==PieceType.empty){
    squares[col-i][row].setPossibleMove(true);
    }else if(squares[col-i][row].getColor()!=player){
    squares[col-i][row].setPossibleMove(true);
     break;
    }else{
    break;
    }
    }
    
    for(int i=1;i<8-row;i++){
    if(squares[col][row+i].getPieceType()==PieceType.empty){
    squares[col][row+i].setPossibleMove(true);
    }else if(squares[col][row+i].getColor()!=player){
    squares[col][row+i].setPossibleMove(true);
     break;
    }else{
    break;
    }
    }
    
    for(int i=1;i<row+1;i++){
    if(squares[col][row-i].getPieceType()==PieceType.empty){
    squares[col][row-i].setPossibleMove(true);
    }else if(squares[col][row-i].getColor()!=player){
    squares[col][row-i].setPossibleMove(true);
     break;
    }else{
    break;
    }
    }
    
    }
    public void knightMovement(int col, int row){
    if(col+2<8&&row+1<8){
    if(squares[col+2][row+1].getColor()!=player){
    squares[col+2][row+1].setPossibleMove(true);
    }
    }
    if(col+2<8&&row-1>-1){
    if(squares[col+2][row-1].getColor()!=player){
    squares[col+2][row-1].setPossibleMove(true);
    }
    }
    if(col-2>-1&&row+1<8){
    if(squares[col-2][row+1].getColor()!=player){
    squares[col-2][row+1].setPossibleMove(true);
    }
    }
    if(col-2>-1&&row-1>-1){
    if(squares[col-2][row-1].getColor()!=player){
    squares[col-2][row-1].setPossibleMove(true);
    }
    }
    
    if(col+1<8&&row+2<8){
    if(squares[col+1][row+2].getColor()!=player){
    squares[col+1][row+2].setPossibleMove(true);
    }
    }
    if(col+1<8&&row-2>-1){
    if(squares[col+1][row-2].getColor()!=player){
    squares[col+1][row-2].setPossibleMove(true);
    }
    }
    if(col-1>-1&&row+2<8){
    if(squares[col-1][row+2].getColor()!=player){
    squares[col-1][row+2].setPossibleMove(true);
    }
    }
    if(col-1>-1&&row-2>-1){
    if(squares[col-1][row-2].getColor()!=player){
    squares[col-1][row-2].setPossibleMove(true);
    }
    }
    }
    public void bishopMovement(int col, int row){
       
    for(int i=1;row+i<8 && col+i<8;i++){
    if(squares[col+i][row+i].getPieceType()==PieceType.empty){
    squares[col+i][row+i].setPossibleMove(true);
    }else if(squares[col+i][row+i].getColor()!=player){
    squares[col+i][row+i].setPossibleMove(true);
    break;
    }else{
    break;
    }
    }
    
    
    
    for(int i=-1;row+i>-1 && col+i>-1;i--){
    if(squares[col+i][row+i].getPieceType()==PieceType.empty){
    squares[col+i][row+i].setPossibleMove(true);
    }else if(squares[col+i][row+i].getColor()!=player){
    squares[col+i][row+i].setPossibleMove(true);
    break;
    }else{
    break;
    }
    }
       
      for(int i=1;row-i>-1 && col+i<8;i++){
    if(squares[col+i][row-i].getPieceType()==PieceType.empty){
    squares[col+i][row-i].setPossibleMove(true);
    }else if(squares[col+i][row-i].getColor()!=player){
    squares[col+i][row-i].setPossibleMove(true);
    break;
    }else{
    break;
    }
    }  
      
      for(int i=1;row+i<8 && col-i>-1;i++){
    if(squares[col-i][row+i].getPieceType()==PieceType.empty){
    squares[col-i][row+i].setPossibleMove(true);
    }else if(squares[col-i][row+i].getColor()!=player){
    squares[col-i][row+i].setPossibleMove(true);
    break;
    }else{
    break;
    }
    }  
      
    }
    public void pawnMovement(int col, int row){
    if(squares[col][row].getColor()=='W'){
    if(squares[col][row+1].getPieceType()==PieceType.empty){
    squares[col][row+1].setPossibleMove(true);
    }
    if(row+2<8){
    if(squares[col][row+1].getPieceType()==PieceType.empty && squares[col][row+2].getPieceType()==PieceType.empty &&row==1){
    squares[col][row+2].setPossibleMove(true);
    }
    }
    if(col+1<8){
    if(squares[col+1][row+1].getPieceType()!=PieceType.empty && squares[col+1][row+1].getColor()=='B'){
     squares[col+1][row+1].setPossibleMove(true);
    }
    }
    if(col-1>-1){
    if(squares[col-1][row+1].getPieceType()!=PieceType.empty && squares[col-1][row+1].getColor()=='B'){
     squares[col-1][row+1].setPossibleMove(true);
    }
    }
    }
    
    if(squares[col][row].getColor()=='B'){
    if(squares[col][row-1].getPieceType()==PieceType.empty){
    squares[col][row-1].setPossibleMove(true);
    }
     if(row-2>-1){
    if(squares[col][row-1].getPieceType()==PieceType.empty && squares[col][row-2].getPieceType()==PieceType.empty &&row==6){
    squares[col][row-2].setPossibleMove(true);
    }
     }
    if(col+1<8){
    if(squares[col+1][row-1].getPieceType()!=PieceType.empty && squares[col+1][row-1].getColor()=='W'){
     squares[col+1][row-1].setPossibleMove(true);
    }
    }
    if(col-1>-1){
    if(squares[col-1][row-1].getPieceType()!=PieceType.empty && squares[col-1][row-1].getColor()=='W'){
     squares[col-1][row-1].setPossibleMove(true);
    }
    }
    }
    }
    public void kingMovement(int col, int row){
        if(row+1<8){
    if(squares[col][row+1].getPieceType()==PieceType.empty||squares[col][row+1].getColor()!=player){
    squares[col][row+1].setPossibleMove(true);
    }
        }
         if(row+1<8&&col+1<8){
    if(squares[col+1][row+1].getPieceType()==PieceType.empty||squares[col+1][row+1].getColor()!=player){
    squares[col+1][row+1].setPossibleMove(true);
    }
         }
         if(row+1<8&&col-1>-1){
    if(squares[col-1][row+1].getPieceType()==PieceType.empty||squares[col-1][row+1].getColor()!=player){
    squares[col-1][row+1].setPossibleMove(true);
    }
         }
         if(row-1>-1){
    if(squares[col][row-1].getPieceType()==PieceType.empty||squares[col][row-1].getColor()!=player){
    squares[col][row-1].setPossibleMove(true);
    }
         }
         if(row-1>-1&&col-1>-1){
    if(squares[col-1][row-1].getPieceType()==PieceType.empty||squares[col-1][row-1].getColor()!=player){
    squares[col-1][row-1].setPossibleMove(true);
    }
         }
         if(row-1>-1&&col+1<8){
    if(squares[col+1][row-1].getPieceType()==PieceType.empty||squares[col+1][row-1].getColor()!=player){
    squares[col+1][row-1].setPossibleMove(true);
    }
         }
         if(col+1<8){
    if(squares[col+1][row].getPieceType()==PieceType.empty||squares[col+1][row].getColor()!=player){
    squares[col+1][row].setPossibleMove(true);
    }
         }
         if(col-1>-1){
    if(squares[col-1][row].getPieceType()==PieceType.empty||squares[col-1][row].getColor()!=player){
    squares[col-1][row].setPossibleMove(true);
    }
         }
         if(player=='W'&& !squares[4][0].isHasMoved()&& !squares[0][0].isHasMoved()&& 
                 squares[2][0].getPieceType()==PieceType.empty &&squares[1][0].getPieceType()==PieceType.empty
                 &&squares[3][0].getPieceType()==PieceType.empty){
         squares[col-2][row].setCanCastle(true);
         }
         if(player=='W'&& !squares[4][0].isHasMoved()&& !squares[7][0].isHasMoved()&& 
                 squares[5][0].getPieceType()==PieceType.empty &&squares[6][0].getPieceType()==PieceType.empty){
         squares[col+2][row].setCanCastle(true);
         }
         if(player=='B'&& !squares[4][7].isHasMoved()&& !squares[0][7].isHasMoved()&& 
                 squares[2][7].getPieceType()==PieceType.empty &&squares[1][7].getPieceType()==PieceType.empty
                 &&squares[3][7].getPieceType()==PieceType.empty){
         squares[col-2][row].setCanCastle(true);
         }
         if(player=='B'&& !squares[4][7].isHasMoved()&& !squares[7][7].isHasMoved()&& 
                 squares[5][7].getPieceType()==PieceType.empty &&squares[6][7].getPieceType()==PieceType.empty){
         squares[col+2][row].setCanCastle(true);
         }
    }
   @Override
    public void move(int col, int row){
    squares[col][row].setPieceType(squares[colNum][rowNum].getPieceType());
    squares[colNum][rowNum].setPieceType(PieceType.empty);
    squares[colNum][rowNum].setColor('E');
    squares[col][row].setColor(player);
    squares[col][row].setHasMoved(true);
    squares[colNum][rowNum].setHasMoved(true);
    checkPawnUpgrade(col,row);
    drawPiecePositions();
    if(player=='W'){
    player='B';
    }else{
    player='W';
    }
    }
    public void checkPawnUpgrade(int col, int row){
    if(player=='W'&&squares[col][row].getPieceType()==PieceType.pawn&& row==7){
    MainFrame.pawn(col, row);
    }
    if(player=='B'&&squares[col][row].getPieceType()==PieceType.pawn&& row==0){
    MainFrame.pawn(col, row);
    }
    }
    public static void pieceChoice(PieceType type, int col, int row){
    squares[col][row].setPieceType(type);
    drawPiecePositions();
    }
    public void castle(int col, int row){
    if(col==2&&row==0){
        //moves the king
    squares[col][row].setPieceType(squares[colNum][rowNum].getPieceType());
    squares[col][row].setColor(player);
    squares[col][row].setHasMoved(true);
    squares[colNum][rowNum].setPieceType(PieceType.empty);
    squares[colNum][rowNum].setColor('E');
    squares[colNum][rowNum].setHasMoved(true);
    
    //moves the rook
    squares[3][0].setPieceType(PieceType.rook);
    squares[3][0].setColor(player);
    squares[3][0].setHasMoved(true);
    squares[0][0].setPieceType(PieceType.empty);
    squares[0][0].setColor('E');
    squares[0][0].setHasMoved(true);
    }
    if(col==6&&row==0){
        //moves the king
    squares[col][row].setPieceType(squares[colNum][rowNum].getPieceType());
    squares[col][row].setColor(player);
    squares[col][row].setHasMoved(true);
    squares[colNum][rowNum].setPieceType(PieceType.empty);
    squares[colNum][rowNum].setColor('E');
    squares[colNum][rowNum].setHasMoved(true);
    
    //moves the rook
    squares[5][0].setPieceType(PieceType.rook);
    squares[5][0].setColor(player);
    squares[5][0].setHasMoved(true);
    squares[7][0].setPieceType(PieceType.empty);
    squares[7][0].setColor('E');
    squares[7][0].setHasMoved(true);
    }
    if(col==2&&row==7){
        //moves the king
    squares[col][row].setPieceType(squares[colNum][rowNum].getPieceType());
    squares[col][row].setColor(player);
    squares[col][row].setHasMoved(true);
    squares[colNum][rowNum].setPieceType(PieceType.empty);
    squares[colNum][rowNum].setColor('E');
    squares[colNum][rowNum].setHasMoved(true);
    
    //moves the rook
    squares[3][7].setPieceType(PieceType.rook);
    squares[3][7].setColor(player);
    squares[3][7].setHasMoved(true);
    squares[0][7].setPieceType(PieceType.empty);
    squares[0][7].setColor('E');
    squares[0][7].setHasMoved(true);
    }
    if(col==6&&row==7){
        //moves the king
    squares[col][row].setPieceType(squares[colNum][rowNum].getPieceType());
    squares[col][row].setColor(player);
    squares[col][row].setHasMoved(true);
    squares[colNum][rowNum].setPieceType(PieceType.empty);
    squares[colNum][rowNum].setColor('E');
    squares[colNum][rowNum].setHasMoved(true);
    
    //moves the rook
    squares[5][7].setPieceType(PieceType.rook);
    squares[5][7].setColor(player);
    squares[5][7].setHasMoved(true);
    squares[7][7].setPieceType(PieceType.empty);
    squares[7][7].setColor('E');
    squares[7][7].setHasMoved(true);
    }
    drawPiecePositions();
    if(player=='W'){
    player='B';
    }else{
    player='W';
    }
    
    }
    public static void loadBackColors(){
     for(int i=0; i<8; i++){
        for(int j=0; j<8; j+=2){
            if(i%2==0){
        buttons[i][j].setBackground(playerOneBackgroundColor);
        buttons[i][j+1].setBackground(playerTwoBackgroundColor);
            }else{
        buttons[i][j].setBackground(playerTwoBackgroundColor);
        buttons[i][j+1].setBackground(playerOneBackgroundColor);
            }
        }} 
     drawPiecePositions();
    }
    public void highlightSquare(int col, int row){
        loadBackColors();
    buttons[col][row].setBackground(Color.yellow);
    }
    
    
    
    public void loadColors(){
    try {
            FileInputStream fis = new FileInputStream("PlayerOneColor.txt");
            InputStreamReader inread = new InputStreamReader(fis);
            BufferedReader buffread = new BufferedReader(inread);
            String savedArray = buffread.readLine();
            buffread.close();
            inread.close();
            fis.close();
            String[] strs= new String[3];
            strs=savedArray.split(",");
            int[] num= new int[3];
            num[0]=Integer.parseInt(strs[0]);
            num[1]=Integer.parseInt(strs[1]);
            num[2]=Integer.parseInt(strs[2]);
           Color color= new Color(num[0],num[1],num[2]);
     playerOneColor=color;       
          
           
    }catch(Exception e){
    
    }
    try {
            FileInputStream fis = new FileInputStream("PlayerTwoColor.txt");
            InputStreamReader inread = new InputStreamReader(fis);
            BufferedReader buffread = new BufferedReader(inread);
            String savedArray = buffread.readLine();
            buffread.close();
            inread.close();
            fis.close();
         String[] strs= new String[3];
            strs=savedArray.split(",");
            int[] num= new int[3];
            num[0]=Integer.parseInt(strs[0]);
            num[1]=Integer.parseInt(strs[1]);
            num[2]=Integer.parseInt(strs[2]);
           Color color= new Color(num[0],num[1],num[2]);
     playerTwoColor=color;    
          
           
    }catch(Exception e){
    
    }
    try {
            FileInputStream fis = new FileInputStream("PlayerOneBackground.txt");
            InputStreamReader inread = new InputStreamReader(fis);
            BufferedReader buffread = new BufferedReader(inread);
            String savedArray = buffread.readLine();
            buffread.close();
            inread.close();
            fis.close();
         String[] strs= new String[3];
            strs=savedArray.split(",");
            int[] num= new int[3];
            num[0]=Integer.parseInt(strs[0]);
            num[1]=Integer.parseInt(strs[1]);
            num[2]=Integer.parseInt(strs[2]);
           Color color= new Color(num[0],num[1],num[2]);
     playerOneBackgroundColor=color;  
          
           
    }catch(Exception e){
    
    }
    try {
            FileInputStream fis = new FileInputStream("PlayerTwoBackground.txt");
            InputStreamReader inread = new InputStreamReader(fis);
            BufferedReader buffread = new BufferedReader(inread);
            String savedArray = buffread.readLine();
            buffread.close();
            inread.close();
            fis.close();
           String[] strs= new String[3];
            strs=savedArray.split(",");
            int[] num= new int[3];
            num[0]=Integer.parseInt(strs[0]);
            num[1]=Integer.parseInt(strs[1]);
            num[2]=Integer.parseInt(strs[2]);
           Color color= new Color(num[0],num[1],num[2]);
     playerTwoBackgroundColor=color; 
          
           
    }catch(Exception e){
    
    }
    }
    
    public static void drawPiecePositions(){
        for(int i=0; i<8; i++){
            for(int j=0; j<8; j++){
    final int BI_WIDTH = 100;
    final int BI_HEIGHT = 100;
    BufferedImage img = new BufferedImage(BI_WIDTH, BI_HEIGHT,BufferedImage.TYPE_INT_ARGB);
    Graphics g = img.createGraphics();
    switch(squares[i][j].getPieceType()){
        case rook->drawRook(g,squares[i][j].getColor());
        case pawn->drawPawn(g,squares[i][j].getColor());
        case queen->drawQueen(g,squares[i][j].getColor());
        case king->drawKing(g,squares[i][j].getColor());
        case bishop->drawBishop(g,squares[i][j].getColor());
        case knight->drawKnight(g,squares[i][j].getColor());
    }
    buttons[i][j].setIcon(new ImageIcon(img));
        }
        }
    
    }
    public static void drawRook(Graphics g, char color){
        Color c;
        if(color=='W'){
        c=playerOneColor;
        }else{
        c=playerTwoColor;
        }
    g.setColor(c);
    g.fillRect(10, 90, 80, 10);
    g.fillRect(15, 80, 70, 10);
    g.fillRect(15, 70, 70, 30);
    g.fillOval(10, 70, 10, 10);
    g.fillOval(79, 70, 10, 10);
    g.fillRect(25, 40, 50, 30);
    g.fillOval(20, 40, 10, 10);
    g.fillOval(69, 40, 10, 10);
    g.fillRect(25, 30, 50, 10);
    g.fillRect(15, 20, 70, 10);
    g.fillRect(15, 10, 15, 10);
    g.fillRect(70, 10, 15, 10);
    g.fillRect(43, 10, 15, 10);
    
    }
    public static void drawKnight(Graphics g, char color){
     Color c;
        if(color=='W'){
        c=playerOneColor;
        }else{
        c=playerTwoColor;
        }
    g.setColor(c);
    g.fillRect(25, 95, 50, 4);
    g.fillOval(23, 95, 4, 4);
    g.fillOval(72, 95, 4, 4);
    g.fillRect(25, 90, 50, 4);
    g.fillOval(23, 90, 4, 4);
    g.fillOval(72, 90, 4, 4);
    g.fillRect(25, 85, 50, 4);
    g.fillOval(23, 85, 4, 4);
    g.fillOval(72, 85, 4, 4);
    
    g.fillRect(25, 80, 50, 5);
    g.fillRect(25, 75, 55, 5);
    g.fillRect(20, 70, 55, 5);
    g.fillRect(15, 65, 55, 5);
    g.fillRect(15, 60, 50, 5);
    g.fillRect(15, 55, 45, 5);
    g.fillRect(15, 50, 40, 5);
    g.fillRect(15, 45, 40, 5);
    g.fillRect(20, 40, 40, 5);
    g.fillRect(20, 35, 55, 5);
    g.fillRect(25, 30, 45, 5);
    g.fillRect(25, 25, 40, 5);
    g.fillRect(30, 20, 30, 5);
    g.fillRect(45, 15, 10, 5);
    g.fillRect(50, 10, 5, 5);
    g.fillRect(60, 40, 20, 5);
    g.fillRect(65, 45, 15, 5);
    g.fillRect(65, 50, 10, 5);
    }
    public static void drawBishop(Graphics g, char color){
     Color c;
        if(color=='W'){
        c=playerOneColor;
        }else{
        c=playerTwoColor;
        }
        
    g.setColor(c);
    g.fillRect(20, 90, 60, 10);
    g.fillOval(15, 90, 10, 10);
    g.fillOval(75, 90, 10, 10);
    
    g.fillRect(25, 80, 50, 10);
    
    
   // g.fillRect(31, 65, 40, 10);
   // g.fillOval(26, 65, 10, 10);
    //g.fillOval(66, 65, 10, 10);
    
    g.fillRect(30, 70, 40, 10);
    g.fillRect(35, 60, 30, 10);
    g.fillRect(35, 50, 30, 10);
    g.fillOval(30, 50, 10, 10);
    g.fillOval(60, 50, 10, 10);
    
    //g.fillOval(32, 55, 10, 10);
    //g.fillOval(62, 55, 10, 10);
    
    //g.fillRect(42, 45, 20, 10);
    
    g.fillOval(35, 18, 30, 40);
    g.fillOval(45, 10, 10, 10);
    }
    public static void drawQueen(Graphics g, char color){
     Color c;
        if(color=='W'){
        c=playerOneColor;
        }else{
        c=playerTwoColor;
        }
        g.setColor(c);
        g.fillRect(25, 30, 50, 50);
        g.fillRect(20, 20, 60, 10);
   if(color=='B'){
        g.setColor(playerOneBackgroundColor);
        }else{
        g.setColor(playerTwoBackgroundColor);
        }
    g.fillOval(5, 30, 35, 55);
    g.fillOval(60, 30, 35, 55);
    g.fillOval(22, 15, 16, 10);
    
    g.fillOval(62, 15, 16, 10);
    g.setColor(c);
    g.fillOval(40, 5, 20, 20);
    g.fillRect(20, 90, 60, 10);
    g.fillOval(15, 90, 10, 10);
    g.fillOval(75, 90, 10, 10);
    
    g.fillOval(25, 75, 50, 20);
    
    
    }
    public static void drawKing(Graphics g, char color){
     Color c;
        if(color=='W'){
        c=playerOneColor;
        }else{
        c=playerTwoColor;
        }
        
    g.setColor(c);
    g.fillRect(20, 90, 60, 10);
    g.fillOval(15, 90, 10, 10);
    g.fillOval(75, 90, 10, 10);
    
    g.fillRect(25, 80, 50, 10);
    
    
   // g.fillRect(31, 65, 40, 10);
   // g.fillOval(26, 65, 10, 10);
    //g.fillOval(66, 65, 10, 10);
    
    g.fillRect(30, 70, 40, 10);
    g.fillRect(35, 60, 30, 10);
    g.fillRect(35, 30, 30, 30);
    g.fillOval(30, 30, 10, 10);
    g.fillOval(60, 30, 10, 10);
    g.fillRect(40, 25, 20, 5);
    g.fillRect(35, 20, 30, 5);
    g.fillRect(47, 5, 5, 15);
    g.fillRect(42, 10, 15, 5);
    
    //g.fillOval(32, 55, 10, 10);
    //g.fillOval(62, 55, 10, 10);
    
    //g.fillRect(42, 45, 20, 10);
    
    
    }
    public static void drawPawn(Graphics g, char color){
     Color c;
        if(color=='W'){
        c=playerOneColor;
        }else{
        c=playerTwoColor;
        }
    g.setColor(c);
    g.fillRect(20, 85, 60, 15);
    g.fillOval(13, 85, 15, 15);
    g.fillOval(73, 85, 15, 15);
    
    g.fillRect(26, 75, 50, 10);
    g.fillOval(21, 75, 10, 10);
    g.fillOval(71, 75, 10, 10);
    
   // g.fillRect(31, 65, 40, 10);
   // g.fillOval(26, 65, 10, 10);
    //g.fillOval(66, 65, 10, 10);
    
    g.fillRect(37, 55, 30, 30);
    g.fillOval(32, 55, 10, 10);
    g.fillOval(62, 55, 10, 10);
    
    g.fillRect(42, 45, 20, 10);
    
    g.fillOval(37, 20, 30, 30);
    }
    
    
    
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BoardPanel = new javax.swing.JPanel();
        a8 = new javax.swing.JButton();
        b8 = new javax.swing.JButton();
        c8 = new javax.swing.JButton();
        d8 = new javax.swing.JButton();
        e8 = new javax.swing.JButton();
        f8 = new javax.swing.JButton();
        g8 = new javax.swing.JButton();
        h8 = new javax.swing.JButton();
        a7 = new javax.swing.JButton();
        b7 = new javax.swing.JButton();
        c7 = new javax.swing.JButton();
        d7 = new javax.swing.JButton();
        e7 = new javax.swing.JButton();
        f7 = new javax.swing.JButton();
        g7 = new javax.swing.JButton();
        h7 = new javax.swing.JButton();
        a6 = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        c6 = new javax.swing.JButton();
        d6 = new javax.swing.JButton();
        e6 = new javax.swing.JButton();
        f6 = new javax.swing.JButton();
        g6 = new javax.swing.JButton();
        h6 = new javax.swing.JButton();
        a5 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        c5 = new javax.swing.JButton();
        d5 = new javax.swing.JButton();
        e5 = new javax.swing.JButton();
        f5 = new javax.swing.JButton();
        g5 = new javax.swing.JButton();
        h5 = new javax.swing.JButton();
        a4 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        c4 = new javax.swing.JButton();
        d4 = new javax.swing.JButton();
        e4 = new javax.swing.JButton();
        f4 = new javax.swing.JButton();
        g4 = new javax.swing.JButton();
        h4 = new javax.swing.JButton();
        a3 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        c3 = new javax.swing.JButton();
        d3 = new javax.swing.JButton();
        e3 = new javax.swing.JButton();
        f3 = new javax.swing.JButton();
        g3 = new javax.swing.JButton();
        h3 = new javax.swing.JButton();
        a2 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        c2 = new javax.swing.JButton();
        d2 = new javax.swing.JButton();
        e2 = new javax.swing.JButton();
        f2 = new javax.swing.JButton();
        g2 = new javax.swing.JButton();
        h2 = new javax.swing.JButton();
        a1 = new javax.swing.JButton();
        b1 = new javax.swing.JButton();
        c1 = new javax.swing.JButton();
        d1 = new javax.swing.JButton();
        e1 = new javax.swing.JButton();
        f1 = new javax.swing.JButton();
        g1 = new javax.swing.JButton();
        h1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();

        setPreferredSize(new java.awt.Dimension(1700, 1100));

        BoardPanel.setPreferredSize(new java.awt.Dimension(1000, 1000));
        BoardPanel.setLayout(new java.awt.GridLayout(8, 8));

        a8.setOpaque(true);
        BoardPanel.add(a8);

        b8.setOpaque(true);
        BoardPanel.add(b8);

        c8.setOpaque(true);
        BoardPanel.add(c8);

        d8.setBorderPainted(false);
        d8.setOpaque(true);
        BoardPanel.add(d8);

        e8.setOpaque(true);
        BoardPanel.add(e8);

        f8.setOpaque(true);
        BoardPanel.add(f8);

        g8.setOpaque(true);
        BoardPanel.add(g8);

        h8.setOpaque(true);
        BoardPanel.add(h8);

        a7.setOpaque(true);
        BoardPanel.add(a7);

        b7.setOpaque(true);
        BoardPanel.add(b7);

        c7.setOpaque(true);
        BoardPanel.add(c7);

        d7.setOpaque(true);
        BoardPanel.add(d7);

        e7.setOpaque(true);
        BoardPanel.add(e7);

        f7.setOpaque(true);
        BoardPanel.add(f7);

        g7.setOpaque(true);
        BoardPanel.add(g7);

        h7.setOpaque(true);
        BoardPanel.add(h7);

        a6.setOpaque(true);
        BoardPanel.add(a6);

        b6.setOpaque(true);
        BoardPanel.add(b6);

        c6.setOpaque(true);
        BoardPanel.add(c6);

        d6.setOpaque(true);
        BoardPanel.add(d6);

        e6.setOpaque(true);
        BoardPanel.add(e6);

        f6.setOpaque(true);
        BoardPanel.add(f6);

        g6.setOpaque(true);
        BoardPanel.add(g6);

        h6.setOpaque(true);
        BoardPanel.add(h6);

        a5.setOpaque(true);
        BoardPanel.add(a5);

        b5.setOpaque(true);
        BoardPanel.add(b5);

        c5.setOpaque(true);
        BoardPanel.add(c5);

        d5.setOpaque(true);
        BoardPanel.add(d5);

        e5.setOpaque(true);
        BoardPanel.add(e5);

        f5.setOpaque(true);
        BoardPanel.add(f5);

        g5.setOpaque(true);
        BoardPanel.add(g5);

        h5.setOpaque(true);
        BoardPanel.add(h5);

        a4.setOpaque(true);
        BoardPanel.add(a4);

        b4.setOpaque(true);
        BoardPanel.add(b4);

        c4.setOpaque(true);
        BoardPanel.add(c4);

        d4.setOpaque(true);
        BoardPanel.add(d4);

        e4.setOpaque(true);
        BoardPanel.add(e4);

        f4.setOpaque(true);
        BoardPanel.add(f4);

        g4.setOpaque(true);
        BoardPanel.add(g4);

        h4.setOpaque(true);
        BoardPanel.add(h4);

        a3.setOpaque(true);
        BoardPanel.add(a3);

        b3.setOpaque(true);
        BoardPanel.add(b3);

        c3.setOpaque(true);
        BoardPanel.add(c3);

        d3.setOpaque(true);
        BoardPanel.add(d3);

        e3.setOpaque(true);
        BoardPanel.add(e3);

        f3.setOpaque(true);
        BoardPanel.add(f3);

        g3.setOpaque(true);
        BoardPanel.add(g3);

        h3.setOpaque(true);
        BoardPanel.add(h3);

        a2.setOpaque(true);
        BoardPanel.add(a2);

        b2.setOpaque(true);
        BoardPanel.add(b2);

        c2.setOpaque(true);
        BoardPanel.add(c2);

        d2.setOpaque(true);
        BoardPanel.add(d2);

        e2.setOpaque(true);
        BoardPanel.add(e2);

        f2.setOpaque(true);
        BoardPanel.add(f2);

        g2.setOpaque(true);
        BoardPanel.add(g2);

        h2.setOpaque(true);
        BoardPanel.add(h2);

        a1.setOpaque(true);
        a1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                a1ActionPerformed(evt);
            }
        });
        BoardPanel.add(a1);

        b1.setOpaque(true);
        BoardPanel.add(b1);

        c1.setOpaque(true);
        BoardPanel.add(c1);

        d1.setOpaque(true);
        BoardPanel.add(d1);

        e1.setOpaque(true);
        BoardPanel.add(e1);

        f1.setOpaque(true);
        BoardPanel.add(f1);

        g1.setOpaque(true);
        BoardPanel.add(g1);

        h1.setOpaque(true);
        BoardPanel.add(h1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 335, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 290, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(BoardPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1024, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(21, 21, 21))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BoardPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 708, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void a1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_a1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_a1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BoardPanel;
    private javax.swing.JButton a1;
    private javax.swing.JButton a2;
    private javax.swing.JButton a3;
    private javax.swing.JButton a4;
    private javax.swing.JButton a5;
    private javax.swing.JButton a6;
    private javax.swing.JButton a7;
    private javax.swing.JButton a8;
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JButton b4;
    private javax.swing.JButton b5;
    private javax.swing.JButton b6;
    private javax.swing.JButton b7;
    private javax.swing.JButton b8;
    private javax.swing.JButton c1;
    private javax.swing.JButton c2;
    private javax.swing.JButton c3;
    private javax.swing.JButton c4;
    private javax.swing.JButton c5;
    private javax.swing.JButton c6;
    private javax.swing.JButton c7;
    private javax.swing.JButton c8;
    private javax.swing.JButton d1;
    private javax.swing.JButton d2;
    private javax.swing.JButton d3;
    private javax.swing.JButton d4;
    private javax.swing.JButton d5;
    private javax.swing.JButton d6;
    private javax.swing.JButton d7;
    private javax.swing.JButton d8;
    private javax.swing.JButton e1;
    private javax.swing.JButton e2;
    private javax.swing.JButton e3;
    private javax.swing.JButton e4;
    private javax.swing.JButton e5;
    private javax.swing.JButton e6;
    private javax.swing.JButton e7;
    private javax.swing.JButton e8;
    private javax.swing.JButton f1;
    private javax.swing.JButton f2;
    private javax.swing.JButton f3;
    private javax.swing.JButton f4;
    private javax.swing.JButton f5;
    private javax.swing.JButton f6;
    private javax.swing.JButton f7;
    private javax.swing.JButton f8;
    private javax.swing.JButton g1;
    private javax.swing.JButton g2;
    private javax.swing.JButton g3;
    private javax.swing.JButton g4;
    private javax.swing.JButton g5;
    private javax.swing.JButton g6;
    private javax.swing.JButton g7;
    private javax.swing.JButton g8;
    private javax.swing.JButton h1;
    private javax.swing.JButton h2;
    private javax.swing.JButton h3;
    private javax.swing.JButton h4;
    private javax.swing.JButton h5;
    private javax.swing.JButton h6;
    private javax.swing.JButton h7;
    private javax.swing.JButton h8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    // End of variables declaration//GEN-END:variables
}
