
package ChessImproved;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;


public class ColorSelector extends javax.swing.JFrame {
    
    
    public ColorSelector() {
        initComponents();
       
    }
    
    public void adjust(){
        Color c= new Color(red.getValue(),green.getValue(),blue.getValue());
    selection.setBackground(c);
    
   
    }
    
    public void savePlayerOneColor(){
        String str= new String();
        
        str+=String.valueOf(red.getValue())+","+String.valueOf(green.getValue())+","+String.valueOf(blue.getValue());
        
        
    try {
            FileOutputStream fos = new FileOutputStream("PlayerOneColor.txt");
            OutputStreamWriter outWrite = new OutputStreamWriter(fos);
            outWrite.write(str);
            outWrite.flush();
            outWrite.close();
            fos.close();
            System.out.println("File Saved");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void savePlayerTwoColor(){
        String str= new String();
        
        str+=String.valueOf(red.getValue())+","+String.valueOf(green.getValue())+","+String.valueOf(blue.getValue());
        
        
    try {
            FileOutputStream fos = new FileOutputStream("PlayerTwoColor.txt");
            OutputStreamWriter outWrite = new OutputStreamWriter(fos);
            outWrite.write(str);
            outWrite.flush();
            outWrite.close();
            fos.close();
            System.out.println("File Saved");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void savePlayerOneBackground(){
        String str= new String();
        
        str+=String.valueOf(red.getValue())+","+String.valueOf(green.getValue())+","+String.valueOf(blue.getValue());
        
        
    try {
            FileOutputStream fos = new FileOutputStream("PlayerOneBackground.txt");
            OutputStreamWriter outWrite = new OutputStreamWriter(fos);
            outWrite.write(str);
            outWrite.flush();
            outWrite.close();
            fos.close();
            System.out.println("File Saved");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void savePlayerTwoBackground(){
        String str= new String();
        
        str+=String.valueOf(red.getValue())+","+String.valueOf(green.getValue())+","+String.valueOf(blue.getValue());
        
        
    try {
            FileOutputStream fos = new FileOutputStream("PLayerTwoBackground.txt");
            OutputStreamWriter outWrite = new OutputStreamWriter(fos);
            outWrite.write(str);
            outWrite.flush();
            outWrite.close();
            fos.close();
            System.out.println("File Saved");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void load(){
    try {
            FileInputStream fis = new FileInputStream("PlayerOneColor.txt");
            InputStreamReader inread = new InputStreamReader(fis);
            BufferedReader buffread = new BufferedReader(inread);
            String savedArray = buffread.readLine();
            buffread.close();
            inread.close();
            fis.close();
            String[] strs= new String[3];
            strs=savedArray.split(",");
            int[] num= new int[3];
            num[0]=Integer.parseInt(strs[0]);
            num[1]=Integer.parseInt(strs[1]);
            num[2]=Integer.parseInt(strs[2]);
           Color color= new Color(num[0],num[1],num[2]);
     Color1.setBackground(color);       
          
           
    }catch(Exception e){
    
    }
    try {
            FileInputStream fis = new FileInputStream("PlayerTwoColor.txt");
            InputStreamReader inread = new InputStreamReader(fis);
            BufferedReader buffread = new BufferedReader(inread);
            String savedArray = buffread.readLine();
            buffread.close();
            inread.close();
            fis.close();
         String[] strs= new String[3];
            strs=savedArray.split(",");
            int[] num= new int[3];
            num[0]=Integer.parseInt(strs[0]);
            num[1]=Integer.parseInt(strs[1]);
            num[2]=Integer.parseInt(strs[2]);
           Color color= new Color(num[0],num[1],num[2]);
     Color2.setBackground(color);    
          
           
    }catch(Exception e){
    
    }
    try {
            FileInputStream fis = new FileInputStream("PlayerOneBackground.txt");
            InputStreamReader inread = new InputStreamReader(fis);
            BufferedReader buffread = new BufferedReader(inread);
            String savedArray = buffread.readLine();
            buffread.close();
            inread.close();
            fis.close();
         String[] strs= new String[3];
            strs=savedArray.split(",");
            int[] num= new int[3];
            num[0]=Integer.parseInt(strs[0]);
            num[1]=Integer.parseInt(strs[1]);
            num[2]=Integer.parseInt(strs[2]);
           Color color= new Color(num[0],num[1],num[2]);
     Color3.setBackground(color);    
          
           
    }catch(Exception e){
    
    }
    try {
            FileInputStream fis = new FileInputStream("PlayerTwoBackground.txt");
            InputStreamReader inread = new InputStreamReader(fis);
            BufferedReader buffread = new BufferedReader(inread);
            String savedArray = buffread.readLine();
            buffread.close();
            inread.close();
            fis.close();
           String[] strs= new String[3];
            strs=savedArray.split(",");
            int[] num= new int[3];
            num[0]=Integer.parseInt(strs[0]);
            num[1]=Integer.parseInt(strs[1]);
            num[2]=Integer.parseInt(strs[2]);
           Color color= new Color(num[0],num[1],num[2]);
     Color4.setBackground(color);  
          
           
    }catch(Exception e){
    
    }
    }
    
    @Override
    public void setDefaultCloseOperation(int operation){
    dispose();
    }

    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
//     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        red = new javax.swing.JSlider();
        jPanel2 = new javax.swing.JPanel();
        green = new javax.swing.JSlider();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        blue = new javax.swing.JSlider();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        selection = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        Color1 = new javax.swing.JButton();
        Color2 = new javax.swing.JButton();
        Color3 = new javax.swing.JButton();
        Color4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new java.awt.Dimension(390, 291));

        jPanel1.setLayout(new java.awt.GridLayout(2, 1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Red");
        jPanel1.add(jLabel2);

        red.setMaximum(255);
        red.setValue(0);
        red.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                redStateChanged(evt);
            }
        });
        jPanel1.add(red);

        jPanel2.setLayout(new java.awt.GridLayout(2, 1));

        green.setMaximum(255);
        green.setValue(0);
        green.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                greenStateChanged(evt);
            }
        });
        jPanel2.add(green);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Green");
        jPanel2.add(jLabel3);

        jPanel3.setLayout(new java.awt.GridLayout(1, 2));

        blue.setMaximum(255);
        blue.setOrientation(javax.swing.JSlider.VERTICAL);
        blue.setToolTipText("");
        blue.setValue(0);
        blue.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                blueStateChanged(evt);
            }
        });
        jPanel3.add(blue);

        jLabel1.setText("B");

        jLabel4.setText("l");

        jLabel5.setText("u");

        jLabel6.setText("e");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(8, Short.MAX_VALUE)
                    .addComponent(jLabel1)
                    .addContainerGap(8, Short.MAX_VALUE)))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(9, Short.MAX_VALUE)
                    .addComponent(jLabel4)
                    .addContainerGap(10, Short.MAX_VALUE)))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel5)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(8, Short.MAX_VALUE)
                    .addComponent(jLabel6)
                    .addContainerGap(8, Short.MAX_VALUE)))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 338, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(113, Short.MAX_VALUE)
                    .addComponent(jLabel1)
                    .addContainerGap(209, Short.MAX_VALUE)))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(136, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(177, Short.MAX_VALUE)))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel5)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(184, Short.MAX_VALUE)
                    .addComponent(jLabel6)
                    .addContainerGap(138, Short.MAX_VALUE)))
        );

        jPanel3.add(jPanel4);

        selection.setText("Color");
        selection.setOpaque(true);
        selection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectionActionPerformed(evt);
            }
        });

        jPanel5.setLayout(new java.awt.GridLayout(4, 1));

        Color1.setText("Player 1");
        Color1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Color1ActionPerformed(evt);
            }
        });
        jPanel5.add(Color1);

        Color2.setText("Player 2");
        Color2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Color2ActionPerformed(evt);
            }
        });
        jPanel5.add(Color2);

        Color3.setText("Back 1");
        Color3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Color3ActionPerformed(evt);
            }
        });
        jPanel5.add(Color3);

        Color4.setText("Back 2");
        Color4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Color4ActionPerformed(evt);
            }
        });
        jPanel5.add(Color4);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 283, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(154, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(selection, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(204, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addGap(0, 397, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(86, Short.MAX_VALUE)
                    .addComponent(selection, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(84, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void redStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_redStateChanged
       adjust();
       repaint();
    }//GEN-LAST:event_redStateChanged

    private void blueStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_blueStateChanged
      adjust();
       repaint();
    }//GEN-LAST:event_blueStateChanged

    private void greenStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_greenStateChanged
        adjust();
       repaint();
    }//GEN-LAST:event_greenStateChanged

    private void selectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectionActionPerformed
        
    }//GEN-LAST:event_selectionActionPerformed

    private void Color1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Color1ActionPerformed
        savePlayerOneColor();
        Color color = new Color(red.getValue(),green.getValue(),blue.getValue());
         Color1.setBackground(color);
         Board.playerOneColor=color;
        Board.loadBackColors();
    }//GEN-LAST:event_Color1ActionPerformed

    private void Color2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Color2ActionPerformed
       savePlayerTwoColor();
       Color color = new Color(red.getValue(),green.getValue(),blue.getValue());
         Color2.setBackground(color);
         Board.playerTwoColor=color;
        Board.loadBackColors();
    }//GEN-LAST:event_Color2ActionPerformed

    private void Color3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Color3ActionPerformed
        savePlayerOneBackground();
        Color color = new Color(red.getValue(),green.getValue(),blue.getValue());
         Color3.setBackground(color);
          Board.playerOneBackgroundColor=color;
        Board.loadBackColors();
    }//GEN-LAST:event_Color3ActionPerformed

    private void Color4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Color4ActionPerformed
         savePlayerTwoBackground();
         Color color = new Color(red.getValue(),green.getValue(),blue.getValue());
         Color4.setBackground(color);
        Board.playerTwoBackgroundColor=color;
        Board.loadBackColors();
    }//GEN-LAST:event_Color4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Color.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Color.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Color.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Color.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Color1;
    private javax.swing.JButton Color2;
    private javax.swing.JButton Color3;
    private javax.swing.JButton Color4;
    private javax.swing.JSlider blue;
    private javax.swing.JSlider green;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JSlider red;
    private javax.swing.JButton selection;
    // End of variables declaration//GEN-END:variables
}
