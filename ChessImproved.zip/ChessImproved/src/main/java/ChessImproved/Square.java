
package ChessImproved;



public class Square {
    private char color;
    private int row;
    private int col;
    private PieceType pieceType;
    private boolean possibleMove;
    private boolean selected;
    private boolean hasMoved;
    private boolean canCastle;
    public Square( int col, int row){
    this.color='E';
    this.row=row;
    this.col= col;
    this.pieceType=PieceType.empty;
    this.selected= false;
    this.possibleMove=false;
    this.hasMoved=false;
    }

    public boolean isCanCastle() {
        return canCastle;
    }

    public void setCanCastle(boolean canCastle) {
        this.canCastle = canCastle;
    }

    public boolean isHasMoved() {
        return hasMoved;
    }

    public void setHasMoved(boolean hasMoved) {
        this.hasMoved = hasMoved;
    }

    
    public boolean isPossibleMove() {
        return possibleMove;
    }

    public void setPossibleMove(boolean possibleMove) {
        this.possibleMove = possibleMove;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public char getColor() {
        return color;
    }

    public void setColor(char color) {
        this.color = color;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public PieceType getPieceType() {
        return pieceType;
    }

    public void setPieceType(PieceType pieceType) {
        this.pieceType = pieceType;
    }
    
}
