package ChessImproved;


public enum PieceType {
    king,
    queen,
    rook,
    knight,
    bishop,
    pawn,
    empty
}
