package ClosestPoints;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class Main {

    private static int ptNum = 10;
    private static int accuracy = 0;

    public static class Point {

        private int x;
        private int y;

        public Point(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public int getX() {
            return x;
        }

        public void setX(int x) {
            this.x = x;
        }

        public int getY() {
            return y;
        }

        public void setY(int y) {
            this.y = y;
        }

    }

    private static class Pair {

        private double dist;
        private int p1;
        private int p2;

        public Pair(int p1, int p2, double dist) {
            this.p1 = p1;
            this.p2 = p2;
            this.dist = dist;
        }

    }

    public static Point[] createPoints() {
        Point[] points = new Point[ptNum];
        //create initial point
        Random r = new Random();
        Point p = new Point(r.nextInt(5), r.nextInt(20));
        points[0] = p;
//create rest of points
        for (int i = 1; i < ptNum; i++) {
            Random rand = new Random();
            Point pt = new Point(points[i - 1].getX() + rand.nextInt(5) + 1, rand.nextInt(20));
            points[i] = pt;
        }
        return points;
    }

    public static void display(Point[] array, Pair pt) {
        for (int i = 0; i < array.length; i++) {
            System.out.println("Index: " + i + "   X: " + array[i].getX() + "   Y: " + array[i].getY());
        }
        System.out.println("The Closest points are points " + pt.p1 + " and " + pt.p2 + " and they are " + pt.dist + " away.");
    }

    public static double distOfPair(Point pt1, Point pt2) {

        double dist = Math.sqrt(Math.pow(pt1.x - pt2.x, 2) + Math.pow(pt1.y - pt2.y, 2));

        return dist;
    }

    public static Pair partitionClosest(Point[] ptsX, Point[] part, int n, int startingIndex, double d) {
        double min = 1000; 
        int p1 = 0;
        int p2 = 0;
        for (int i = startingIndex; i < startingIndex + n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (distOfPair(part[i], part[j]) < min) {
                    min = distOfPair(part[i], part[j]);
                    p1 = i;
                    p2 = j;
                }
            }
        }
        int tempp1 = 0;
        int tempp2 = 0;
        for (int i = 0; i < ptsX.length; i++) {

            if (ptsX[i].x == part[p1].x && ptsX[i].y == part[p1].y) {
                tempp1 = i;
            }

            if (ptsX[i].y == part[p2].y && ptsX[i].x == part[p2].x) {
                tempp2 = i;
            }
        }
        p1 = tempp1;
        p2 = tempp2;

        Pair p = new Pair(p1, p2, min);
        return p;

    }

    public static Pair calcClosestPair(Point[] pts, int n, int startingIndex, Pair pair) {
        double minDist = 1000;

        for (int i = startingIndex; i < startingIndex + n; i++) {
            for (int j = i + 1; j < startingIndex + n; j++) {

                if (distOfPair(pts[i], pts[j]) < minDist) {

                    minDist = distOfPair(pts[i], pts[j]);
                    pair.dist = minDist;
                    pair.p1 = i;
                    pair.p2 = j;
                }
            }
        }

        return pair;
    }

    public static Pair closestPair(Point[] pts, int n, int startingIndex, Pair pair) {
        //System.out.println("N: " + n);
        //System.out.println("SIND: " + startingIndex);
        if (n < 4) {
            Pair p = calcClosestPair(pts, n, startingIndex, pair);

            Pair p2 = new Pair(p.p1, p.p2, p.dist);
//            System.out.println("BF.dist: " + p.dist);
//            System.out.println("BF.p1: " + p.p1);
//            System.out.println("BF.p2: " + p.p2);
            return p2;
        }

        int mid = n / 2;
        

        Pair p1 = closestPair(pts, mid, startingIndex, pair);

        Pair p2 = closestPair(pts, n - mid, startingIndex + mid, pair);
//        System.out.println("Call1Dist: " + p1.dist);
//        System.out.println("Call2Dist: " + p2.dist);
        Pair p;
        if (p1.dist < p2.dist) {
            p = p1;
        } else {
            p = p2;
        }
        //System.out.println("finalDist: " + p.dist);
        ArrayList<Point> points = new ArrayList<Point>();
        mid+=startingIndex;
Point midPoint = pts[mid];
        int j = 0;
        for (int i = startingIndex; i < startingIndex+n; i++) {
            if (Math.abs(pts[i].x - midPoint.x) < p.dist) {
                points.add(pts[i]);
                j++;
            }
        }
        //System.out.println("PTs.length: " + points.size());
        Point[] ptsY = sortY(points);

        Pair temp = partitionClosest(pts, ptsY, j, startingIndex, p.dist);

//        System.out.println("");
//        System.out.println("P.dist: " + p.dist);
//        System.out.println("P.p1: " + p.p1);
//        System.out.println("P.p2: " + p.p2);
//        System.out.println("T.dist: " + temp.dist);
//        System.out.println("T.p1: " + temp.p1);
//        System.out.println("T.p2: " + temp.p2);
        if (temp.dist < p.dist) {
            p = temp;
        }
//        System.out.println("PFin.dist: " + p.dist);
//        System.out.println("PFin.p1: " + p.p1);
//        System.out.println("PFin.p2: " + p.p2);
        return p;
    }

    public static Pair bruteForceSort(Point[] pts, int n, Pair pair) {

        double minDist = 1000;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (distOfPair(pts[i], pts[j]) < minDist) {
                    minDist = distOfPair(pts[i], pts[j]);
                    pair.p1 = i;
                    pair.p2 = j;
                    pair.dist = distOfPair(pts[i], pts[j]);
                }
            }
        }
        System.out.println("Brute Force Calculation");

        return pair;
    }

    public static Point[] sortY(ArrayList<Point> points) {

        ArrayList<Point> list = new ArrayList<Point>();
        Point[] ptsY = new Point[points.size()];
        for (int j = 0; j < points.size(); j++) {
            list.add(points.get(j));
        }

        for (int i = 0; i < points.size(); i++) {
            int index = -1;
            int min = 1000;

            for (int j = 0; j < list.size(); j++) {

                if (list.get(j).y < min) {
                    min = list.get(j).y;
                    index = j;
                }
            }
            Point p = new Point(list.get(index).x, list.get(index).y);
            ptsY[i] = p;
            list.remove(index);
        }

        return ptsY;
    }

    public static void sort(Point[] pts) {
        Pair pair = new Pair(0, 0, 10000);
        Pair p1 = bruteForceSort(pts, pts.length, pair);
        display(pts, p1);
        Pair p = new Pair(0, 0, 0);
        System.out.println("Divide and Conquer Calculation");
        Pair pair2 = new Pair(0, 0, 10000);
        Pair p2 = closestPair(pts, pts.length, 0, pair2);
        display(pts, p2);
        if (p1.dist == p2.dist) {
            accuracy++;
        }
    }

    public static void main(String[] args) {
        //for (int i = 0; i < 100; i++) {
            sort(createPoints());
        //}
       // System.out.println("C:" + accuracy);
    }

}
